-- ============================================================================
-- VORTEX SYSTEM — MIGRAÇÃO NÃO DESTRUTIVA PARA PROSPECTS
-- ============================================================================
-- Esta migration:
-- 1. NÃO apaga tabelas, colunas ou registros existentes.
-- 2. Adiciona apenas colunas ausentes na tabela public.prospects.
-- 3. Atualiza o cache do schema do PostgREST (NOTIFY pgrst, 'reload schema').
-- ============================================================================

ALTER TABLE IF EXISTS public.prospects
  ADD COLUMN IF NOT EXISTS instagram text,
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS origin text,
  ADD COLUMN IF NOT EXISTS responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS responsible_name text,
  ADD COLUMN IF NOT EXISTS contact_date date,
  ADD COLUMN IF NOT EXISTS first_contact_date date,
  ADD COLUMN IF NOT EXISTS next_contact_date date,
  ADD COLUMN IF NOT EXISTS converted_company_id uuid,
  ADD COLUMN IF NOT EXISTS converted_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

-- Preserva dados existentes de 'source' e 'company_id' nos novos campos apenas quando nulos
UPDATE public.prospects
SET origin = source
WHERE origin IS NULL AND source IS NOT NULL;

UPDATE public.prospects
SET converted_company_id = company_id
WHERE converted_company_id IS NULL AND company_id IS NOT NULL;

UPDATE public.prospects
SET first_contact_date = contact_date
WHERE first_contact_date IS NULL AND contact_date IS NOT NULL;

-- Atualiza o schema cache do Supabase / PostgREST imediatamente
NOTIFY pgrst, 'reload schema';
