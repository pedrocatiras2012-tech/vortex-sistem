-- ============================================================================
-- VORTEX SYSTEM 2.0 — EVOLUÇÃO COMERCIAL COMPLETA & GESTÃO DE EQUIPE (HARDENED)
-- ============================================================================
-- IMPORTANTE:
-- 1. Migration 100% incremental, idempotente e NÃO destrutiva.
-- 2. NÃO utiliza DROP TABLE, DROP COLUMN, TRUNCATE ou DELETE em massa.
-- 3. Preserva todos os dados, perfis, prospects, empresas, comissões e login.
-- 4. Segurança aplicada diretamente no banco (RLS granular por operação,
--    políticas restritivas, triggers anti-escalada e funções SECURITY DEFINER
--    com search_path fixo e privilégios EXECUTE restritos).
-- ============================================================================

-- 1. Evolução da tabela public.profiles (colaboradores, departamentos e responsabilidades)
ALTER TABLE IF EXISTS public.profiles
  ADD COLUMN IF NOT EXISTS phone text,
  ADD COLUMN IF NOT EXISTS department text,
  ADD COLUMN IF NOT EXISTS responsibilities text,
  ADD COLUMN IF NOT EXISTS entry_date date DEFAULT CURRENT_DATE,
  ADD COLUMN IF NOT EXISTS custom_role_label text,
  ADD COLUMN IF NOT EXISTS linked_auth_email text,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

-- 2. Evolução da tabela public.prospects (oportunidades, distribuição e fechamento)
ALTER TABLE IF EXISTS public.prospects
  ADD COLUMN IF NOT EXISTS estimated_value numeric(12,2),
  ADD COLUMN IF NOT EXISTS deal_value numeric(12,2),
  ADD COLUMN IF NOT EXISTS contracted_service text,
  ADD COLUMN IF NOT EXISTS closed_at date,
  ADD COLUMN IF NOT EXISTS sale_status text DEFAULT 'aberta',
  ADD COLUMN IF NOT EXISTS loss_reason text,
  ADD COLUMN IF NOT EXISTS next_activity_title text,
  ADD COLUMN IF NOT EXISTS next_activity_time text,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS assigned_by_name text,
  ADD COLUMN IF NOT EXISTS assignment_notes text,
  ADD COLUMN IF NOT EXISTS participating_collaborators jsonb DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS last_interaction_at timestamptz;

-- 3. Evolução da tabela public.commissions (status prevista/pendente/aprovada/paga e papel na venda)
ALTER TABLE IF EXISTS public.commissions
  ADD COLUMN IF NOT EXISTS participation_role text,
  ADD COLUMN IF NOT EXISTS notes text;

-- 4. Tabela public.prospect_activities (tarefas comerciais, lembretes e retornos)
CREATE TABLE IF NOT EXISTS public.prospect_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid NOT NULL REFERENCES public.prospects(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  due_date date NOT NULL,
  due_time text,
  responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  responsible_name text,
  priority text NOT NULL DEFAULT 'media',
  status text NOT NULL DEFAULT 'pendente',
  completion_outcome text,
  completed_at timestamptz,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_prospect_activities_prospect
  ON public.prospect_activities (prospect_id, due_date);
CREATE INDEX IF NOT EXISTS idx_prospect_activities_responsible
  ON public.prospect_activities (responsible_id, status, due_date);

-- 5. Tabela public.commercial_proposals (múltiplas propostas comerciais por lead)
CREATE TABLE IF NOT EXISTS public.commercial_proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid NOT NULL REFERENCES public.prospects(id) ON DELETE CASCADE,
  company_id uuid REFERENCES public.companies(id) ON DELETE SET NULL,
  title text NOT NULL,
  service_type text NOT NULL,
  value numeric(12,2) NOT NULL DEFAULT 0,
  sent_date date NOT NULL DEFAULT CURRENT_DATE,
  valid_until date,
  responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  responsible_name text,
  status text NOT NULL DEFAULT 'em_preparacao',
  viewed_confirmed_at timestamptz,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_commercial_proposals_prospect
  ON public.commercial_proposals (prospect_id, created_at DESC);

-- 6. Tabela public.lead_assignments_history (histórico imutável de atribuições e transferências)
CREATE TABLE IF NOT EXISTS public.lead_assignments_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid NOT NULL REFERENCES public.prospects(id) ON DELETE CASCADE,
  previous_responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  previous_responsible_name text,
  new_responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  new_responsible_name text,
  assigned_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  assigned_by_name text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_assignments_history_prospect
  ON public.lead_assignments_history (prospect_id, created_at DESC);

-- 7. Tabela public.sale_collaborators (participação de colaboradores em cada venda fechada)
CREATE TABLE IF NOT EXISTS public.sale_collaborators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid REFERENCES public.prospects(id) ON DELETE CASCADE,
  company_id uuid REFERENCES public.companies(id) ON DELETE SET NULL,
  collaborator_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  collaborator_name text,
  participation_role text NOT NULL,
  commission_id uuid REFERENCES public.commissions(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sale_collaborators_prospect
  ON public.sale_collaborators (prospect_id);
CREATE INDEX IF NOT EXISTS idx_sale_collaborators_collab
  ON public.sale_collaborators (collaborator_id);

-- 8. Tabela public.team_invites (pré-cadastro / vínculo seguro de colaboradores ao Supabase Auth)
CREATE TABLE IF NOT EXISTS public.team_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  email text NOT NULL,
  phone text,
  role text NOT NULL DEFAULT 'colaborador',
  job_title text NOT NULL DEFAULT 'Colaborador',
  department text,
  responsibilities text,
  entry_date date DEFAULT CURRENT_DATE,
  avatar_url text,
  permissions jsonb NOT NULL DEFAULT '{"dashboard":true,"prospeccao":true,"empresas":true,"comissoes":true,"financeiro":false,"marketing":true,"relatorios":false,"equipe":false,"configuracoes":false,"ver_todos_leads":false,"distribuir_leads":false,"visualizar_comissoes_equipe":false}'::jsonb,
  status text NOT NULL DEFAULT 'pendente',
  linked_profile_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_team_invites_email_pending
  ON public.team_invites (lower(email))
  WHERE status = 'pendente';

-- ============================================================================
-- 9. FUNÇÕES AUXILIARES DE AUTORIZAÇÃO (SECURITY DEFINER + search_path fixo)
-- ============================================================================

CREATE OR REPLACE FUNCTION public.vortex_is_active_user()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND lower(COALESCE(status, 'ativo')) = 'ativo'
  );
$$;

CREATE OR REPLACE FUNCTION public.vortex_current_role()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT COALESCE(
    (
      SELECT CASE
        WHEN lower(role) IN ('proprietario', 'owner') THEN 'proprietario'
        WHEN lower(role) IN ('administrador', 'admin') THEN 'administrador'
        WHEN lower(role) IN ('gerente', 'manager') THEN 'gerente'
        ELSE 'colaborador'
      END
      FROM public.profiles
      WHERE id = auth.uid()
        AND lower(COALESCE(status, 'ativo')) = 'ativo'
    ),
    ''
  );
$$;

CREATE OR REPLACE FUNCTION public.vortex_is_owner()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND lower(COALESCE(status, 'ativo')) = 'ativo'
      AND lower(role) IN ('proprietario', 'owner')
  );
$$;

CREATE OR REPLACE FUNCTION public.vortex_is_admin_or_owner()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND lower(COALESCE(status, 'ativo')) = 'ativo'
      AND lower(role) IN ('proprietario', 'owner', 'administrador', 'admin')
  );
$$;

CREATE OR REPLACE FUNCTION public.vortex_is_manager_or_above()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND lower(COALESCE(status, 'ativo')) = 'ativo'
      AND lower(role) IN ('proprietario', 'owner', 'administrador', 'admin', 'gerente', 'manager')
  );
$$;

CREATE OR REPLACE FUNCTION public.vortex_has_module_perm(module_key text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND lower(COALESCE(status, 'ativo')) = 'ativo'
      AND (
        lower(role) IN ('proprietario', 'owner')
        OR (
          jsonb_typeof(permissions -> module_key) = 'boolean'
          AND (permissions ->> module_key)::boolean = true
        )
      )
  );
$$;

CREATE OR REPLACE FUNCTION public.vortex_has_lead_access(p_prospect_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT public.vortex_is_active_user()
    AND p_prospect_id IS NOT NULL
    AND (
      public.vortex_is_manager_or_above()
      OR public.vortex_has_module_perm('ver_todos_leads')
      OR (
        public.vortex_has_module_perm('prospeccao')
        AND EXISTS (
          SELECT 1
          FROM public.prospects p
          WHERE p.id = p_prospect_id
            AND (
              p.responsible_id = auth.uid()
              OR (p.responsible_id IS NULL AND p.member_id = auth.uid())
              OR EXISTS (
                SELECT 1
                FROM jsonb_array_elements(
                  CASE
                    WHEN jsonb_typeof(p.participating_collaborators) = 'array' THEN p.participating_collaborators
                    ELSE '[]'::jsonb
                  END
                ) pc
                WHERE pc ->> 'id' = auth.uid()::text
              )
            )
        )
      )
    );
$$;

CREATE OR REPLACE FUNCTION public.vortex_can_edit_lead(p_prospect_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT public.vortex_is_active_user()
    AND p_prospect_id IS NOT NULL
    AND (
      public.vortex_is_manager_or_above()
      OR (
        public.vortex_has_module_perm('prospeccao')
        AND EXISTS (
          SELECT 1
          FROM public.prospects p
          WHERE p.id = p_prospect_id
            AND (
              p.responsible_id = auth.uid()
              OR (p.responsible_id IS NULL AND p.member_id = auth.uid())
            )
        )
      )
    );
$$;

-- Sanitização estrita das permissões permitidas por nível de acesso (anti-escalada)
CREATE OR REPLACE FUNCTION public.vortex_sanitize_permissions(target_role text, raw_perms jsonb)
RETURNS jsonb
LANGUAGE plpgsql
IMMUTABLE
SET search_path = public, pg_temp
AS $$
DECLARE
  norm_role text := CASE
    WHEN lower(COALESCE(target_role, '')) IN ('proprietario', 'owner') THEN 'proprietario'
    WHEN lower(COALESCE(target_role, '')) IN ('administrador', 'admin') THEN 'administrador'
    WHEN lower(COALESCE(target_role, '')) IN ('gerente', 'manager') THEN 'gerente'
    ELSE 'colaborador'
  END;
  src jsonb := CASE WHEN jsonb_typeof(raw_perms) = 'object' THEN raw_perms ELSE '{}'::jsonb END;
  b_dashboard boolean := COALESCE((src ->> 'dashboard')::boolean, true);
  b_prospeccao boolean := COALESCE((src ->> 'prospeccao')::boolean, true);
  b_empresas boolean := COALESCE((src ->> 'empresas')::boolean, true);
  b_comissoes boolean := COALESCE((src ->> 'comissoes')::boolean, true);
  b_financeiro boolean := COALESCE((src ->> 'financeiro')::boolean, false);
  b_marketing boolean := COALESCE((src ->> 'marketing')::boolean, true);
  b_relatorios boolean := COALESCE((src ->> 'relatorios')::boolean, norm_role IN ('administrador', 'gerente'));
  b_equipe boolean := COALESCE((src ->> 'equipe')::boolean, norm_role IN ('administrador', 'gerente'));
  b_configuracoes boolean := COALESCE((src ->> 'configuracoes')::boolean, norm_role = 'administrador');
  b_ver_todos boolean := COALESCE((src ->> 'ver_todos_leads')::boolean, norm_role IN ('administrador', 'gerente'));
  b_distribuir boolean := COALESCE((src ->> 'distribuir_leads')::boolean, norm_role IN ('administrador', 'gerente'));
  b_vis_comissoes boolean := COALESCE((src ->> 'visualizar_comissoes_equipe')::boolean, norm_role IN ('administrador', 'gerente'));
BEGIN
  IF norm_role = 'proprietario' THEN
    RETURN jsonb_build_object(
      'dashboard', true,
      'prospeccao', true,
      'empresas', true,
      'comissoes', true,
      'financeiro', true,
      'marketing', true,
      'relatorios', true,
      'equipe', true,
      'configuracoes', true,
      'ver_todos_leads', true,
      'distribuir_leads', true,
      'visualizar_comissoes_equipe', true
    );
  END IF;

  -- Teto de segurança por cargo: colaborador não pode receber administração de equipe/sistema
  IF norm_role = 'colaborador' THEN
    b_equipe := false;
    b_configuracoes := false;
  ELSIF norm_role = 'gerente' THEN
    b_configuracoes := false;
  END IF;

  RETURN jsonb_build_object(
    'dashboard', b_dashboard,
    'prospeccao', b_prospeccao,
    'empresas', b_empresas,
    'comissoes', b_comissoes,
    'financeiro', b_financeiro,
    'marketing', b_marketing,
    'relatorios', b_relatorios,
    'equipe', b_equipe,
    'configuracoes', b_configuracoes,
    'ver_todos_leads', b_ver_todos,
    'distribuir_leads', b_distribuir,
    'visualizar_comissoes_equipe', b_vis_comissoes
  );
END;
$$;

-- ============================================================================
-- 10. TRIGGERS DE INTEGRIDADE & ANTI-ESCALADA DE PRIVILÉGIOS
-- ============================================================================

-- 10.1 Proteção em public.profiles (impede auto-escalada, edição de terceiros e ataque ao proprietário)
CREATE OR REPLACE FUNCTION public.vortex_prevent_role_escalation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  caller_role text;
  caller_status text;
  claim_id_txt text := NULLIF(current_setting('vortex.claiming_invite_id', true), '');
  claim_inv public.team_invites%ROWTYPE;
  creator_role text;
  creator_status text;
  u_email text;
  norm_new_role text;
BEGIN
  -- Sempre higieniza permissões conforme o teto do cargo
  norm_new_role := CASE
    WHEN lower(COALESCE(NEW.role, '')) IN ('proprietario', 'owner') THEN 'proprietario'
    WHEN lower(COALESCE(NEW.role, '')) IN ('administrador', 'admin') THEN 'administrador'
    WHEN lower(COALESCE(NEW.role, '')) IN ('gerente', 'manager') THEN 'gerente'
    ELSE 'colaborador'
  END;
  NEW.role := norm_new_role;
  NEW.permissions := public.vortex_sanitize_permissions(norm_new_role, NEW.permissions);

  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT lower(role), lower(COALESCE(status, 'ativo'))
    INTO caller_role, caller_status
  FROM public.profiles
  WHERE id = auth.uid();

  IF COALESCE(caller_status, '') <> 'ativo' THEN
    RAISE EXCEPTION 'Usuário inativo não possui permissão para alterar perfis.';
  END IF;

  -- Impede que colaborador/gerente altere qualquer dado de outro colaborador
  IF OLD.id <> auth.uid() AND COALESCE(caller_role, '') NOT IN ('proprietario', 'owner', 'administrador', 'admin') THEN
    RAISE EXCEPTION 'Você não tem permissão para alterar o perfil de outro colaborador.';
  END IF;

  IF (
    OLD.role IS DISTINCT FROM NEW.role
    OR OLD.permissions IS DISTINCT FROM NEW.permissions
    OR OLD.status IS DISTINCT FROM NEW.status
  ) THEN
    -- Fluxo único de exceção controlada: aplicação de pré-cadastro (vortex_claim_team_invite)
    IF NEW.id = auth.uid()
       AND lower(COALESCE(OLD.status, 'ativo')) = 'ativo'
       AND lower(COALESCE(NEW.status, 'ativo')) = 'ativo'
       AND claim_id_txt IS NOT NULL THEN

      SELECT * INTO claim_inv
      FROM public.team_invites
      WHERE id = claim_id_txt::uuid
        AND status = 'pendente'
        AND linked_profile_id IS NULL;

      SELECT email INTO u_email FROM auth.users WHERE id = auth.uid();

      IF claim_inv.id IS NOT NULL
         AND u_email IS NOT NULL
         AND lower(claim_inv.email) = lower(u_email)
         AND claim_inv.created_by IS NOT NULL THEN

        SELECT lower(role), lower(COALESCE(status, 'ativo'))
          INTO creator_role, creator_status
        FROM public.profiles
        WHERE id = claim_inv.created_by;

        IF COALESCE(creator_status, '') = 'ativo'
           AND COALESCE(creator_role, '') IN ('proprietario', 'owner', 'administrador', 'admin')
           AND (
             lower(claim_inv.role) NOT IN ('proprietario', 'owner')
             OR COALESCE(creator_role, '') IN ('proprietario', 'owner')
           )
           AND NEW.role = (
             CASE
               WHEN lower(claim_inv.role) IN ('proprietario', 'owner') THEN 'proprietario'
               WHEN lower(claim_inv.role) IN ('administrador', 'admin') THEN 'administrador'
               WHEN lower(claim_inv.role) IN ('gerente', 'manager') THEN 'gerente'
               ELSE 'colaborador'
             END
           )
           AND NEW.permissions = public.vortex_sanitize_permissions(NEW.role, claim_inv.permissions) THEN
          RETURN NEW;
        END IF;
      END IF;
    END IF;

    -- Qualquer outra alteração de role, permissions ou status exige Proprietário ou Administrador ativo
    IF COALESCE(caller_role, '') NOT IN ('proprietario', 'owner', 'administrador', 'admin') THEN
      RAISE EXCEPTION 'Apenas proprietário ou administrador autorizado podem alterar cargos, status ou permissões.';
    END IF;

    -- Não-proprietário (inclusive administrador) não pode alterar próprio nível, permissões ou status
    IF NEW.id = auth.uid() AND COALESCE(caller_role, '') NOT IN ('proprietario', 'owner') THEN
      RAISE EXCEPTION 'Não é permitido alterar o próprio cargo, status ou conjunto de permissões.';
    END IF;

    -- Somente Proprietário pode modificar um Proprietário ou promover alguém a Proprietário
    IF lower(OLD.role) IN ('proprietario', 'owner') AND COALESCE(caller_role, '') NOT IN ('proprietario', 'owner') THEN
      RAISE EXCEPTION 'Administradores não podem alterar o acesso de um Proprietário.';
    END IF;
    IF lower(NEW.role) IN ('proprietario', 'owner') AND COALESCE(caller_role, '') NOT IN ('proprietario', 'owner') THEN
      RAISE EXCEPTION 'Apenas um Proprietário pode atribuir o nível Proprietário.';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_vortex_prevent_role_escalation'
  ) THEN
    CREATE TRIGGER trg_vortex_prevent_role_escalation
      BEFORE UPDATE ON public.profiles
      FOR EACH ROW
      EXECUTE FUNCTION public.vortex_prevent_role_escalation();
  END IF;
END $$;

-- 10.2 Validação estrita em public.team_invites (impede falsificação de criador, reuso e escalada)
CREATE OR REPLACE FUNCTION public.vortex_validate_team_invite()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  norm_role text;
  claim_id_txt text := NULLIF(current_setting('vortex.claiming_invite_id', true), '');
BEGIN
  norm_role := CASE
    WHEN lower(COALESCE(NEW.role, '')) IN ('proprietario', 'owner') THEN 'proprietario'
    WHEN lower(COALESCE(NEW.role, '')) IN ('administrador', 'admin') THEN 'administrador'
    WHEN lower(COALESCE(NEW.role, '')) IN ('gerente', 'manager') THEN 'gerente'
    ELSE 'colaborador'
  END;
  NEW.role := norm_role;
  NEW.email := lower(trim(COALESCE(NEW.email, '')));
  NEW.permissions := public.vortex_sanitize_permissions(norm_role, NEW.permissions);

  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  IF TG_OP = 'INSERT' THEN
    IF NOT public.vortex_is_admin_or_owner() THEN
      RAISE EXCEPTION 'Apenas proprietário ou administrador ativo pode criar convites.';
    END IF;
    IF NEW.role = 'proprietario' AND NOT public.vortex_is_owner() THEN
      RAISE EXCEPTION 'Apenas um Proprietário pode criar convite com nível Proprietário.';
    END IF;
    NEW.created_by := auth.uid();
    NEW.status := CASE WHEN NEW.linked_profile_id IS NOT NULL THEN 'vinculado' ELSE 'pendente' END;
    RETURN NEW;
  END IF;

  -- TG_OP = 'UPDATE'
  -- Permite finalização legítima pela própria RPC vortex_claim_team_invite()
  IF claim_id_txt IS NOT NULL
     AND claim_id_txt = OLD.id::text
     AND OLD.status = 'pendente'
     AND OLD.linked_profile_id IS NULL
     AND NEW.status = 'vinculado'
     AND NEW.linked_profile_id = auth.uid()
     AND NEW.role IS NOT DISTINCT FROM OLD.role
     AND NEW.permissions IS NOT DISTINCT FROM OLD.permissions
     AND NEW.email = OLD.email
     AND NEW.created_by IS NOT DISTINCT FROM OLD.created_by THEN
    RETURN NEW;
  END IF;

  IF NOT public.vortex_is_admin_or_owner() THEN
    RAISE EXCEPTION 'Apenas proprietário ou administrador ativo pode alterar ou cancelar convites.';
  END IF;

  IF (OLD.role = 'proprietario' OR NEW.role = 'proprietario') AND NOT public.vortex_is_owner() THEN
    RAISE EXCEPTION 'Apenas um Proprietário pode gerenciar convites de nível Proprietário.';
  END IF;

  -- Impede reativar ou reutilizar convite já vinculado a um perfil
  IF OLD.status = 'vinculado' AND (
    NEW.status = 'pendente'
    OR NEW.linked_profile_id IS DISTINCT FROM OLD.linked_profile_id
    OR NEW.email IS DISTINCT FROM OLD.email
  ) THEN
    RAISE EXCEPTION 'Convites já vinculados não podem ser reutilizados ou reabertos.';
  END IF;

  NEW.created_by := OLD.created_by;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_vortex_validate_team_invite ON public.team_invites;
CREATE TRIGGER trg_vortex_validate_team_invite
  BEFORE INSERT OR UPDATE ON public.team_invites
  FOR EACH ROW
  EXECUTE FUNCTION public.vortex_validate_team_invite();

-- 10.3 Consistência obrigatória de distribuição de leads (prospects <-> lead_assignments_history)
CREATE OR REPLACE FUNCTION public.vortex_validate_prospect_assignment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  IF OLD.responsible_id IS DISTINCT FROM NEW.responsible_id THEN
    IF NOT (public.vortex_is_manager_or_above() OR public.vortex_has_module_perm('distribuir_leads')) THEN
      RAISE EXCEPTION 'Você não possui permissão para distribuir ou transferir leads.';
    END IF;
    NEW.assigned_by := auth.uid();
    NEW.assigned_at := COALESCE(NEW.assigned_at, now());
  END IF;

  RETURN NEW;
END;
$$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'prospects') THEN
    DROP TRIGGER IF EXISTS trg_vortex_validate_prospect_assignment ON public.prospects;
    CREATE TRIGGER trg_vortex_validate_prospect_assignment
      BEFORE UPDATE ON public.prospects
      FOR EACH ROW
      EXECUTE FUNCTION public.vortex_validate_prospect_assignment();
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.vortex_validate_assignment_history()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  p_resp uuid;
BEGIN
  IF auth.uid() IS NOT NULL THEN
    IF NOT (public.vortex_is_manager_or_above() OR public.vortex_has_module_perm('distribuir_leads')) THEN
      RAISE EXCEPTION 'Somente usuários autorizados (distribuir_leads ou gestão) podem registrar distribuição de leads.';
    END IF;
    NEW.assigned_by := auth.uid();
  END IF;

  SELECT responsible_id INTO p_resp
  FROM public.prospects
  WHERE id = NEW.prospect_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Lead informado no histórico de distribuição não existe.';
  END IF;

  -- Impede inserção isolada no histórico divergente do responsável atual no prospect
  IF p_resp IS DISTINCT FROM NEW.new_responsible_id THEN
    RAISE EXCEPTION 'Inconsistência na distribuição: atualize primeiro o responsável do lead antes de registrar o histórico.';
  END IF;

  NEW.created_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_vortex_validate_assignment_history ON public.lead_assignments_history;
CREATE TRIGGER trg_vortex_validate_assignment_history
  BEFORE INSERT ON public.lead_assignments_history
  FOR EACH ROW
  EXECUTE FUNCTION public.vortex_validate_assignment_history();

CREATE OR REPLACE FUNCTION public.vortex_block_immutable_assignment_history()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
BEGIN
  RAISE EXCEPTION 'O histórico de atribuições e transferências de leads é imutável.';
END;
$$;

DROP TRIGGER IF EXISTS trg_vortex_immutable_assignment_history ON public.lead_assignments_history;
CREATE TRIGGER trg_vortex_immutable_assignment_history
  BEFORE UPDATE OR DELETE ON public.lead_assignments_history
  FOR EACH ROW
  EXECUTE FUNCTION public.vortex_block_immutable_assignment_history();

-- ============================================================================
-- 11. RPC SEGURA DE VÍNCULO DE CONVITE (vortex_claim_team_invite)
-- ============================================================================

CREATE OR REPLACE FUNCTION public.vortex_claim_team_invite()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  u_id uuid := auth.uid();
  u_email text;
  caller_status text;
  caller_role text;
  inv public.team_invites%ROWTYPE;
  creator_role text;
  creator_status text;
  norm_role text;
  sanitized_perms jsonb;
  updated_profile_rows integer := 0;
BEGIN
  IF u_id IS NULL THEN
    RETURN jsonb_build_object('claimed', false, 'reason', 'unauthenticated');
  END IF;

  SELECT lower(COALESCE(status, 'ativo')), lower(COALESCE(role, 'colaborador'))
    INTO caller_status, caller_role
  FROM public.profiles
  WHERE id = u_id;

  IF NOT FOUND OR caller_status <> 'ativo' THEN
    RETURN jsonb_build_object('claimed', false, 'reason', 'inactive_or_missing_profile');
  END IF;

  -- Nunca rebaixa ou sobrescreve um Proprietário já ativo via convite pendente
  IF caller_role IN ('proprietario', 'owner') THEN
    RETURN jsonb_build_object('claimed', false, 'reason', 'already_owner');
  END IF;

  SELECT email INTO u_email FROM auth.users WHERE id = u_id;
  IF u_email IS NULL OR trim(u_email) = '' THEN
    RETURN jsonb_build_object('claimed', false, 'reason', 'missing_auth_email');
  END IF;

  -- Bloqueia linha pendente para evitar condição de corrida / reuso
  SELECT * INTO inv
  FROM public.team_invites
  WHERE lower(email) = lower(u_email)
    AND status = 'pendente'
    AND linked_profile_id IS NULL
  ORDER BY created_at DESC
  LIMIT 1
  FOR UPDATE SKIP LOCKED;

  IF inv.id IS NULL THEN
    RETURN jsonb_build_object('claimed', false);
  END IF;

  -- Confirma que o convite foi criado por proprietário/administrador ativo e autorizado
  IF inv.created_by IS NULL THEN
    RETURN jsonb_build_object('claimed', false, 'reason', 'missing_creator');
  END IF;

  SELECT lower(role), lower(COALESCE(status, 'ativo'))
    INTO creator_role, creator_status
  FROM public.profiles
  WHERE id = inv.created_by;

  IF COALESCE(creator_status, '') <> 'ativo'
     OR COALESCE(creator_role, '') NOT IN ('proprietario', 'owner', 'administrador', 'admin') THEN
    RETURN jsonb_build_object('claimed', false, 'reason', 'unauthorized_invite_creator');
  END IF;

  norm_role := CASE
    WHEN lower(COALESCE(inv.role, '')) IN ('proprietario', 'owner') THEN 'proprietario'
    WHEN lower(COALESCE(inv.role, '')) IN ('administrador', 'admin') THEN 'administrador'
    WHEN lower(COALESCE(inv.role, '')) IN ('gerente', 'manager') THEN 'gerente'
    ELSE 'colaborador'
  END;

  -- Impede promoção a proprietário sem criação explícita por um proprietário ativo
  IF norm_role = 'proprietario' AND COALESCE(creator_role, '') NOT IN ('proprietario', 'owner') THEN
    RETURN jsonb_build_object('claimed', false, 'reason', 'owner_authorization_required');
  END IF;

  sanitized_perms := public.vortex_sanitize_permissions(norm_role, inv.permissions);

  -- Habilita verificação controlada na trigger somente nesta transação para este convite
  PERFORM set_config('vortex.claiming_invite_id', inv.id::text, true);

  UPDATE public.profiles
  SET
    full_name = COALESCE(NULLIF(inv.full_name, ''), full_name),
    phone = COALESCE(inv.phone, phone),
    role = norm_role,
    job_title = COALESCE(NULLIF(inv.job_title, ''), job_title),
    department = COALESCE(inv.department, department),
    responsibilities = COALESCE(inv.responsibilities, responsibilities),
    entry_date = COALESCE(inv.entry_date, entry_date),
    avatar_url = COALESCE(inv.avatar_url, avatar_url),
    permissions = sanitized_perms,
    linked_auth_email = u_email,
    updated_at = now()
  WHERE id = u_id
    AND lower(COALESCE(status, 'ativo')) = 'ativo';

  GET DIAGNOSTICS updated_profile_rows = ROW_COUNT;

  IF updated_profile_rows <> 1 THEN
    PERFORM set_config('vortex.claiming_invite_id', '', true);
    RETURN jsonb_build_object('claimed', false, 'reason', 'profile_update_failed');
  END IF;

  -- Marca convite como vinculado somente após atualização bem-sucedida do perfil
  UPDATE public.team_invites
  SET
    status = 'vinculado',
    linked_profile_id = u_id,
    updated_at = now()
  WHERE id = inv.id
    AND status = 'pendente'
    AND linked_profile_id IS NULL;

  PERFORM set_config('vortex.claiming_invite_id', '', true);
  RETURN jsonb_build_object('claimed', true, 'invite_id', inv.id);
END;
$$;

-- ============================================================================
-- 12. RLS GRANULAR (SELECT / INSERT / UPDATE / DELETE) NAS TABELAS DA 004
-- ============================================================================

ALTER TABLE public.prospect_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commercial_proposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_assignments_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sale_collaborators ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.team_invites ENABLE ROW LEVEL SECURITY;

-- 12.1 prospect_activities
DROP POLICY IF EXISTS vortex_activities_select ON public.prospect_activities;
DROP POLICY IF EXISTS vortex_activities_write ON public.prospect_activities;
DROP POLICY IF EXISTS vortex_activities_insert ON public.prospect_activities;
DROP POLICY IF EXISTS vortex_activities_update ON public.prospect_activities;
DROP POLICY IF EXISTS vortex_activities_delete ON public.prospect_activities;

CREATE POLICY vortex_activities_select ON public.prospect_activities
  FOR SELECT TO authenticated
  USING (
    public.vortex_is_manager_or_above()
    OR public.vortex_has_module_perm('ver_todos_leads')
    OR (
      public.vortex_has_module_perm('prospeccao')
      AND (
        responsible_id = auth.uid()
        OR created_by = auth.uid()
        OR public.vortex_has_lead_access(prospect_id)
      )
    )
  );

CREATE POLICY vortex_activities_insert ON public.prospect_activities
  FOR INSERT TO authenticated
  WITH CHECK (
    public.vortex_is_active_user()
    AND (created_by IS NULL OR created_by = auth.uid())
    AND (
      public.vortex_is_manager_or_above()
      OR (
        public.vortex_has_module_perm('prospeccao')
        AND public.vortex_can_edit_lead(prospect_id)
        AND (responsible_id IS NULL OR responsible_id = auth.uid())
      )
    )
  );

CREATE POLICY vortex_activities_update ON public.prospect_activities
  FOR UPDATE TO authenticated
  USING (
    public.vortex_is_manager_or_above()
    OR (
      public.vortex_has_module_perm('prospeccao')
      AND (
        responsible_id = auth.uid()
        OR created_by = auth.uid()
        OR public.vortex_can_edit_lead(prospect_id)
      )
    )
  )
  WITH CHECK (
    public.vortex_is_manager_or_above()
    OR (
      public.vortex_has_module_perm('prospeccao')
      AND (
        responsible_id = auth.uid()
        OR created_by = auth.uid()
        OR public.vortex_can_edit_lead(prospect_id)
      )
    )
  );

CREATE POLICY vortex_activities_delete ON public.prospect_activities
  FOR DELETE TO authenticated
  USING (
    public.vortex_is_manager_or_above()
    OR (
      public.vortex_has_module_perm('prospeccao')
      AND (
        created_by = auth.uid()
        OR responsible_id = auth.uid()
        OR public.vortex_can_edit_lead(prospect_id)
      )
    )
  );

-- 12.2 commercial_proposals
DROP POLICY IF EXISTS vortex_proposals_select ON public.commercial_proposals;
DROP POLICY IF EXISTS vortex_proposals_write ON public.commercial_proposals;
DROP POLICY IF EXISTS vortex_proposals_insert ON public.commercial_proposals;
DROP POLICY IF EXISTS vortex_proposals_update ON public.commercial_proposals;
DROP POLICY IF EXISTS vortex_proposals_delete ON public.commercial_proposals;

CREATE POLICY vortex_proposals_select ON public.commercial_proposals
  FOR SELECT TO authenticated
  USING (
    public.vortex_is_manager_or_above()
    OR public.vortex_has_module_perm('ver_todos_leads')
    OR (
      public.vortex_has_module_perm('prospeccao')
      AND (
        responsible_id = auth.uid()
        OR public.vortex_has_lead_access(prospect_id)
      )
    )
  );

CREATE POLICY vortex_proposals_insert ON public.commercial_proposals
  FOR INSERT TO authenticated
  WITH CHECK (
    public.vortex_is_active_user()
    AND (
      public.vortex_is_manager_or_above()
      OR (
        public.vortex_has_module_perm('prospeccao')
        AND public.vortex_can_edit_lead(prospect_id)
        AND (responsible_id IS NULL OR responsible_id = auth.uid())
      )
    )
  );

CREATE POLICY vortex_proposals_update ON public.commercial_proposals
  FOR UPDATE TO authenticated
  USING (
    public.vortex_is_manager_or_above()
    OR (
      public.vortex_has_module_perm('prospeccao')
      AND (
        responsible_id = auth.uid()
        OR public.vortex_can_edit_lead(prospect_id)
      )
    )
  )
  WITH CHECK (
    public.vortex_is_manager_or_above()
    OR (
      public.vortex_has_module_perm('prospeccao')
      AND (
        responsible_id = auth.uid()
        OR public.vortex_can_edit_lead(prospect_id)
      )
    )
  );

CREATE POLICY vortex_proposals_delete ON public.commercial_proposals
  FOR DELETE TO authenticated
  USING (
    public.vortex_is_manager_or_above()
    OR (
      public.vortex_has_module_perm('prospeccao')
      AND (
        responsible_id = auth.uid()
        OR public.vortex_can_edit_lead(prospect_id)
      )
    )
  );

-- 12.3 lead_assignments_history (somente SELECT e INSERT autorizado; imutável)
DROP POLICY IF EXISTS vortex_assignments_select ON public.lead_assignments_history;
DROP POLICY IF EXISTS vortex_assignments_insert ON public.lead_assignments_history;

CREATE POLICY vortex_assignments_select ON public.lead_assignments_history
  FOR SELECT TO authenticated
  USING (
    public.vortex_is_manager_or_above()
    OR public.vortex_has_module_perm('ver_todos_leads')
    OR new_responsible_id = auth.uid()
    OR previous_responsible_id = auth.uid()
    OR assigned_by = auth.uid()
  );

CREATE POLICY vortex_assignments_insert ON public.lead_assignments_history
  FOR INSERT TO authenticated
  WITH CHECK (
    public.vortex_is_active_user()
    AND (assigned_by IS NULL OR assigned_by = auth.uid())
    AND (
      public.vortex_is_manager_or_above()
      OR public.vortex_has_module_perm('distribuir_leads')
    )
  );

-- 12.4 sale_collaborators (participantes de venda e vínculo com comissões)
DROP POLICY IF EXISTS vortex_sale_collabs_select ON public.sale_collaborators;
DROP POLICY IF EXISTS vortex_sale_collabs_write ON public.sale_collaborators;
DROP POLICY IF EXISTS vortex_sale_collabs_insert ON public.sale_collaborators;
DROP POLICY IF EXISTS vortex_sale_collabs_update ON public.sale_collaborators;
DROP POLICY IF EXISTS vortex_sale_collabs_delete ON public.sale_collaborators;

CREATE POLICY vortex_sale_collabs_select ON public.sale_collaborators
  FOR SELECT TO authenticated
  USING (
    public.vortex_is_manager_or_above()
    OR public.vortex_has_module_perm('visualizar_comissoes_equipe')
    OR collaborator_id = auth.uid()
    OR (
      public.vortex_has_module_perm('comissoes')
      AND prospect_id IS NOT NULL
      AND public.vortex_can_edit_lead(prospect_id)
    )
  );

CREATE POLICY vortex_sale_collabs_insert ON public.sale_collaborators
  FOR INSERT TO authenticated
  WITH CHECK (
    public.vortex_is_active_user()
    AND (
      public.vortex_is_manager_or_above()
      OR public.vortex_has_module_perm('distribuir_leads')
      OR (
        public.vortex_has_module_perm('prospeccao')
        AND public.vortex_has_module_perm('empresas')
        AND prospect_id IS NOT NULL
        AND public.vortex_can_edit_lead(prospect_id)
      )
    )
  );

CREATE POLICY vortex_sale_collabs_update ON public.sale_collaborators
  FOR UPDATE TO authenticated
  USING (public.vortex_is_manager_or_above())
  WITH CHECK (public.vortex_is_manager_or_above());

CREATE POLICY vortex_sale_collabs_delete ON public.sale_collaborators
  FOR DELETE TO authenticated
  USING (public.vortex_is_admin_or_owner());

-- 12.5 team_invites (somente proprietário/administrador podem criar, alterar ou cancelar)
DROP POLICY IF EXISTS vortex_invites_admin_all ON public.team_invites;
DROP POLICY IF EXISTS vortex_invites_self_read ON public.team_invites;
DROP POLICY IF EXISTS vortex_invites_select ON public.team_invites;
DROP POLICY IF EXISTS vortex_invites_insert ON public.team_invites;
DROP POLICY IF EXISTS vortex_invites_update ON public.team_invites;
DROP POLICY IF EXISTS vortex_invites_delete ON public.team_invites;

CREATE POLICY vortex_invites_select ON public.team_invites
  FOR SELECT TO authenticated
  USING (
    public.vortex_is_admin_or_owner()
    OR (public.vortex_is_manager_or_above() AND public.vortex_has_module_perm('equipe'))
    OR lower(email) = lower(COALESCE(auth.jwt() ->> 'email', ''))
  );

CREATE POLICY vortex_invites_insert ON public.team_invites
  FOR INSERT TO authenticated
  WITH CHECK (
    public.vortex_is_admin_or_owner()
    AND (created_by IS NULL OR created_by = auth.uid())
    AND (
      lower(COALESCE(role, 'colaborador')) NOT IN ('proprietario', 'owner')
      OR public.vortex_is_owner()
    )
  );

CREATE POLICY vortex_invites_update ON public.team_invites
  FOR UPDATE TO authenticated
  USING (
    public.vortex_is_admin_or_owner()
    AND (
      lower(COALESCE(role, 'colaborador')) NOT IN ('proprietario', 'owner')
      OR public.vortex_is_owner()
    )
  )
  WITH CHECK (
    public.vortex_is_admin_or_owner()
    AND (
      lower(COALESCE(role, 'colaborador')) NOT IN ('proprietario', 'owner')
      OR public.vortex_is_owner()
    )
  );

CREATE POLICY vortex_invites_delete ON public.team_invites
  FOR DELETE TO authenticated
  USING (
    public.vortex_is_admin_or_owner()
    AND (
      lower(COALESCE(role, 'colaborador')) NOT IN ('proprietario', 'owner')
      OR public.vortex_is_owner()
    )
  );

-- ============================================================================
-- 13. POLÍTICAS RESTRITIVAS COMPLEMENTARES EM TABELAS EXISTENTES (DEFENSE-IN-DEPTH)
-- ============================================================================
-- Aplicadas com segurança apenas quando a tabela já possui RLS e políticas
-- permissivas ativas, garantindo que nunca quebrem configurações anteriores.

DO $$
DECLARE
  has_rls boolean;
  has_perm boolean;
BEGIN
  -- 13.1 public.prospects
  SELECT c.relrowsecurity,
         EXISTS (SELECT 1 FROM pg_policies p WHERE p.schemaname = 'public' AND p.tablename = 'prospects' AND p.permissive = 'PERMISSIVE')
    INTO has_rls, has_perm
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relname = 'prospects';

  IF COALESCE(has_rls, false) AND COALESCE(has_perm, false) THEN
    DROP POLICY IF EXISTS vortex_prospects_restrict_select ON public.prospects;
    DROP POLICY IF EXISTS vortex_prospects_restrict_insert ON public.prospects;
    DROP POLICY IF EXISTS vortex_prospects_restrict_update ON public.prospects;
    DROP POLICY IF EXISTS vortex_prospects_restrict_delete ON public.prospects;

    CREATE POLICY vortex_prospects_restrict_select ON public.prospects
      AS RESTRICTIVE FOR SELECT TO authenticated
      USING (
        public.vortex_is_manager_or_above()
        OR public.vortex_has_module_perm('ver_todos_leads')
        OR (
          public.vortex_has_module_perm('prospeccao')
          AND (
            responsible_id = auth.uid()
            OR (responsible_id IS NULL AND member_id = auth.uid())
            OR EXISTS (
              SELECT 1
              FROM jsonb_array_elements(
                CASE
                  WHEN jsonb_typeof(participating_collaborators) = 'array' THEN participating_collaborators
                  ELSE '[]'::jsonb
                END
              ) pc
              WHERE pc ->> 'id' = auth.uid()::text
            )
          )
        )
      );

    CREATE POLICY vortex_prospects_restrict_insert ON public.prospects
      AS RESTRICTIVE FOR INSERT TO authenticated
      WITH CHECK (
        public.vortex_is_manager_or_above()
        OR (
          public.vortex_has_module_perm('prospeccao')
          AND (member_id = auth.uid() OR created_by = auth.uid())
          AND (
            responsible_id IS NULL
            OR responsible_id = auth.uid()
            OR public.vortex_has_module_perm('distribuir_leads')
          )
        )
      );

    CREATE POLICY vortex_prospects_restrict_update ON public.prospects
      AS RESTRICTIVE FOR UPDATE TO authenticated
      USING (
        public.vortex_is_manager_or_above()
        OR (
          public.vortex_has_module_perm('prospeccao')
          AND (
            responsible_id = auth.uid()
            OR (responsible_id IS NULL AND member_id = auth.uid())
          )
        )
      )
      WITH CHECK (
        public.vortex_is_manager_or_above()
        OR (
          public.vortex_has_module_perm('prospeccao')
          AND (
            responsible_id = auth.uid()
            OR (responsible_id IS NULL AND member_id = auth.uid())
            OR public.vortex_has_module_perm('distribuir_leads')
          )
        )
      );

    CREATE POLICY vortex_prospects_restrict_delete ON public.prospects
      AS RESTRICTIVE FOR DELETE TO authenticated
      USING (
        public.vortex_is_manager_or_above()
        OR (
          public.vortex_has_module_perm('prospeccao')
          AND (
            responsible_id = auth.uid()
            OR (responsible_id IS NULL AND member_id = auth.uid())
          )
        )
      );
  END IF;

  -- 13.2 public.prospect_interactions
  SELECT c.relrowsecurity,
         EXISTS (SELECT 1 FROM pg_policies p WHERE p.schemaname = 'public' AND p.tablename = 'prospect_interactions' AND p.permissive = 'PERMISSIVE')
    INTO has_rls, has_perm
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relname = 'prospect_interactions';

  IF COALESCE(has_rls, false) AND COALESCE(has_perm, false) THEN
    DROP POLICY IF EXISTS vortex_interactions_restrict_select ON public.prospect_interactions;
    DROP POLICY IF EXISTS vortex_interactions_restrict_write ON public.prospect_interactions;

    CREATE POLICY vortex_interactions_restrict_select ON public.prospect_interactions
      AS RESTRICTIVE FOR SELECT TO authenticated
      USING (
        public.vortex_is_manager_or_above()
        OR public.vortex_has_module_perm('ver_todos_leads')
        OR (
          public.vortex_has_module_perm('prospeccao')
          AND (
            responsible_id = auth.uid()
            OR public.vortex_has_lead_access(prospect_id)
          )
        )
      );

    CREATE POLICY vortex_interactions_restrict_write ON public.prospect_interactions
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (
        public.vortex_is_manager_or_above()
        OR (
          public.vortex_has_module_perm('prospeccao')
          AND public.vortex_can_edit_lead(prospect_id)
        )
      )
      WITH CHECK (
        public.vortex_is_manager_or_above()
        OR (
          public.vortex_has_module_perm('prospeccao')
          AND public.vortex_can_edit_lead(prospect_id)
        )
      );
  END IF;

  -- 13.3 public.commissions
  SELECT c.relrowsecurity,
         EXISTS (SELECT 1 FROM pg_policies p WHERE p.schemaname = 'public' AND p.tablename = 'commissions' AND p.permissive = 'PERMISSIVE')
    INTO has_rls, has_perm
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relname = 'commissions';

  IF COALESCE(has_rls, false) AND COALESCE(has_perm, false) THEN
    DROP POLICY IF EXISTS vortex_commissions_restrict_select ON public.commissions;
    DROP POLICY IF EXISTS vortex_commissions_restrict_insert ON public.commissions;
    DROP POLICY IF EXISTS vortex_commissions_restrict_update ON public.commissions;
    DROP POLICY IF EXISTS vortex_commissions_restrict_delete ON public.commissions;

    CREATE POLICY vortex_commissions_restrict_select ON public.commissions
      AS RESTRICTIVE FOR SELECT TO authenticated
      USING (
        public.vortex_is_manager_or_above()
        OR public.vortex_has_module_perm('visualizar_comissoes_equipe')
        OR (
          public.vortex_has_module_perm('comissoes')
          AND collaborator_id = auth.uid()
        )
      );

    CREATE POLICY vortex_commissions_restrict_insert ON public.commissions
      AS RESTRICTIVE FOR INSERT TO authenticated
      WITH CHECK (
        public.vortex_is_manager_or_above()
        OR (
          public.vortex_has_module_perm('comissoes')
          AND lower(COALESCE(status, 'prevista')) IN ('prevista', 'pendente')
          AND (
            collaborator_id = auth.uid()
            OR (prospect_id IS NOT NULL AND public.vortex_can_edit_lead(prospect_id))
          )
        )
      );

    CREATE POLICY vortex_commissions_restrict_update ON public.commissions
      AS RESTRICTIVE FOR UPDATE TO authenticated
      USING (public.vortex_is_manager_or_above())
      WITH CHECK (public.vortex_is_manager_or_above());

    CREATE POLICY vortex_commissions_restrict_delete ON public.commissions
      AS RESTRICTIVE FOR DELETE TO authenticated
      USING (public.vortex_is_admin_or_owner());
  END IF;

  -- 13.4 public.payments (módulo financeiro)
  SELECT c.relrowsecurity,
         EXISTS (SELECT 1 FROM pg_policies p WHERE p.schemaname = 'public' AND p.tablename = 'payments' AND p.permissive = 'PERMISSIVE')
    INTO has_rls, has_perm
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relname = 'payments';

  IF COALESCE(has_rls, false) AND COALESCE(has_perm, false) THEN
    DROP POLICY IF EXISTS vortex_payments_restrict_finance ON public.payments;
    CREATE POLICY vortex_payments_restrict_finance ON public.payments
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (public.vortex_is_admin_or_owner() OR public.vortex_has_module_perm('financeiro'))
      WITH CHECK (public.vortex_is_admin_or_owner() OR public.vortex_has_module_perm('financeiro'));
  END IF;

  -- 13.5 public.expenses (módulo financeiro)
  SELECT c.relrowsecurity,
         EXISTS (SELECT 1 FROM pg_policies p WHERE p.schemaname = 'public' AND p.tablename = 'expenses' AND p.permissive = 'PERMISSIVE')
    INTO has_rls, has_perm
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relname = 'expenses';

  IF COALESCE(has_rls, false) AND COALESCE(has_perm, false) THEN
    DROP POLICY IF EXISTS vortex_expenses_restrict_finance ON public.expenses;
    CREATE POLICY vortex_expenses_restrict_finance ON public.expenses
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (public.vortex_is_admin_or_owner() OR public.vortex_has_module_perm('financeiro'))
      WITH CHECK (public.vortex_is_admin_or_owner() OR public.vortex_has_module_perm('financeiro'));
  END IF;
END $$;

-- ============================================================================
-- 14. STORAGE BUCKET "avatars" COM ISOLAMENTO POR PASTA / PROPRIETÁRIO
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'storage' AND table_name = 'buckets') THEN
    INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
    VALUES (
      'avatars',
      'avatars',
      true,
      3145728,
      ARRAY['image/png', 'image/jpeg', 'image/webp', 'image/gif']
    )
    ON CONFLICT (id) DO UPDATE SET
      file_size_limit = COALESCE(storage.buckets.file_size_limit, 3145728),
      allowed_mime_types = COALESCE(storage.buckets.allowed_mime_types, ARRAY['image/png', 'image/jpeg', 'image/webp', 'image/gif']);
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'storage' AND table_name = 'objects') THEN
    DROP POLICY IF EXISTS vortex_avatars_public_read ON storage.objects;
    DROP POLICY IF EXISTS vortex_avatars_auth_insert ON storage.objects;
    DROP POLICY IF EXISTS vortex_avatars_auth_update ON storage.objects;
    DROP POLICY IF EXISTS vortex_avatars_auth_delete ON storage.objects;

    -- Leitura necessária para exibição das fotos dos colaboradores na interface
    CREATE POLICY vortex_avatars_public_read ON storage.objects
      FOR SELECT
      USING (bucket_id = 'avatars');

    -- Upload permitido apenas na própria pasta (<user_id>/...) ou por Proprietário/Administrador
    CREATE POLICY vortex_avatars_auth_insert ON storage.objects
      FOR INSERT TO authenticated
      WITH CHECK (
        bucket_id = 'avatars'
        AND (
          (storage.foldername(name))[1] = auth.uid()::text
          OR public.vortex_is_admin_or_owner()
        )
      );

    -- Impede que qualquer usuário sobrescreva fotos de terceiros
    CREATE POLICY vortex_avatars_auth_update ON storage.objects
      FOR UPDATE TO authenticated
      USING (
        bucket_id = 'avatars'
        AND (
          owner = auth.uid()
          OR (storage.foldername(name))[1] = auth.uid()::text
          OR public.vortex_is_admin_or_owner()
        )
      )
      WITH CHECK (
        bucket_id = 'avatars'
        AND (
          (storage.foldername(name))[1] = auth.uid()::text
          OR public.vortex_is_admin_or_owner()
        )
      );

    CREATE POLICY vortex_avatars_auth_delete ON storage.objects
      FOR DELETE TO authenticated
      USING (
        bucket_id = 'avatars'
        AND (
          owner = auth.uid()
          OR (storage.foldername(name))[1] = auth.uid()::text
          OR public.vortex_is_admin_or_owner()
        )
      );
  END IF;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
-- 15. MENOR PRIVILÉGIO NAS PERMISSÕES EXECUTE DAS FUNÇÕES
-- ============================================================================

REVOKE ALL ON FUNCTION public.vortex_is_active_user() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_current_role() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_is_owner() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_is_admin_or_owner() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_is_manager_or_above() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_has_module_perm(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_has_lead_access(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_can_edit_lead(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_sanitize_permissions(text, jsonb) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_claim_team_invite() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_prevent_role_escalation() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_validate_team_invite() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_validate_prospect_assignment() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_validate_assignment_history() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.vortex_block_immutable_assignment_history() FROM PUBLIC, anon;

GRANT EXECUTE ON FUNCTION public.vortex_is_active_user() TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_current_role() TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_is_owner() TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_is_admin_or_owner() TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_is_manager_or_above() TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_has_module_perm(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_has_lead_access(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_can_edit_lead(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_sanitize_permissions(text, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.vortex_claim_team_invite() TO authenticated;

-- Atualiza o schema cache do Supabase / PostgREST
NOTIFY pgrst, 'reload schema';
