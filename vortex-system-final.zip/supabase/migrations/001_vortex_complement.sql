-- ============================================================================
-- VORTEX SYSTEM — MIGRAÇÃO COMPLEMENTAR NÃO DESTRUTIVA
-- ============================================================================
-- IMPORTANTE:
-- 1. Este script NÃO apaga tabelas, NÃO remove colunas e NÃO altera dados.
-- 2. Utilize este arquivo apenas no SQL Editor do Supabase caso alguma tabela
--    ou coluna complementar ainda não exista no seu projeto atual.
-- 3. Nenhuma política RLS existente é sobrescrita.
-- ============================================================================

-- 1. Complemento seguro na tabela profiles (se faltar alguma coluna)
ALTER TABLE IF EXISTS public.profiles
  ADD COLUMN IF NOT EXISTS full_name text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS role text DEFAULT 'colaborador',
  ADD COLUMN IF NOT EXISTS job_title text,
  ADD COLUMN IF NOT EXISTS permissions jsonb DEFAULT '{"dashboard":true,"prospeccao":true,"empresas":true,"comissoes":true,"financeiro":false,"marketing":true,"relatorios":false,"equipe":false,"configuracoes":false}'::jsonb,
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'ativo',
  ADD COLUMN IF NOT EXISTS avatar_url text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- 2. Tabela prospects (caso ainda não exista)
CREATE TABLE IF NOT EXISTS public.prospects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  contact_name text NOT NULL,
  phone text,
  whatsapp text,
  email text,
  city text,
  segment text,
  instagram text,
  website text,
  origin text,
  responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  responsible_name text,
  notes text,
  contact_date date,
  first_contact_date date,
  next_contact_date date,
  status text NOT NULL DEFAULT 'novo',
  converted_company_id uuid,
  converted_at timestamptz,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 3. Tabela prospect_interactions (histórico individual permanente)
CREATE TABLE IF NOT EXISTS public.prospect_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid NOT NULL REFERENCES public.prospects(id) ON DELETE CASCADE,
  company_id uuid,
  contact_at timestamptz NOT NULL DEFAULT now(),
  contact_type text NOT NULL DEFAULT 'whatsapp',
  summary text NOT NULL,
  responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  responsible_name text,
  outcome text,
  next_action text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 4. Complemento seguro na tabela companies
ALTER TABLE IF EXISTS public.companies
  ADD COLUMN IF NOT EXISTS name text,
  ADD COLUMN IF NOT EXISTS contact_name text,
  ADD COLUMN IF NOT EXISTS phone text,
  ADD COLUMN IF NOT EXISTS whatsapp text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS cnpj text,
  ADD COLUMN IF NOT EXISTS city text,
  ADD COLUMN IF NOT EXISTS segment text,
  ADD COLUMN IF NOT EXISTS entry_date date DEFAULT CURRENT_DATE,
  ADD COLUMN IF NOT EXISTS contracted_service text DEFAULT 'outros',
  ADD COLUMN IF NOT EXISTS contract_value numeric(12,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS responsible_name text,
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'ativo',
  ADD COLUMN IF NOT EXISTS origin text,
  ADD COLUMN IF NOT EXISTS prospect_id uuid,
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- 5. Complemento seguro na tabela commissions
ALTER TABLE IF EXISTS public.commissions
  ADD COLUMN IF NOT EXISTS collaborator_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS collaborator_name text,
  ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS company_name text,
  ADD COLUMN IF NOT EXISTS prospect_id uuid,
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS sale_value numeric(12,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS commission_percentage numeric(5,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS commission_value numeric(12,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'pendente',
  ADD COLUMN IF NOT EXISTS paid_at date,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- 6. Complemento seguro na tabela payments (receitas)
ALTER TABLE IF EXISTS public.payments
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS company_name text,
  ADD COLUMN IF NOT EXISTS amount numeric(12,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS payment_date date DEFAULT CURRENT_DATE,
  ADD COLUMN IF NOT EXISTS category text DEFAULT 'mensalidade',
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'recebido',
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- 7. Complemento seguro na tabela expenses (despesas)
ALTER TABLE IF EXISTS public.expenses
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS category text DEFAULT 'operacional',
  ADD COLUMN IF NOT EXISTS amount numeric(12,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS expense_date date DEFAULT CURRENT_DATE,
  ADD COLUMN IF NOT EXISTS responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS responsible_name text,
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- 8. Complemento seguro na tabela marketing_tasks
ALTER TABLE IF EXISTS public.marketing_tasks
  ADD COLUMN IF NOT EXISTS title text,
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS category text DEFAULT 'marketing',
  ADD COLUMN IF NOT EXISTS responsible_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS responsible_name text,
  ADD COLUMN IF NOT EXISTS due_date date,
  ADD COLUMN IF NOT EXISTS priority text DEFAULT 'media',
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'pendente',
  ADD COLUMN IF NOT EXISTS completed_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- 9. Tabela system_settings (configurações gerais da organização)
CREATE TABLE IF NOT EXISTS public.system_settings (
  id text PRIMARY KEY DEFAULT 'default',
  organization_name text DEFAULT 'VORTEX SYSTEM',
  organization_cnpj text,
  organization_email text,
  organization_phone text,
  organization_city text,
  default_commission_pct numeric(5,2) DEFAULT 10,
  currency text DEFAULT 'BRL',
  preferences jsonb DEFAULT '{"compactTables":false,"defaultPeriodDays":30}'::jsonb,
  updated_at timestamptz DEFAULT now()
);

-- 10. Proteção contra escalada de privilégios em profiles (trigger não destrutiva)
CREATE OR REPLACE FUNCTION public.vortex_prevent_role_escalation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  caller_role text;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT role INTO caller_role FROM public.profiles WHERE id = auth.uid();

  IF (OLD.role IS DISTINCT FROM NEW.role OR OLD.permissions IS DISTINCT FROM NEW.permissions) THEN
    IF caller_role NOT IN ('proprietario', 'owner') THEN
      RAISE EXCEPTION 'Apenas o proprietário pode alterar cargos ou permissões.';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_vortex_prevent_role_escalation'
  ) THEN
    CREATE TRIGGER trg_vortex_prevent_role_escalation
      BEFORE UPDATE ON public.profiles
      FOR EACH ROW
      EXECUTE FUNCTION public.vortex_prevent_role_escalation();
  END IF;
END $$;

-- 11. RLS somente nas tabelas novas (prospects, prospect_interactions, system_settings)
ALTER TABLE public.prospects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prospect_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'prospects' AND policyname = 'vortex_prospects_auth_all') THEN
    CREATE POLICY vortex_prospects_auth_all ON public.prospects
      FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'prospect_interactions' AND policyname = 'vortex_interactions_auth_all') THEN
    CREATE POLICY vortex_interactions_auth_all ON public.prospect_interactions
      FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'system_settings' AND policyname = 'vortex_settings_auth_read') THEN
    CREATE POLICY vortex_settings_auth_read ON public.system_settings
      FOR SELECT TO authenticated USING (true);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'system_settings' AND policyname = 'vortex_settings_owner_write') THEN
    CREATE POLICY vortex_settings_owner_write ON public.system_settings
      FOR ALL TO authenticated
      USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('proprietario', 'owner', 'administrador', 'admin')))
      WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('proprietario', 'owner', 'administrador', 'admin')));
  END IF;
END $$;

-- Atualiza o schema cache do Supabase / PostgREST
NOTIFY pgrst, 'reload schema';
