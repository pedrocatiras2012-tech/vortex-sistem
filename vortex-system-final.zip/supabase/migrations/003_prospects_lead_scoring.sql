-- ============================================================================
-- VORTEX SYSTEM 2.0 — MIGRAÇÃO NÃO DESTRUTIVA PARA LEAD SCORING E PROSPECÇÃO
-- ============================================================================
-- IMPORTANTE:
-- 1. Esta migration é 100% aditiva e NÃO destrutiva.
-- 2. NÃO apaga tabelas, colunas ou registros existentes.
-- 3. Todas as novas colunas são opcionais (nullable ou com default seguro)
--    para manter total compatibilidade com registros anteriores.
-- ============================================================================

ALTER TABLE IF EXISTS public.prospects
  ADD COLUMN IF NOT EXISTS place_id text,
  ADD COLUMN IF NOT EXISTS state text,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS website_status text,
  ADD COLUMN IF NOT EXISTS geo_confirmed boolean,
  ADD COLUMN IF NOT EXISTS lead_score integer,
  ADD COLUMN IF NOT EXISTS lead_classification text,
  ADD COLUMN IF NOT EXISTS score_justification text,
  ADD COLUMN IF NOT EXISTS commercial_opportunities text,
  ADD COLUMN IF NOT EXISTS google_rating numeric(3,2),
  ADD COLUMN IF NOT EXISTS google_reviews_count integer,
  ADD COLUMN IF NOT EXISTS search_date timestamptz;

CREATE INDEX IF NOT EXISTS idx_prospects_place_id
  ON public.prospects (place_id)
  WHERE place_id IS NOT NULL;

-- Atualiza o schema cache do Supabase / PostgREST
NOTIFY pgrst, 'reload schema';
