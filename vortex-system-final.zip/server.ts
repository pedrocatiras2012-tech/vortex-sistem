import 'dotenv/config';
import express from 'express';
import type { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { criarApiMunicipios, municipios as IBGE_LOCAL_DATASET } from 'municipios-brasil/dados';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function sanitizeEnvValue(raw: string | undefined): string {
  if (!raw) return '';
  let val = raw.trim();
  if (
    (val.startsWith('"') && val.endsWith('"')) ||
    (val.startsWith("'") && val.endsWith("'"))
  ) {
    val = val.slice(1, -1).trim();
  }
  return val;
}

function normalizeSupabaseUrl(raw: string): { origin: string; hadPath: boolean } | null {
  try {
    const parsed = new URL(raw);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return null;
    }
    const hadPath = parsed.pathname !== '/' && parsed.pathname !== '';
    return { origin: parsed.origin, hadPath };
  } catch {
    return null;
  }
}

function isSecretSupabaseKey(key: string): boolean {
  if (key.startsWith('sb_secret_')) return true;
  try {
    const parts = key.split('.');
    if (parts.length !== 3) return false;
    const payloadJson = Buffer.from(parts[1], 'base64url').toString('utf8');
    const payload = JSON.parse(payloadJson) as { role?: string };
    return payload.role === 'service_role';
  } catch {
    return false;
  }
}

function getPlacesEnvFlags() {
  const gMaps = sanitizeEnvValue(process.env.GOOGLE_MAPS_API_KEY);
  const viteGMaps = sanitizeEnvValue(process.env.VITE_GOOGLE_MAPS_API_KEY);
  const mapsKey = sanitizeEnvValue(process.env.MAPS_API_KEY);
  const placesKey = sanitizeEnvValue(process.env.PLACES_API_KEY);

  return {
    GOOGLE_MAPS_API_KEY: Boolean(gMaps),
    VITE_GOOGLE_MAPS_API_KEY: Boolean(viteGMaps),
    MAPS_API_KEY: Boolean(mapsKey),
    PLACES_API_KEY: Boolean(placesKey),
    sameGoogleAndViteKey: Boolean(gMaps && viteGMaps && gMaps === viteGMaps),
  };
}

function getPlacesApiKeyCandidates(): Array<{ key: string; source: string }> {
  const candidates: Array<[string, string | undefined]> = [
    ['GOOGLE_MAPS_API_KEY', process.env.GOOGLE_MAPS_API_KEY],
    ['VITE_GOOGLE_MAPS_API_KEY', process.env.VITE_GOOGLE_MAPS_API_KEY],
    ['MAPS_API_KEY', process.env.MAPS_API_KEY],
    ['PLACES_API_KEY', process.env.PLACES_API_KEY],
  ];
  const seenKeys = new Set<string>();
  const result: Array<{ key: string; source: string }> = [];
  for (const [source, raw] of candidates) {
    const val = sanitizeEnvValue(raw);
    if (val && !seenKeys.has(val)) {
      seenKeys.add(val);
      result.push({ key: val, source });
    }
  }
  return result;
}

function getPlacesApiKey(): { key: string; source: string } {
  return getPlacesApiKeyCandidates()[0] || { key: '', source: '' };
}

function buildWhatsAppDigits(
  internationalPhone?: string,
  nationalPhone?: string
): string {
  const intlDigits = (internationalPhone || '').replace(/\D/g, '');
  if (intlDigits.length >= 10) {
    return intlDigits;
  }
  const natDigits = (nationalPhone || '').replace(/\D/g, '');
  if (!natDigits) return '';
  if (natDigits.length === 10 || natDigits.length === 11) {
    return `55${natDigits}`;
  }
  return natDigits.length >= 10 ? natDigits : '';
}

function normalizeGeoText(value: string): string {
  return (value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const BRAZIL_STATES: Record<string, string> = {
  AC: 'Acre',
  AL: 'Alagoas',
  AP: 'Amapá',
  AM: 'Amazonas',
  BA: 'Bahia',
  CE: 'Ceará',
  DF: 'Distrito Federal',
  ES: 'Espírito Santo',
  GO: 'Goiás',
  MA: 'Maranhão',
  MT: 'Mato Grosso',
  MS: 'Mato Grosso do Sul',
  MG: 'Minas Gerais',
  PA: 'Pará',
  PB: 'Paraíba',
  PR: 'Paraná',
  PE: 'Pernambuco',
  PI: 'Piauí',
  RJ: 'Rio de Janeiro',
  RN: 'Rio Grande do Norte',
  RS: 'Rio Grande do Sul',
  RO: 'Rondônia',
  RR: 'Roraima',
  SC: 'Santa Catarina',
  SP: 'São Paulo',
  SE: 'Sergipe',
  TO: 'Tocantins',
};

interface IbgeMunicipality {
  id: number;
  name: string;
  normalizedName: string;
}

const IBGE_CACHE = new Map<string, { items: IbgeMunicipality[]; fetchedAt: number; source: 'ibge_api' | 'ibge_dataset' }>();
const IBGE_CACHE_TTL_MS = 24 * 60 * 60 * 1000;
let localIbgeApi: ReturnType<typeof criarApiMunicipios> | null = null;

function getLocalIbgeMunicipalities(uf: string): IbgeMunicipality[] {
  if (!localIbgeApi) {
    localIbgeApi = criarApiMunicipios(IBGE_LOCAL_DATASET);
  }
  return localIbgeApi
    .porEstado(uf as Parameters<typeof localIbgeApi.porEstado>[0])
    .map((m) => ({
      id: Number(m.codigoIbge) || 0,
      name: String(m.nome).trim(),
      normalizedName: normalizeGeoText(String(m.nome)),
    }))
    .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
}

async function fetchIbgeMunicipalities(ufRaw: string): Promise<IbgeMunicipality[]> {
  const uf = ufRaw.trim().toUpperCase();
  if (!BRAZIL_STATES[uf]) {
    throw new Error(`UF "${ufRaw}" inválida. Selecione um estado brasileiro válido.`);
  }

  const cached = IBGE_CACHE.get(uf);
  if (cached && Date.now() - cached.fetchedAt < IBGE_CACHE_TTL_MS) {
    return cached.items;
  }

  // Try official live IBGE endpoint first; fall back seamlessly to embedded official IBGE dataset if unreachable
  try {
    const url = `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${uf}/municipios`;
    const response = await fetch(url, {
      headers: { Accept: 'application/json' },
      signal: AbortSignal.timeout(3500),
    });

    if (response.ok) {
      const raw = (await response.json()) as Array<{ id?: number; nome?: string }>;
      if (Array.isArray(raw) && raw.length > 0) {
        const items: IbgeMunicipality[] = raw
          .filter((item) => item && typeof item.nome === 'string')
          .map((item) => ({
            id: Number(item.id) || 0,
            name: String(item.nome).trim(),
            normalizedName: normalizeGeoText(String(item.nome)),
          }))
          .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));

        IBGE_CACHE.set(uf, { items, fetchedAt: Date.now(), source: 'ibge_api' });
        return items;
      }
    }
  } catch {
    // Live IBGE endpoint unreachable/timeout in current network — use official embedded IBGE dataset
  }

  const fallbackItems = getLocalIbgeMunicipalities(uf);
  if (fallbackItems.length === 0) {
    throw new Error(`Não foi possível obter a lista de municípios para ${uf}.`);
  }
  IBGE_CACHE.set(uf, { items: fallbackItems, fetchedAt: Date.now(), source: 'ibge_dataset' });
  return fallbackItems;
}

const SEGMENT_QUERY_VARIATIONS: Array<{ match: string[]; queries: string[] }> = [
  {
    match: ['estetica automotiva', 'estetica_automotiva'],
    queries: [
      'Estética automotiva',
      'Lavagem automotiva',
      'Higienização automotiva',
      'Detalhamento automotivo',
      'Polimento automotivo',
    ],
  },
  {
    match: ['oficinas mecanicas', 'oficina mecanica', 'oficina_mecanica'],
    queries: [
      'Oficina mecânica',
      'Auto center',
      'Centro automotivo',
      'Mecânica automotiva',
      'Manutenção automotiva',
    ],
  },
  {
    match: ['clinicas odontologicas', 'clinica odontologica', 'clinica_odontologica'],
    queries: [
      'Clínica odontológica',
      'Dentista',
      'Consultório odontológico',
      'Ortodontia e implantes',
    ],
  },
  {
    match: ['clinicas medicas e estetica', 'clinica medica e estetica', 'clinica_medica_estetica'],
    queries: [
      'Clínica médica',
      'Clínica de estética',
      'Estética facial e corporal',
      'Consultório médico',
    ],
  },
  {
    match: ['restaurantes', 'restaurante e gastronomia'],
    queries: [
      'Restaurantes',
      'Restaurantes familiares',
      'Restaurantes comerciais',
      'Comida caseira',
      'Restaurantes especializados',
    ],
  },
  {
    match: ['academias e estudios fitness', 'academias', 'academia'],
    queries: [
      'Academia de ginástica',
      'Estúdio de pilates',
      'Treinamento funcional',
      'Box de crossfit',
    ],
  },
  {
    match: ['imobiliarias', 'imobiliaria'],
    queries: ['Imobiliária', 'Corretora de imóveis', 'Administração de imóveis'],
  },
  {
    match: ['escritorios de contabilidade', 'contabilidade'],
    queries: ['Escritório de contabilidade', 'Contabilidade empresarial', 'Assessoria contábil'],
  },
  {
    match: ['escritorios de advocacia', 'advocacia'],
    queries: ['Escritório de advocacia', 'Advogado', 'Consultoria jurídica'],
  },
  {
    match: ['pet shops e clinicas veterinarias', 'pet shop', 'pet_shop'],
    queries: ['Pet shop', 'Clínica veterinária', 'Banho e tosa', 'Hospital veterinário'],
  },
  {
    match: ['saloes de beleza e barbearias', 'salao_barbearia', 'salao de beleza'],
    queries: ['Salão de beleza', 'Barbearia', 'Cabeleireiro', 'Estúdio de beleza'],
  },
  {
    match: ['lojas de moveis e decoracao', 'moveis_decoracao'],
    queries: ['Loja de móveis', 'Móveis planejados', 'Loja de decoração'],
  },
  {
    match: ['construtoras e engenharia', 'construtoras'],
    queries: ['Construtora', 'Escritório de engenharia', 'Arquitetura e construção'],
  },
  {
    match: ['escolas e cursos livres', 'escolas_cursos'],
    queries: ['Escola particular', 'Escola de idiomas', 'Cursos profissionalizantes'],
  },
  {
    match: ['energia solar e climatizacao', 'energia_solar'],
    queries: [
      'Empresa de energia solar',
      'Instalação de energia fotovoltaica',
      'Ar condicionado e climatização',
    ],
  },
];

function buildSearchQueries(segment: string, mode: 'padrao' | 'aprofundada'): string[] {
  const clean = segment.trim();
  if (mode === 'padrao') {
    return [clean];
  }

  const norm = normalizeGeoText(clean);
  const preset = SEGMENT_QUERY_VARIATIONS.find((v) => v.match.includes(norm));
  if (preset) {
    return preset.queries;
  }

  const words = norm.split(' ').filter(Boolean);
  const variations = [clean];
  if (words.length <= 2) {
    variations.push(`Empresa de ${clean}`);
    variations.push(`Serviços de ${clean}`);
  }
  return Array.from(new Set(variations));
}

interface AddressComponent {
  longText?: string;
  shortText?: string;
  types?: string[];
}

interface GooglePlaceApiItem {
  id?: string;
  displayName?: { text?: string; languageCode?: string };
  formattedAddress?: string;
  addressComponents?: AddressComponent[];
  businessStatus?: string;
  googleMapsUri?: string;
  primaryTypeDisplayName?: { text?: string; languageCode?: string };
  types?: string[];
  nationalPhoneNumber?: string;
  internationalPhoneNumber?: string;
  websiteUri?: string;
  rating?: number;
  userRatingCount?: number;
}

interface GooglePlacesTextSearchResponse {
  places?: GooglePlaceApiItem[];
  nextPageToken?: string;
  error?: {
    code?: number;
    message?: string;
    status?: string;
    details?: Array<Record<string, unknown>>;
  };
}

interface ContinuationItem {
  queryTerm: string;
  pageToken?: string;
  pageNumber: number;
}

function validatePlaceGeography(
  place: GooglePlaceApiItem,
  targetCity: string,
  targetUf: string
): {
  geoStatus: 'confirmed' | 'unconfirmed' | 'mismatch';
  detectedCity: string;
  detectedState: string;
} {
  const targetCityNorm = normalizeGeoText(targetCity);
  const targetUfUpper = targetUf.trim().toUpperCase();
  const targetStateNameNorm = normalizeGeoText(BRAZIL_STATES[targetUfUpper] || '');

  const comps = Array.isArray(place.addressComponents) ? place.addressComponents : [];
  const addr = place.formattedAddress || '';

  let componentCity = '';
  let componentLocality = '';
  let componentStateShort = '';
  let componentStateLong = '';
  let countryShort = '';

  for (const c of comps) {
    const types = c.types || [];
    if (types.includes('administrative_area_level_2')) {
      componentCity = c.longText || c.shortText || '';
    }
    if (types.includes('locality')) {
      componentLocality = c.longText || c.shortText || '';
    }
    if (types.includes('administrative_area_level_1')) {
      componentStateShort = (c.shortText || '').trim().toUpperCase();
      componentStateLong = c.longText || '';
    }
    if (types.includes('country')) {
      countryShort = (c.shortText || '').trim().toUpperCase();
    }
  }

  // Fallback parse from formattedAddress: e.g. "..., Belo Horizonte - MG, 30110-000, Brasil"
  const formattedMatch = addr.match(/,\s*([^,\-]+?)\s*-\s*([A-Z]{2})(?:,|\s|$)/);
  const formattedCity = formattedMatch?.[1]?.trim() || '';
  const formattedUf = formattedMatch?.[2]?.trim().toUpperCase() || '';

  const detectedState = componentStateShort || formattedUf || '';
  const detectedCity = componentCity || componentLocality || formattedCity || '';

  if (countryShort && countryShort !== 'BR') {
    return { geoStatus: 'mismatch', detectedCity, detectedState };
  }

  // Check UF compatibility first
  let stateConfirmed = false;
  if (componentStateShort || componentStateLong || formattedUf) {
    const matchesShort =
      (componentStateShort && componentStateShort === targetUfUpper) ||
      (formattedUf && formattedUf === targetUfUpper);
    const matchesLong =
      Boolean(componentStateLong) && normalizeGeoText(componentStateLong) === targetStateNameNorm;

    if (!matchesShort && !matchesLong) {
      return { geoStatus: 'mismatch', detectedCity, detectedState };
    }
    stateConfirmed = true;
  }

  // Check city compatibility
  const cityCandidates = [componentCity, componentLocality, formattedCity]
    .filter(Boolean)
    .map((c) => normalizeGeoText(c));

  if (cityCandidates.length > 0) {
    const cityMatches = cityCandidates.some((c) => c === targetCityNorm);
    if (cityMatches && stateConfirmed) {
      return { geoStatus: 'confirmed', detectedCity: detectedCity || targetCity, detectedState: targetUfUpper };
    }

    // Distrito Federal special case: Brasília covers DF administrative regions
    if (
      targetUfUpper === 'DF' &&
      targetCityNorm === 'brasilia' &&
      stateConfirmed &&
      (cityCandidates.includes('brasilia') || normalizeGeoText(addr).includes('brasilia'))
    ) {
      return { geoStatus: 'confirmed', detectedCity: 'Brasília', detectedState: 'DF' };
    }

    // If administrative_area_level_2 or formattedCity explicitly points to a different municipality, reject
    if (componentCity && normalizeGeoText(componentCity) !== targetCityNorm) {
      return { geoStatus: 'mismatch', detectedCity, detectedState };
    }
    if (!componentCity && formattedCity && normalizeGeoText(formattedCity) !== targetCityNorm) {
      return { geoStatus: 'mismatch', detectedCity, detectedState };
    }
  }

  // Fallback check inside formattedAddress text if addressComponents omitted city
  if (stateConfirmed && normalizeGeoText(addr).includes(targetCityNorm)) {
    return { geoStatus: 'confirmed', detectedCity: detectedCity || targetCity, detectedState: targetUfUpper };
  }

  return {
    geoStatus: 'unconfirmed',
    detectedCity: detectedCity || '',
    detectedState: detectedState || '',
  };
}

const inFlightSearches = new Set<string>();

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  app.use(express.json({ limit: '1mb' }));

  app.get('/api/supabase-config', (_req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');

    const rawUrl = sanitizeEnvValue(process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL);
    const anonKey = sanitizeEnvValue(process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY);

    if (!rawUrl || !anonKey) {
      res.json({ configured: false });
      return;
    }

    const normalized = normalizeSupabaseUrl(rawUrl);
    if (!normalized) {
      res.status(400).json({
        configured: false,
        error:
          'VITE_SUPABASE_URL inválida. Utilize a Project URL do Supabase (ex: https://seu-projeto.supabase.co).',
      });
      return;
    }

    if (isSecretSupabaseKey(anonKey)) {
      res.status(400).json({
        configured: false,
        error:
          'Chave secreta (service_role ou sb_secret_) detectada em VITE_SUPABASE_ANON_KEY. Por segurança, substitua pela chave pública anon ou publishable.',
      });
      return;
    }

    res.json({
      configured: true,
      url: normalized.origin,
      anonKey,
    });
  });

  app.get('/api/prospecting/status', (_req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    const { key, source } = getPlacesApiKey();
    res.json({
      configured: Boolean(key),
      source: source || null,
      envFlags: getPlacesEnvFlags(),
      provider: 'google_places_new',
    });
  });

  // IBGE Municipalities endpoint filtered strictly by UF with 24h in-memory cache
  app.get('/api/prospecting/municipalities', async (req: Request, res: Response) => {
    const uf = String(req.query.uf || '').trim().toUpperCase();
    if (!uf || !BRAZIL_STATES[uf]) {
      res.status(400).json({
        error: 'Selecione um estado brasileiro válido (UF) para carregar os municípios.',
      });
      return;
    }

    try {
      const municipalities = await fetchIbgeMunicipalities(uf);
      res.setHeader('Cache-Control', 'public, max-age=3600');
      res.json({
        uf,
        stateName: BRAZIL_STATES[uf],
        total: municipalities.length,
        municipalities,
      });
    } catch (err) {
      res.status(503).json({
        error:
          err instanceof Error
            ? err.message
            : 'Serviço de localidades do IBGE indisponível no momento.',
      });
    }
  });

  // Server-side RBAC verification against Supabase Auth + profiles table (using user's Bearer JWT)
  async function verifySupabaseBearerAccess(
    req: Request,
    options: { requiredModule?: string; allowedRoles?: string[] }
  ): Promise<{
    ok: boolean;
    status: number;
    error?: string;
    userId?: string;
    role?: string;
    permissions?: Record<string, boolean>;
  }> {
    const authHeader = String(req.headers.authorization || '').trim();
    if (!authHeader.toLowerCase().startsWith('bearer ')) {
      return { ok: false, status: 401, error: 'Token de autenticação ausente.' };
    }
    const token = authHeader.slice(7).trim();
    const rawUrl = sanitizeEnvValue(process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL);
    const anonKey = sanitizeEnvValue(process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY);
    const normalized = normalizeSupabaseUrl(rawUrl);

    if (!normalized || !anonKey) {
      return { ok: false, status: 503, error: 'Configuração Supabase indisponível no servidor.' };
    }

    try {
      const userResp = await fetch(`${normalized.origin}/auth/v1/user`, {
        headers: {
          apikey: anonKey,
          Authorization: `Bearer ${token}`,
        },
        signal: AbortSignal.timeout(6000),
      });
      if (!userResp.ok) {
        return { ok: false, status: 401, error: 'Sessão inválida ou expirada.' };
      }
      const authUser = (await userResp.json()) as { id?: string };
      if (!authUser.id) {
        return { ok: false, status: 401, error: 'Usuário autenticado não identificado.' };
      }

      const profResp = await fetch(
        `${normalized.origin}/rest/v1/profiles?id=eq.${encodeURIComponent(authUser.id)}&select=id,role,status,permissions`,
        {
          headers: {
            apikey: anonKey,
            Authorization: `Bearer ${token}`,
          },
          signal: AbortSignal.timeout(6000),
        }
      );
      if (!profResp.ok) {
        return { ok: false, status: 403, error: 'Não foi possível validar o perfil de permissões.' };
      }
      const rows = (await profResp.json()) as Array<{
        id: string;
        role?: string;
        status?: string;
        permissions?: Record<string, boolean>;
      }>;
      const prof = rows[0];
      if (!prof || String(prof.status || 'ativo').toLowerCase() === 'inativo') {
        return { ok: false, status: 403, error: 'Usuário inativo ou sem perfil autorizado.' };
      }

      const rawRole = String(prof.role || 'colaborador').toLowerCase().trim();
      const canonicalRole =
        rawRole === 'owner' || rawRole === 'proprietario'
          ? 'proprietario'
          : rawRole === 'admin' || rawRole === 'administrador'
            ? 'administrador'
            : rawRole === 'manager' || rawRole === 'gerente'
              ? 'gerente'
              : 'colaborador';

      const perms = prof.permissions || {};

      if (canonicalRole !== 'proprietario') {
        if (options.allowedRoles && !options.allowedRoles.includes(canonicalRole)) {
          return {
            ok: false,
            status: 403,
            error: 'Seu nível de acesso não possui autorização para esta operação.',
          };
        }
        if (options.requiredModule && perms[options.requiredModule] !== true) {
          return {
            ok: false,
            status: 403,
            error: `Permissão negada para o módulo/recurso "${options.requiredModule}".`,
          };
        }
      }

      return {
        ok: true,
        status: 200,
        userId: prof.id,
        role: canonicalRole,
        permissions: perms,
      };
    } catch {
      return { ok: false, status: 502, error: 'Falha ao verificar autorização no Supabase.' };
    }
  }

  app.post('/api/auth/verify-access', async (req: Request, res: Response) => {
    const body = (req.body || {}) as { requiredModule?: string; allowedRoles?: string[] };
    const result = await verifySupabaseBearerAccess(req, {
      requiredModule: body.requiredModule,
      allowedRoles: body.allowedRoles,
    });
    if (!result.ok) {
      res.status(result.status).json({ authorized: false, error: result.error });
      return;
    }
    res.json({
      authorized: true,
      userId: result.userId,
      role: result.role,
      permissions: result.permissions,
    });
  });

  // Server-side proxy for Google Places API (New) Text Search
  app.post('/api/prospecting/search', async (req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    // Google Places requests must always belong to an authenticated user
    // with prospecting permission; never expose the paid API proxy anonymously.
    const authCheck = await verifySupabaseBearerAccess(req, { requiredModule: 'prospeccao' });
    if (!authCheck.ok) {
      res.status(authCheck.status).json({ error: authCheck.error });
      return;
    }

    const candidates = getPlacesApiKeyCandidates();

    if (candidates.length === 0) {
      res.status(503).json({
        configured: false,
        error:
          'Chave da Google Places API não configurada no backend. Cadastre GOOGLE_MAPS_API_KEY nos Secrets para habilitar buscas reais.',
      });
      return;
    }

    const body = (req.body || {}) as {
      city?: string;
      state?: string;
      segment?: string;
      mode?: string;
      pageToken?: string;
      continuationQueue?: ContinuationItem[];
      seenPlaceIds?: string[];
      currentTotal?: number;
      pageSize?: number;
    };

    const cityInput = typeof body.city === 'string' ? body.city.trim() : '';
    const stateInput = typeof body.state === 'string' ? body.state.trim().toUpperCase() : '';
    const segment = typeof body.segment === 'string' ? body.segment.trim() : '';
    const mode: 'padrao' | 'aprofundada' = body.mode === 'aprofundada' ? 'aprofundada' : 'padrao';
    const pageSize = Math.min(20, Math.max(1, Number(body.pageSize) || 20));
    const currentTotal = Math.max(0, Number(body.currentTotal) || 0);
    const MAX_RESULTS_PER_SESSION = 60;

    if (!stateInput || !BRAZIL_STATES[stateInput]) {
      res.status(400).json({
        error: 'Selecione um estado brasileiro (UF) válido antes de iniciar a pesquisa.',
      });
      return;
    }

    if (!cityInput) {
      res.status(400).json({
        error: `Selecione um município válido de ${stateInput} (${BRAZIL_STATES[stateInput]}).`,
      });
      return;
    }

    if (!segment) {
      res.status(400).json({
        error: 'Informe ou selecione o segmento empresarial para iniciar a busca.',
      });
      return;
    }

    // Backend validation against IBGE municipalities for the chosen UF
    let canonicalCity = cityInput;
    try {
      const stateCities = await fetchIbgeMunicipalities(stateInput);
      const cityNorm = normalizeGeoText(cityInput);
      const found = stateCities.find((m) => m.normalizedName === cityNorm);
      if (!found) {
        res.status(400).json({
          error: `A cidade "${cityInput}" não pertence ao estado ${stateInput} (${BRAZIL_STATES[stateInput]}). Selecione um município válido da lista de ${stateInput}.`,
        });
        return;
      }
      canonicalCity = found.name;
    } catch (err) {
      res.status(503).json({
        error:
          err instanceof Error
            ? `Não foi possível validar o município no IBGE: ${err.message}`
            : 'Não foi possível validar o município selecionado.',
      });
      return;
    }

    const requestLockKey = `${stateInput}|${normalizeGeoText(canonicalCity)}|${normalizeGeoText(segment)}|${mode}|${currentTotal}`;
    if (inFlightSearches.has(requestLockKey)) {
      res.status(429).json({
        error: 'Já existe uma busca idêntica em andamento. Aguarde a conclusão antes de tentar novamente.',
      });
      return;
    }
    inFlightSearches.add(requestLockKey);

    const fieldMask = [
      'places.id',
      'places.displayName',
      'places.formattedAddress',
      'places.addressComponents',
      'places.businessStatus',
      'places.googleMapsUri',
      'places.primaryTypeDisplayName',
      'places.types',
      'places.nationalPhoneNumber',
      'places.internationalPhoneNumber',
      'places.websiteUri',
      'places.rating',
      'places.userRatingCount',
      'nextPageToken',
    ].join(',');

    async function callPlacesTextSearch(textQuery: string, pageToken?: string) {
      const requestPayload: Record<string, unknown> = {
        textQuery,
        languageCode: 'pt-BR',
        regionCode: 'BR',
        pageSize,
      };
      if (pageToken) {
        requestPayload.pageToken = pageToken;
      }

      let winningData: GooglePlacesTextSearchResponse | null = null;
      let lastFailure: {
        upstreamStatus: number;
        statusText: string;
        rawMsg: string;
        keySource: string;
        googleDetails: Array<Record<string, unknown>> | null;
      } | null = null;

      for (const candidate of candidates) {
        const upstream = await fetch('https://places.googleapis.com/v1/places:searchText', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Goog-Api-Key': candidate.key,
            'X-Goog-FieldMask': fieldMask,
            'X-Goog-Maps-Solution-ID': 'gmp_mcp_codeassist_v1_aistudio',
          },
          body: JSON.stringify(requestPayload),
          signal: AbortSignal.timeout(12000),
        });

        const rawText = await upstream.text();
        let data: GooglePlacesTextSearchResponse = {};
        try {
          data = JSON.parse(rawText) as GooglePlacesTextSearchResponse;
        } catch {
          data = {};
        }

        if (upstream.ok) {
          winningData = data;
          break;
        }

        const statusText = data.error?.status || '';
        const rawMsg = data.error?.message || rawText.slice(0, 300) || '';
        lastFailure = {
          upstreamStatus: upstream.status,
          statusText,
          rawMsg,
          keySource: candidate.source,
          googleDetails: data.error?.details || null,
        };

        if (upstream.status !== 401 && upstream.status !== 403) {
          break;
        }
      }

      return { winningData, lastFailure };
    }

    try {
      const seenIds = new Set<string>(Array.isArray(body.seenPlaceIds) ? body.seenPlaceIds : []);
      const isContinuation =
        (Array.isArray(body.continuationQueue) && body.continuationQueue.length > 0) ||
        Boolean(body.pageToken);

      const queueToExecute: ContinuationItem[] = isContinuation
        ? Array.isArray(body.continuationQueue) && body.continuationQueue.length > 0
          ? [...body.continuationQueue]
          : [{ queryTerm: segment, pageToken: body.pageToken, pageNumber: 2 }]
        : buildSearchQueries(segment, mode).map((queryTerm) => ({
            queryTerm,
            pageNumber: 1,
          }));

      const maxCallsThisRequest = mode === 'aprofundada' ? (isContinuation ? 2 : 3) : 1;
      const remainingCapacity = Math.max(0, MAX_RESULTS_PER_SESSION - currentTotal);

      const collectedResults: Array<Record<string, unknown>> = [];
      const leftoverQueue: ContinuationItem[] = [];
      let apiCallsUsed = 0;
      let filteredOutGeoCount = 0;
      let filteredOutClosedCount = 0;
      let unconfirmedGeoCount = 0;
      const queriesExecuted: string[] = [];
      let hardFailure: {
        upstreamStatus: number;
        statusText: string;
        rawMsg: string;
        keySource: string;
        googleDetails: Array<Record<string, unknown>> | null;
      } | null = null;

      while (
        queueToExecute.length > 0 &&
        apiCallsUsed < maxCallsThisRequest &&
        collectedResults.length < remainingCapacity
      ) {
        const task = queueToExecute.shift()!;
        const textQuery = `${task.queryTerm} em ${canonicalCity}, ${stateInput}, Brasil`;
        queriesExecuted.push(textQuery);
        apiCallsUsed += 1;

        const { winningData, lastFailure } = await callPlacesTextSearch(textQuery, task.pageToken);

        if (!winningData && lastFailure) {
          if (collectedResults.length === 0) {
            hardFailure = lastFailure;
          }
          break;
        }

        const rawPlaces = Array.isArray(winningData?.places) ? winningData!.places! : [];
        for (const place of rawPlaces) {
          if (collectedResults.length >= remainingCapacity) break;

          const placeId = place.id || '';
          if (placeId && seenIds.has(placeId)) {
            continue;
          }

          const businessStatus = place.businessStatus || 'OPERATIONAL';
          if (businessStatus === 'CLOSED_PERMANENTLY') {
            filteredOutClosedCount += 1;
            if (placeId) seenIds.add(placeId);
            continue;
          }

          const geoCheck = validatePlaceGeography(place, canonicalCity, stateInput);
          if (geoCheck.geoStatus === 'mismatch') {
            filteredOutGeoCount += 1;
            if (placeId) seenIds.add(placeId);
            continue;
          }

          if (geoCheck.geoStatus === 'unconfirmed') {
            unconfirmedGeoCount += 1;
          }

          if (placeId) seenIds.add(placeId);

          const nationalPhone = place.nationalPhoneNumber || '';
          const internationalPhone = place.internationalPhoneNumber || '';
          const displayPhone = nationalPhone || internationalPhone;
          const whatsappDigits = buildWhatsAppDigits(internationalPhone, nationalPhone);
          const website = (place.websiteUri || '').trim();
          const websiteStatus =
            website.length > 0 ? 'site_informado' : 'sem_site_informado';

          collectedResults.push({
            placeId,
            name: place.displayName?.text || 'Empresa sem nome informado',
            address: place.formattedAddress || 'Endereço não informado',
            city: canonicalCity,
            state: stateInput,
            detectedCity: geoCheck.detectedCity,
            detectedState: geoCheck.detectedState,
            geoStatus: geoCheck.geoStatus,
            phone: displayPhone,
            internationalPhone,
            whatsappDigits,
            whatsappUrl: whatsappDigits ? `https://wa.me/${whatsappDigits}` : '',
            website,
            websiteStatus,
            hasWebsiteListed: Boolean(website),
            category:
              place.primaryTypeDisplayName?.text ||
              (place.types?.[0] ? place.types[0].replace(/_/g, ' ') : task.queryTerm),
            types: Array.isArray(place.types) ? place.types : [],
            businessStatus,
            rating: typeof place.rating === 'number' ? place.rating : null,
            userRatingCount:
              typeof place.userRatingCount === 'number' ? place.userRatingCount : null,
            googleMapsUri: place.googleMapsUri || '',
            matchedQuery: task.queryTerm,
          });
        }

        // Queue next page of this query (max 3 pages per query = Google Places limit)
        if (
          winningData?.nextPageToken &&
          task.pageNumber < 3 &&
          currentTotal + collectedResults.length < MAX_RESULTS_PER_SESSION
        ) {
          leftoverQueue.push({
            queryTerm: task.queryTerm,
            pageToken: winningData.nextPageToken,
            pageNumber: task.pageNumber + 1,
          });
        }
      }

      if (hardFailure) {
        const isQuota =
          hardFailure.upstreamStatus === 429 ||
          hardFailure.statusText === 'RESOURCE_EXHAUSTED' ||
          hardFailure.rawMsg.toLowerCase().includes('quota');

        if (isQuota) {
          res.status(429).json({
            quotaExceeded: true,
            upstreamStatus: hardFailure.upstreamStatus,
            googleStatus: hardFailure.statusText || null,
            error:
              'Limite de requisições da Google Places API atingido no momento. Tente novamente mais tarde ou verifique a cota do projeto no Google Cloud.',
            details: hardFailure.rawMsg,
          });
          return;
        }

        if (hardFailure.upstreamStatus === 403 || hardFailure.upstreamStatus === 401) {
          res.status(hardFailure.upstreamStatus).json({
            upstreamStatus: hardFailure.upstreamStatus,
            googleStatus: hardFailure.statusText || null,
            error:
              'A chave configurada foi recusada pela Google Places API (New). Verifique se a "Places API (New)" está ativada no Google Cloud e sem restrições incompatíveis com servidor.',
            details: hardFailure.rawMsg,
          });
          return;
        }

        res.status(hardFailure.upstreamStatus).json({
          upstreamStatus: hardFailure.upstreamStatus,
          googleStatus: hardFailure.statusText || null,
          error: hardFailure.rawMsg || 'Erro ao consultar a Google Places API (New).',
        });
        return;
      }

      const nextContinuationQueue =
        currentTotal + collectedResults.length >= MAX_RESULTS_PER_SESSION
          ? []
          : [...queueToExecute, ...leftoverQueue];

      res.json({
        configured: true,
        city: canonicalCity,
        state: stateInput,
        stateName: BRAZIL_STATES[stateInput],
        mode,
        query: queriesExecuted[0] || `${segment} em ${canonicalCity}, ${stateInput}, Brasil`,
        queriesExecuted,
        apiCallsUsed,
        filteredOutGeoCount,
        filteredOutClosedCount,
        unconfirmedGeoCount,
        results: collectedResults,
        continuationQueue: nextContinuationQueue,
        hasMore: nextContinuationQueue.length > 0,
        maxSessionLimit: MAX_RESULTS_PER_SESSION,
        searchedAt: new Date().toISOString(),
      });
    } catch (err) {
      res.status(502).json({
        error:
          err instanceof Error
            ? `Falha de comunicação com a Google Places API: ${err.message}`
            : 'Falha de comunicação com a Google Places API.',
      });
    } finally {
      inFlightSearches.delete(requestLockKey);
    }
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`VORTEX SYSTEM rodando em http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Erro ao iniciar servidor:', err);
  process.exit(1);
});
