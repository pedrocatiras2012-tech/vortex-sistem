import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import {
  getSupabaseClient,
  initSupabase,
  supabase,
  supabaseConfigError,
} from '../lib/supabase';
import { ensureUserProfile } from '../services/database';
import type { ModulePermissions, UserProfile } from '../types';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  configured: boolean;
  configError: string | null;
  isAdminOrOwner: boolean;
  isManagerOrAbove: boolean;
  canViewAllLeads: boolean;
  canDistributeLeads: boolean;
  hasPermission: (moduleKey: keyof ModulePermissions) => boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ needsEmailConfirmation: boolean }>;
  resetPassword: (email: string) => Promise<void>;
  updatePassword: (newPassword: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [configured, setConfigured] = useState(false);
  const [configError, setConfigError] = useState<string | null>(supabaseConfigError);

  const loadProfile = useCallback(async (authUser: User | null) => {
    if (!authUser) {
      setProfile(null);
      return;
    }
    try {
      const p = await ensureUserProfile({
        id: authUser.id,
        email: authUser.email,
        user_metadata: authUser.user_metadata,
      });
      setProfile(p);
    } catch {
      setProfile(null);
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    let unsubscribe: (() => void) | null = null;

    (async () => {
      const ready = await initSupabase();
      if (!mounted) return;
      setConfigured(ready);
      setConfigError(supabaseConfigError);

      if (!ready || !supabase) {
        setLoading(false);
        return;
      }

      const { data } = await supabase.auth.getSession();
      if (!mounted) return;
      setSession(data.session);
      setUser(data.session?.user ?? null);
      if (data.session?.user) {
        await loadProfile(data.session.user);
      }
      if (mounted) setLoading(false);

      const { data: listener } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
        if (!mounted) return;
        setSession(newSession);
        setUser(newSession?.user ?? null);
        if (newSession?.user) {
          await loadProfile(newSession.user);
        } else {
          setProfile(null);
        }
        setLoading(false);
      });

      unsubscribe = () => listener.subscription.unsubscribe();
    })();

    return () => {
      mounted = false;
      if (unsubscribe) unsubscribe();
    };
  }, [loadProfile]);

  const signIn = useCallback(async (email: string, password: string) => {
    const client = getSupabaseClient();
    const { data, error } = await client.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error) throw new Error(error.message);
    if (data.user) {
      await loadProfile(data.user);
    }
  }, [loadProfile]);

  const signUp = useCallback(async (email: string, password: string, fullName: string) => {
    const client = getSupabaseClient();
    const { data, error } = await client.auth.signUp({
      email: email.trim(),
      password,
      options: {
        data: {
          full_name: fullName.trim(),
        },
      },
    });
    if (error) throw new Error(error.message);
    const needsEmailConfirmation = Boolean(data.user && !data.session);
    if (data.session?.user) {
      await loadProfile(data.session.user);
    }
    return { needsEmailConfirmation };
  }, [loadProfile]);

  const resetPassword = useCallback(async (email: string) => {
    const client = getSupabaseClient();
    const { error } = await client.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: window.location.origin,
    });
    if (error) throw new Error(error.message);
  }, []);

  const updatePassword = useCallback(async (newPassword: string) => {
    const client = getSupabaseClient();
    const { error } = await client.auth.updateUser({ password: newPassword });
    if (error) throw new Error(error.message);
  }, []);

  const signOut = useCallback(async () => {
    if (!supabase) return;
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
    setProfile(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    if (user) {
      await loadProfile(user);
    }
  }, [user, loadProfile]);

  const hasPermission = useCallback(
    (moduleKey: keyof ModulePermissions) => {
      if (!profile) return false;
      if (profile.status === 'inativo') return false;
      if (profile.role === 'proprietario') return true;
      return Boolean(profile.permissions?.[moduleKey]);
    },
    [profile]
  );

  const isAdminOrOwner =
    Boolean(profile && profile.status === 'ativo' && (profile.role === 'proprietario' || profile.role === 'administrador'));
  const isManagerOrAbove =
    Boolean(
      profile &&
        profile.status === 'ativo' &&
        (profile.role === 'proprietario' || profile.role === 'administrador' || profile.role === 'gerente')
    );
  const canViewAllLeads = isManagerOrAbove || hasPermission('ver_todos_leads');
  const canDistributeLeads = isManagerOrAbove || hasPermission('distribuir_leads');

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        profile,
        loading,
        configured,
        configError,
        isAdminOrOwner,
        isManagerOrAbove,
        canViewAllLeads,
        canDistributeLeads,
        hasPermission,
        signIn,
        signUp,
        resetPassword,
        updatePassword,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider');
  return ctx;
}
