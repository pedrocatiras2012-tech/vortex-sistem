export type WebsiteStatus = 'site_informado' | 'sem_site_informado' | 'nao_verificado';
export type GeoValidationStatus = 'confirmed' | 'unconfirmed' | 'mismatch';
export type LeadClassification = 'alto' | 'medio' | 'baixo';
export type SearchMode = 'padrao' | 'aprofundada';

export interface ScoreCriterionBreakdown {
  key: 'website' | 'segment' | 'phone' | 'operational' | 'geography' | 'profile';
  label: string;
  points: number;
  maxPoints: number;
  reason: string;
}

export interface LeadScoreResult {
  total: number;
  classification: LeadClassification;
  classificationLabel: string;
  segmentCompatible: boolean;
  justification: string;
  breakdown: ScoreCriterionBreakdown[];
  opportunities: string[];
}

export interface BrazilStateInfo {
  uf: string;
  name: string;
}

export const BRAZIL_STATES_LIST: BrazilStateInfo[] = [
  { uf: 'AC', name: 'Acre' },
  { uf: 'AL', name: 'Alagoas' },
  { uf: 'AP', name: 'Amapá' },
  { uf: 'AM', name: 'Amazonas' },
  { uf: 'BA', name: 'Bahia' },
  { uf: 'CE', name: 'Ceará' },
  { uf: 'DF', name: 'Distrito Federal' },
  { uf: 'ES', name: 'Espírito Santo' },
  { uf: 'GO', name: 'Goiás' },
  { uf: 'MA', name: 'Maranhão' },
  { uf: 'MT', name: 'Mato Grosso' },
  { uf: 'MS', name: 'Mato Grosso do Sul' },
  { uf: 'MG', name: 'Minas Gerais' },
  { uf: 'PA', name: 'Pará' },
  { uf: 'PB', name: 'Paraíba' },
  { uf: 'PR', name: 'Paraná' },
  { uf: 'PE', name: 'Pernambuco' },
  { uf: 'PI', name: 'Piauí' },
  { uf: 'RJ', name: 'Rio de Janeiro' },
  { uf: 'RN', name: 'Rio Grande do Norte' },
  { uf: 'RS', name: 'Rio Grande do Sul' },
  { uf: 'RO', name: 'Rondônia' },
  { uf: 'RR', name: 'Roraima' },
  { uf: 'SC', name: 'Santa Catarina' },
  { uf: 'SP', name: 'São Paulo' },
  { uf: 'SE', name: 'Sergipe' },
  { uf: 'TO', name: 'Tocantins' },
];

export interface SegmentDefinition {
  id: string;
  label: string;
  deepQueries: string[];
  placeTypes: string[];
  keywords: string[];
}

export const SEGMENT_DEFINITIONS: SegmentDefinition[] = [
  {
    id: 'estetica_automotiva',
    label: 'Estética automotiva',
    deepQueries: [
      'Estética automotiva',
      'Lavagem automotiva',
      'Higienização automotiva',
      'Detalhamento automotivo',
      'Polimento automotivo',
    ],
    placeTypes: ['car_wash', 'car_repair', 'auto_parts_store'],
    keywords: ['estetica automotiva', 'lavagem', 'lava jato', 'higienizacao', 'detalhamento', 'polimento', 'automotivo', 'car wash'],
  },
  {
    id: 'oficina_mecanica',
    label: 'Oficinas mecânicas',
    deepQueries: [
      'Oficina mecânica',
      'Auto center',
      'Centro automotivo',
      'Mecânica automotiva',
      'Manutenção automotiva',
    ],
    placeTypes: ['car_repair', 'auto_parts_store', 'tire_shop'],
    keywords: ['oficina', 'mecanica', 'auto center', 'automotivo', 'reparacao', 'funilaria', 'pneus'],
  },
  {
    id: 'clinica_odontologica',
    label: 'Clínicas odontológicas',
    deepQueries: [
      'Clínica odontológica',
      'Dentista',
      'Consultório odontológico',
      'Ortodontia e implantes',
    ],
    placeTypes: ['dentist', 'dental_clinic', 'doctor', 'medical_clinic'],
    keywords: ['odonto', 'dentista', 'ortodontia', 'implante', 'sorriso', 'clinica'],
  },
  {
    id: 'clinica_medica_estetica',
    label: 'Clínicas médicas e estética',
    deepQueries: [
      'Clínica médica',
      'Clínica de estética',
      'Estética facial e corporal',
      'Consultório médico',
    ],
    placeTypes: ['medical_clinic', 'doctor', 'skin_care_clinic', 'spa', 'beauty_salon'],
    keywords: ['clinica', 'estetica', 'medico', 'saude', 'dermatologia', 'biomedicina', 'spa'],
  },
  {
    id: 'restaurantes',
    label: 'Restaurantes',
    deepQueries: [
      'Restaurantes',
      'Restaurantes familiares',
      'Restaurantes comerciais',
      'Comida caseira',
      'Restaurantes especializados',
    ],
    placeTypes: ['restaurant', 'brazilian_restaurant', 'steak_house', 'pizza_restaurant', 'meal_delivery'],
    keywords: ['restaurante', 'churrascaria', 'pizzaria', 'bistro', 'comida', 'gastronomia', 'cantina'],
  },
  {
    id: 'academias',
    label: 'Academias e estúdios fitness',
    deepQueries: [
      'Academia de ginástica',
      'Estúdio de pilates',
      'Treinamento funcional',
      'Box de crossfit',
    ],
    placeTypes: ['gym', 'fitness_center', 'sports_club'],
    keywords: ['academia', 'fitness', 'pilates', 'crossfit', 'musculacao', 'treino', 'estudio'],
  },
  {
    id: 'imobiliarias',
    label: 'Imobiliárias',
    deepQueries: [
      'Imobiliária',
      'Corretora de imóveis',
      'Administração de imóveis',
    ],
    placeTypes: ['real_estate_agency'],
    keywords: ['imobiliaria', 'imoveis', 'corretora', 'empreendimentos'],
  },
  {
    id: 'contabilidade',
    label: 'Escritórios de contabilidade',
    deepQueries: [
      'Escritório de contabilidade',
      'Contabilidade empresarial',
      'Assessoria contábil',
    ],
    placeTypes: ['accounting', 'consultant'],
    keywords: ['contabilidade', 'contabil', 'contador', 'assessoria fiscal'],
  },
  {
    id: 'advocacia',
    label: 'Escritórios de advocacia',
    deepQueries: [
      'Escritório de advocacia',
      'Advogado',
      'Consultoria jurídica',
    ],
    placeTypes: ['lawyer'],
    keywords: ['advocacia', 'advogado', 'juridico', 'direito'],
  },
  {
    id: 'pet_shop',
    label: 'Pet shops e clínicas veterinárias',
    deepQueries: [
      'Pet shop',
      'Clínica veterinária',
      'Banho e tosa',
      'Hospital veterinário',
    ],
    placeTypes: ['pet_store', 'veterinary_care'],
    keywords: ['pet', 'veterinaria', 'banho e tosa', 'animal', 'cao', 'gato'],
  },
  {
    id: 'salao_barbearia',
    label: 'Salões de beleza e barbearias',
    deepQueries: [
      'Salão de beleza',
      'Barbearia',
      'Cabeleireiro',
      'Estúdio de beleza',
    ],
    placeTypes: ['beauty_salon', 'barber_shop', 'hair_salon', 'hair_care'],
    keywords: ['salao', 'beleza', 'barbearia', 'cabeleireiro', 'manicure', 'sobrancelha', 'barber'],
  },
  {
    id: 'moveis_decoracao',
    label: 'Lojas de móveis e decoração',
    deepQueries: [
      'Loja de móveis',
      'Móveis planejados',
      'Loja de decoração',
    ],
    placeTypes: ['furniture_store', 'home_goods_store', 'interior_designer'],
    keywords: ['moveis', 'decoracao', 'planejados', 'design de interiores', 'marcenaria'],
  },
  {
    id: 'construtoras',
    label: 'Construtoras e engenharia',
    deepQueries: [
      'Construtora',
      'Escritório de engenharia',
      'Arquitetura e construção',
    ],
    placeTypes: ['general_contractor', 'roofing_contractor'],
    keywords: ['construtora', 'engenharia', 'arquitetura', 'obras', 'construcao'],
  },
  {
    id: 'escolas_cursos',
    label: 'Escolas e cursos livres',
    deepQueries: [
      'Escola particular',
      'Escola de idiomas',
      'Cursos profissionalizantes',
    ],
    placeTypes: ['school', 'secondary_school', 'primary_school', 'university'],
    keywords: ['escola', 'curso', 'ensino', 'idiomas', 'treinamento', 'colegio'],
  },
  {
    id: 'energia_solar',
    label: 'Energia solar e climatização',
    deepQueries: [
      'Empresa de energia solar',
      'Instalação de energia fotovoltaica',
      'Ar condicionado e climatização',
    ],
    placeTypes: ['electrician', 'contractor'],
    keywords: ['solar', 'fotovoltaica', 'energia', 'climatizacao', 'ar condicionado'],
  },
];

export function normalizeText(value: string): string {
  return (value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function getSegmentDeepQueries(segmentInput: string): {
  queries: string[];
  definition: SegmentDefinition | null;
} {
  const safeInput = typeof segmentInput === 'string' ? segmentInput : '';
  const normalizedInput = normalizeText(safeInput);
  const matched =
    SEGMENT_DEFINITIONS.find(
      (s) =>
        s.id === safeInput ||
        normalizeText(s.label) === normalizedInput ||
        s.deepQueries.some((q) => normalizeText(q) === normalizedInput)
    ) || null;

  if (matched) {
    return { queries: matched.deepQueries.slice(0, 5), definition: matched };
  }

  const clean = safeInput.trim();
  const baseWords = normalizedInput.split(' ').filter(Boolean);
  const queries = clean ? [clean] : [];
  if (clean && baseWords.length <= 2) {
    queries.push(`Empresa de ${clean}`);
    queries.push(`Serviços de ${clean}`);
  }
  return { queries: Array.from(new Set(queries)), definition: null };
}

export function evaluateSegmentCompatibility(params: {
  searchedSegment: string;
  placeName: string;
  category: string;
  types: string[];
}): { level: 'high' | 'partial' | 'none'; points: number; reason: string } {
  const { definition } = getSegmentDeepQueries(params.searchedSegment);
  const normCategory = normalizeText(params.category);
  const normName = normalizeText(params.placeName);
  const normSearch = normalizeText(params.searchedSegment);
  const combinedText = `${normCategory} ${normName}`;
  const lowerTypes = (params.types || []).map((t) => t.toLowerCase());

  if (definition) {
    const typeMatch = lowerTypes.some((t) => definition.placeTypes.includes(t));
    const kwMatch = definition.keywords.some((kw) => combinedText.includes(normalizeText(kw)));

    if (typeMatch && kwMatch) {
      return {
        level: 'high',
        points: 25,
        reason: `Categoria "${params.category}" e tipo do perfil diretamente compatíveis com ${definition.label}.`,
      };
    }
    if (typeMatch || kwMatch) {
      return {
        level: 'high',
        points: 25,
        reason: `Perfil empresarial compatível com o segmento ${definition.label}.`,
      };
    }

    const searchTokens = normSearch.split(' ').filter((w) => w.length >= 4);
    if (searchTokens.some((tok) => combinedText.includes(tok))) {
      return {
        level: 'partial',
        points: 10,
        reason: `Correspondência parcial com o segmento "${params.searchedSegment}".`,
      };
    }

    // Generic point_of_interest/establishment without contradicting type
    if (
      lowerTypes.includes('point_of_interest') ||
      lowerTypes.includes('establishment') ||
      lowerTypes.length === 0
    ) {
      return {
        level: 'partial',
        points: 10,
        reason: `Categoria genérica no Google ("${params.category}"); recomenda-se validar aderência ao segmento.`,
      };
    }

    return {
      level: 'none',
      points: 0,
      reason: `Categoria "${params.category}" não apresenta correspondência clara com ${definition.label}.`,
    };
  }

  // Custom segment matching
  const tokens = normSearch.split(' ').filter((w) => w.length >= 3);
  const matchedTokens = tokens.filter((tok) => combinedText.includes(tok));
  if (tokens.length > 0 && matchedTokens.length >= Math.max(1, Math.ceil(tokens.length / 2))) {
    return {
      level: 'high',
      points: 25,
      reason: `Perfil diretamente compatível com o segmento "${params.searchedSegment}".`,
    };
  }
  if (matchedTokens.length > 0 || lowerTypes.includes('establishment')) {
    return {
      level: 'partial',
      points: 10,
      reason: `Correspondência parcial com "${params.searchedSegment}".`,
    };
  }
  return {
    level: 'none',
    points: 0,
    reason: `Sem correspondência direta identificada para "${params.searchedSegment}".`,
  };
}

export function calculateLeadScore(input: {
  name: string;
  category: string;
  address: string;
  phone: string;
  websiteStatus: WebsiteStatus;
  website: string;
  businessStatus: string;
  geoStatus: GeoValidationStatus;
  searchedSegment: string;
  types: string[];
}): LeadScoreResult {
  const breakdown: ScoreCriterionBreakdown[] = [];

  // A) Ausência de site informado: até 25 pontos
  let websitePoints = 0;
  let websiteReason = 'Site informado no perfil público do Google.';
  if (input.websiteStatus === 'sem_site_informado') {
    websitePoints = 25;
    websiteReason = 'Sem site informado no Google (+25 pts por potencial de presença web).';
  } else if (input.websiteStatus === 'nao_verificado') {
    websitePoints = 0;
    websiteReason = 'Situação do site não verificada (0 pts por ausência).';
  }
  breakdown.push({
    key: 'website',
    label: 'Presença de site',
    points: websitePoints,
    maxPoints: 25,
    reason: websiteReason,
  });

  // B) Compatibilidade do segmento: até 25 pontos
  const segCompat = evaluateSegmentCompatibility({
    searchedSegment: input.searchedSegment,
    placeName: input.name,
    category: input.category,
    types: input.types,
  });
  breakdown.push({
    key: 'segment',
    label: 'Compatibilidade do segmento',
    points: segCompat.points,
    maxPoints: 25,
    reason: segCompat.reason,
  });

  // C) Telefone comercial público: até 15 pontos
  const phoneDigits = (input.phone || '').replace(/\D/g, '');
  const hasValidPhone = phoneDigits.length >= 8;
  const phonePoints = hasValidPhone ? 15 : 0;
  breakdown.push({
    key: 'phone',
    label: 'Telefone comercial público',
    points: phonePoints,
    maxPoints: 15,
    reason: hasValidPhone
      ? 'Telefone comercial público válido identificado.'
      : 'Telefone comercial não informado no perfil público.',
  });

  // D) Situação operacional: até 10 pontos
  const opStatus = (input.businessStatus || '').toUpperCase();
  const isOperational = opStatus === 'OPERATIONAL';
  const opPoints = isOperational ? 10 : 0;
  breakdown.push({
    key: 'operational',
    label: 'Situação operacional',
    points: opPoints,
    maxPoints: 10,
    reason: isOperational
      ? 'Empresa indicada como operacional no Google.'
      : opStatus === 'CLOSED_TEMPORARILY'
        ? 'Empresa indicada como temporariamente fechada.'
        : 'Situação operacional não confirmada.',
  });

  // E) Correspondência geográfica: até 20 pontos
  const geoPoints = input.geoStatus === 'confirmed' ? 20 : 0;
  breakdown.push({
    key: 'geography',
    label: 'Correspondência geográfica',
    points: geoPoints,
    maxPoints: 20,
    reason:
      input.geoStatus === 'confirmed'
        ? 'Cidade e UF confirmadas no endereço oficial.'
        : 'Localização municipal não confirmada automaticamente (revisar endereço).',
  });

  // F) Perfil empresarial identificável: até 5 pontos
  let profilePoints = 0;
  if (input.name && input.name !== 'Empresa sem nome informado') profilePoints += 2;
  if (input.category && input.category !== '—') profilePoints += 1;
  if (input.address && input.address !== 'Endereço não informado') profilePoints += 2;
  profilePoints = Math.min(5, profilePoints);
  breakdown.push({
    key: 'profile',
    label: 'Perfil identificável',
    points: profilePoints,
    maxPoints: 5,
    reason:
      profilePoints === 5
        ? 'Nome, categoria e endereço comercial identificáveis.'
        : 'Dados básicos parciais no perfil público.',
  });

  const rawTotal = breakdown.reduce((sum, item) => sum + item.points, 0);
  const total = Math.max(0, Math.min(100, rawTotal));

  const classification: LeadClassification =
    total >= 80 ? 'alto' : total >= 60 ? 'medio' : 'baixo';

  const classificationLabel =
    classification === 'alto'
      ? 'Alto potencial'
      : classification === 'medio'
        ? 'Médio potencial'
        : 'Baixo potencial';

  // Commercial opportunities (investigative language only)
  const opportunities: string[] = [];
  if (input.websiteStatus === 'sem_site_informado') {
    opportunities.push(
      'Empresa sem site informado no Google. Pode ser interessante oferecer uma apresentação profissional na internet.'
    );
  } else if (input.websiteStatus === 'site_informado') {
    opportunities.push(
      'Empresa com site informado. Pode ser interessante avaliar oportunidades de melhoria de presença digital e gestão de redes sociais.'
    );
  } else {
    opportunities.push(
      'Situação de website não verificada. Vale confirmar os canais digitais atuais antes da abordagem.'
    );
  }

  if (hasValidPhone) {
    opportunities.push(
      'Telefone comercial disponível. Existe um canal público para contato inicial.'
    );
  } else {
    opportunities.push(
      'Sem telefone público listado no Google. Pode exigir busca de canal complementar antes da abordagem.'
    );
  }

  if (segCompat.level === 'high') {
    opportunities.push(
      `Segmento aderente (${input.category}). Boa oportunidade para explorar posicionamento digital e captação local.`
    );
  } else if (segCompat.level === 'none') {
    opportunities.push(
      'Categoria distante do segmento pesquisado. Avalie se o perfil realmente faz parte do público-alvo desejado.'
    );
  }

  if (input.geoStatus !== 'confirmed') {
    opportunities.push(
      'Localização municipal não confirmada automaticamente. Verifique cidade e UF no endereço antes de avançar.'
    );
  }

  const justification = breakdown
    .map((b) => `${b.label}: ${b.points}/${b.maxPoints} pts (${b.reason})`)
    .join(' | ');

  return {
    total,
    classification,
    classificationLabel,
    segmentCompatible: segCompat.level !== 'none',
    justification,
    breakdown,
    opportunities,
  };
}
