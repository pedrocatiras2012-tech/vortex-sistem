import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { SchemaTableStatus } from '../types';

function sanitizeEnvValue(raw: unknown): string {
  if (typeof raw !== 'string') return '';
  let val = raw.trim();
  if (
    (val.startsWith('"') && val.endsWith('"')) ||
    (val.startsWith("'") && val.endsWith("'"))
  ) {
    val = val.slice(1, -1).trim();
  }
  return val;
}

function normalizeSupabaseUrl(raw: string): string {
  try {
    const parsed = new URL(raw);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return '';
    return parsed.origin;
  } catch {
    return '';
  }
}

function isSecretKey(key: string): boolean {
  if (key.startsWith('sb_secret_')) return true;
  try {
    const parts = key.split('.');
    if (parts.length !== 3) return false;
    const json = atob(parts[1].replace(/-/g, '+').replace(/_/g, '/'));
    const payload = JSON.parse(json) as { role?: string };
    return payload.role === 'service_role';
  } catch {
    return false;
  }
}

function createSupabaseInstance(url: string, anonKey: string): SupabaseClient {
  return createClient(url, anonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
}

function hasValidConfig(url: string, anonKey: string): boolean {
  return Boolean(url && anonKey && url.startsWith('http') && anonKey.length > 20 && !isSecretKey(anonKey));
}

const buildTimeUrl = normalizeSupabaseUrl(sanitizeEnvValue(import.meta.env.VITE_SUPABASE_URL));
const buildTimeAnonKey = sanitizeEnvValue(import.meta.env.VITE_SUPABASE_ANON_KEY);

export let isSupabaseConfigured = false;
export let supabase: SupabaseClient | null = null;
export let supabaseConfigError: string | null = null;

let activeUrl = '';
let activeKey = '';

function applyConfig(url: string, anonKey: string): boolean {
  const normalizedUrl = normalizeSupabaseUrl(sanitizeEnvValue(url));
  const cleanKey = sanitizeEnvValue(anonKey);

  if (!hasValidConfig(normalizedUrl, cleanKey)) {
    return false;
  }

  if (supabase && activeUrl === normalizedUrl && activeKey === cleanKey) {
    isSupabaseConfigured = true;
    supabaseConfigError = null;
    return true;
  }

  activeUrl = normalizedUrl;
  activeKey = cleanKey;
  supabase = createSupabaseInstance(normalizedUrl, cleanKey);
  isSupabaseConfigured = true;
  supabaseConfigError = null;
  return true;
}

/**
 * Always prioritizes live runtime Secrets served by /api/supabase-config so
 * stale build-time import.meta.env values never override updated Secrets.
 */
export async function initSupabase(): Promise<boolean> {
  try {
    const response = await fetch(`/api/supabase-config?t=${Date.now()}`, {
      cache: 'no-store',
      headers: { 'Cache-Control': 'no-cache' },
    });

    const data = (await response.json().catch(() => ({}))) as {
      configured?: boolean;
      url?: string;
      anonKey?: string;
      error?: string;
    };

    if (data.error) {
      supabaseConfigError = data.error;
      supabase = null;
      isSupabaseConfigured = false;
      return false;
    }

    if (data.configured && data.url && data.anonKey) {
      return applyConfig(data.url, data.anonKey);
    }
  } catch {
    // Fallback below only if backend endpoint is unavailable
  }

  if (buildTimeAnonKey && isSecretKey(buildTimeAnonKey)) {
    supabaseConfigError =
      'Chave secreta (service_role ou sb_secret_) detectada. Utilize apenas a chave pública anon ou publishable.';
    return false;
  }

  return applyConfig(buildTimeUrl, buildTimeAnonKey);
}

export function getSupabaseClient(): SupabaseClient {
  if (!supabase) {
    throw new Error(
      supabaseConfigError ||
        'Conexão com o Supabase não configurada. Defina VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY nos Secrets do ambiente.'
    );
  }
  return supabase;
}

const KNOWN_TABLES = [
  'profiles',
  'team_invites',
  'companies',
  'commissions',
  'payments',
  'expenses',
  'marketing_tasks',
  'prospecting_logs',
  'prospects',
  'prospect_interactions',
  'prospect_activities',
  'commercial_proposals',
  'lead_assignments_history',
  'sale_collaborators',
  'system_settings',
];

export async function probeDatabaseSchema(): Promise<SchemaTableStatus[]> {
  if (!supabase) {
    return KNOWN_TABLES.map((table) => ({
      table,
      exists: false,
      accessible: false,
      rowCount: null,
      error: 'Supabase não configurado',
    }));
  }

  const results = await Promise.all(
    KNOWN_TABLES.map(async (table): Promise<SchemaTableStatus> => {
      try {
        const { count, error } = await supabase!
          .from(table)
          .select('*', { count: 'exact', head: true });

        if (!error) {
          return {
            table,
            exists: true,
            accessible: true,
            rowCount: count ?? 0,
          };
        }

        const code = (error as { code?: string }).code || '';
        const msg = error.message || '';
        const missing =
          code === '42P01' ||
          code === 'PGRST205' ||
          msg.toLowerCase().includes('could not find the table') ||
          msg.toLowerCase().includes('does not exist');

        if (missing) {
          return {
            table,
            exists: false,
            accessible: false,
            rowCount: null,
            error: 'Tabela não encontrada neste projeto',
          };
        }

        return {
          table,
          exists: true,
          accessible: false,
          rowCount: null,
          error: msg,
        };
      } catch (err) {
        return {
          table,
          exists: false,
          accessible: false,
          rowCount: null,
          error: err instanceof Error ? err.message : 'Erro ao consultar tabela',
        };
      }
    })
  );

  return results;
}
