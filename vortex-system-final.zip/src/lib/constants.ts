import type {
  ActivityPriority,
  CommissionStatus,
  CompanyStatus,
  ContactType,
  ModulePermissions,
  ProposalStatus,
  ProspectStatus,
  SaleParticipationRole,
  SaleStatus,
  ServiceType,
  TaskCategory,
  TaskPriority,
  TaskStatus,
  UserRole,
} from '../types';

export const ROLE_LABELS: Record<UserRole, string> = {
  proprietario: 'Proprietário',
  administrador: 'Administrador',
  gerente: 'Gerente',
  colaborador: 'Colaborador',
};

export const DEFAULT_PERMISSIONS_BY_ROLE: Record<UserRole, ModulePermissions> = {
  proprietario: {
    dashboard: true,
    prospeccao: true,
    empresas: true,
    comissoes: true,
    financeiro: true,
    marketing: true,
    relatorios: true,
    equipe: true,
    configuracoes: true,
    ver_todos_leads: true,
    distribuir_leads: true,
    visualizar_comissoes_equipe: true,
  },
  administrador: {
    dashboard: true,
    prospeccao: true,
    empresas: true,
    comissoes: true,
    financeiro: true,
    marketing: true,
    relatorios: true,
    equipe: true,
    configuracoes: true,
    ver_todos_leads: true,
    distribuir_leads: true,
    visualizar_comissoes_equipe: true,
  },
  gerente: {
    dashboard: true,
    prospeccao: true,
    empresas: true,
    comissoes: true,
    financeiro: false,
    marketing: true,
    relatorios: true,
    equipe: true,
    configuracoes: false,
    ver_todos_leads: true,
    distribuir_leads: true,
    visualizar_comissoes_equipe: true,
  },
  colaborador: {
    dashboard: true,
    prospeccao: true,
    empresas: true,
    comissoes: true,
    financeiro: false,
    marketing: true,
    relatorios: false,
    equipe: false,
    configuracoes: false,
    ver_todos_leads: false,
    distribuir_leads: false,
    visualizar_comissoes_equipe: false,
  },
};

export const PERMISSION_LABELS: Record<keyof ModulePermissions, string> = {
  dashboard: 'Dashboard Principal',
  prospeccao: 'Prospecção (CRM & Bot)',
  empresas: 'Empresas e Clientes',
  comissoes: 'Comissões',
  financeiro: 'Financeiro',
  marketing: 'Marketing e Tarefas',
  relatorios: 'Relatórios e Exportação',
  equipe: 'Gestão de Equipe',
  configuracoes: 'Configurações do Sistema',
  ver_todos_leads: 'Visualizar todos os leads da equipe',
  distribuir_leads: 'Distribuir e transferir leads',
  visualizar_comissoes_equipe: 'Visualizar comissões de outros colaboradores',
};

export const PROSPECT_STATUS_OPTIONS: { value: ProspectStatus; label: string; colorClass: string }[] = [
  { value: 'novo', label: 'Novo lead', colorClass: 'text-sky-300 border-sky-500/30 bg-sky-500/10' },
  { value: 'contato_pendente', label: 'Contato pendente', colorClass: 'text-slate-300 border-slate-500/30 bg-slate-500/10' },
  { value: 'primeiro_contato', label: 'Primeiro contato realizado', colorClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10' },
  { value: 'aguardando_resposta', label: 'Aguardando resposta', colorClass: 'text-amber-300 border-amber-500/30 bg-amber-500/10' },
  { value: 'interessado', label: 'Interessado', colorClass: 'text-indigo-300 border-indigo-500/30 bg-indigo-500/10' },
  { value: 'reuniao_agendada', label: 'Reunião / apresentação agendada', colorClass: 'text-purple-300 border-purple-500/30 bg-purple-500/10' },
  { value: 'proposta_enviada', label: 'Proposta enviada', colorClass: 'text-violet-300 border-violet-500/30 bg-violet-500/10' },
  { value: 'em_negociacao', label: 'Em negociação', colorClass: 'text-cyan-300 border-cyan-500/30 bg-cyan-500/10' },
  { value: 'convertido', label: 'Venda fechada', colorClass: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10' },
  { value: 'perdido', label: 'Venda perdida', colorClass: 'text-rose-300 border-rose-500/30 bg-rose-500/10' },
  { value: 'sem_interesse', label: 'Sem interesse', colorClass: 'text-zinc-300 border-zinc-500/30 bg-zinc-500/10' },
];

export const CONTACT_TYPE_OPTIONS: { value: ContactType; label: string }[] = [
  { value: 'primeiro_contato', label: 'Primeiro contato' },
  { value: 'mensagem_enviada', label: 'Mensagem enviada' },
  { value: 'whatsapp', label: 'WhatsApp' },
  { value: 'ligacao', label: 'Ligação realizada' },
  { value: 'resposta_recebida', label: 'Resposta recebida' },
  { value: 'reuniao', label: 'Reunião realizada' },
  { value: 'apresentacao_enviada', label: 'Apresentação enviada' },
  { value: 'proposta_enviada', label: 'Proposta enviada' },
  { value: 'negociacao', label: 'Negociação' },
  { value: 'observacao_interna', label: 'Observações internas' },
  { value: 'email', label: 'E-mail' },
  { value: 'outro', label: 'Outros acontecimentos' },
];

export const ACTIVITY_PRIORITY_OPTIONS: { value: ActivityPriority; label: string; colorClass: string }[] = [
  { value: 'baixa', label: 'Baixa', colorClass: 'text-slate-300 border-slate-500/30 bg-slate-500/10' },
  { value: 'media', label: 'Média', colorClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10' },
  { value: 'alta', label: 'Alta', colorClass: 'text-amber-300 border-amber-500/30 bg-amber-500/10' },
  { value: 'urgente', label: 'Urgente', colorClass: 'text-rose-300 border-rose-500/30 bg-rose-500/10' },
];

export const PROPOSAL_STATUS_OPTIONS: { value: ProposalStatus; label: string; colorClass: string }[] = [
  { value: 'em_preparacao', label: 'Em preparação', colorClass: 'text-slate-300 border-slate-500/30 bg-slate-500/10' },
  { value: 'enviada', label: 'Enviada', colorClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10' },
  { value: 'visualizada', label: 'Visualizada (confirmada)', colorClass: 'text-cyan-300 border-cyan-500/30 bg-cyan-500/10' },
  { value: 'em_negociacao', label: 'Em negociação', colorClass: 'text-amber-300 border-amber-500/30 bg-amber-500/10' },
  { value: 'aceita', label: 'Aceita', colorClass: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10' },
  { value: 'recusada', label: 'Recusada', colorClass: 'text-rose-300 border-rose-500/30 bg-rose-500/10' },
  { value: 'expirada', label: 'Expirada', colorClass: 'text-zinc-300 border-zinc-500/30 bg-zinc-500/10' },
];

export const SALE_STATUS_OPTIONS: { value: SaleStatus; label: string; colorClass: string }[] = [
  { value: 'aberta', label: 'Em aberto', colorClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10' },
  { value: 'ganha', label: 'Venda fechada', colorClass: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10' },
  { value: 'perdida', label: 'Venda perdida', colorClass: 'text-rose-300 border-rose-500/30 bg-rose-500/10' },
  { value: 'cancelada', label: 'Cancelada', colorClass: 'text-zinc-300 border-zinc-500/30 bg-zinc-500/10' },
];

export const SALE_PARTICIPATION_ROLE_OPTIONS: { value: SaleParticipationRole; label: string }[] = [
  { value: 'prospeccao', label: 'Prospecção (quem prospectou)' },
  { value: 'atendimento', label: 'Atendimento (quem atendeu)' },
  { value: 'negociacao', label: 'Negociação (quem negociou)' },
  { value: 'fechamento', label: 'Fechamento (quem fechou a venda)' },
];

export const DEFAULT_JOB_ROLES = [
  'Administrador',
  'Diretor',
  'Gerente comercial',
  'Marketing',
  'Marketing Digital',
  'Prospecção',
  'Prospectador',
  'Vendas',
  'Consultor Comercial',
  'Atendimento',
  'Financeiro',
  'Desenvolvimento de sites',
  'Gestão de redes sociais',
  'Colaborador',
];

export const DEFAULT_DEPARTMENTS = [
  'Diretoria',
  'Comercial & Vendas',
  'Prospecção',
  'Marketing',
  'Atendimento ao Cliente',
  'Desenvolvimento Web',
  'Gestão de Redes Sociais',
  'Financeiro',
  'Operações',
];

export const PROSPECT_ORIGIN_OPTIONS = [
  'Indicação',
  'Instagram',
  'Google / Maps',
  'Tráfego Pago',
  'Prospecção Ativa',
  'Site / Formulário',
  'LinkedIn',
  'Evento / Networking',
  'Outro',
];

export const SERVICE_TYPE_OPTIONS: { value: ServiceType; label: string }[] = [
  { value: 'criacao_sites', label: 'Criação de sites' },
  { value: 'gestao_redes', label: 'Gestão de redes sociais' },
  { value: 'presenca_digital', label: 'Presença digital' },
  { value: 'automacao', label: 'Automação' },
  { value: 'outros', label: 'Outros serviços' },
];

export const COMPANY_STATUS_OPTIONS: { value: CompanyStatus; label: string; colorClass: string }[] = [
  { value: 'ativo', label: 'Ativo', colorClass: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10' },
  { value: 'onboarding', label: 'Em implantação', colorClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10' },
  { value: 'pausado', label: 'Pausado', colorClass: 'text-amber-300 border-amber-500/30 bg-amber-500/10' },
  { value: 'cancelado', label: 'Cancelado', colorClass: 'text-rose-300 border-rose-500/30 bg-rose-500/10' },
];

export const COMMISSION_STATUS_OPTIONS: { value: CommissionStatus; label: string; colorClass: string }[] = [
  { value: 'prevista', label: 'Prevista', colorClass: 'text-cyan-300 border-cyan-500/30 bg-cyan-500/10' },
  { value: 'pendente', label: 'Pendente', colorClass: 'text-amber-300 border-amber-500/30 bg-amber-500/10' },
  { value: 'aprovada', label: 'Aprovada', colorClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10' },
  { value: 'paga', label: 'Paga', colorClass: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10' },
  { value: 'cancelada', label: 'Cancelada', colorClass: 'text-rose-300 border-rose-500/30 bg-rose-500/10' },
];

export const PAYMENT_CATEGORIES = [
  'Mensalidade',
  'Projeto / Implantação',
  'Consultoria',
  'Automação',
  'Setup Inicial',
  'Outros',
];

export const EXPENSE_CATEGORIES = [
  'Infraestrutura & Software',
  'Tráfego & Marketing',
  'Equipe & Terceiros',
  'Comissões Pagas',
  'Impostos & Taxas',
  'Operacional / Escritório',
  'Outros',
];

export const TASK_CATEGORY_OPTIONS: { value: TaskCategory; label: string }[] = [
  { value: 'marketing', label: 'Marketing' },
  { value: 'producao_conteudo', label: 'Produção de conteúdo' },
  { value: 'atendimento', label: 'Atendimento' },
  { value: 'comercial', label: 'Comercial' },
];

export const TASK_PRIORITY_OPTIONS: { value: TaskPriority; label: string; colorClass: string }[] = [
  { value: 'baixa', label: 'Baixa', colorClass: 'text-slate-300 border-slate-500/30 bg-slate-500/10' },
  { value: 'media', label: 'Média', colorClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10' },
  { value: 'alta', label: 'Alta', colorClass: 'text-amber-300 border-amber-500/30 bg-amber-500/10' },
  { value: 'urgente', label: 'Urgente', colorClass: 'text-rose-300 border-rose-500/30 bg-rose-500/10' },
];

export const TASK_STATUS_OPTIONS: { value: TaskStatus; label: string; colorClass: string }[] = [
  { value: 'pendente', label: 'Pendente', colorClass: 'text-amber-300 border-amber-500/30 bg-amber-500/10' },
  { value: 'em_andamento', label: 'Em andamento', colorClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10' },
  { value: 'concluida', label: 'Concluída', colorClass: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10' },
  { value: 'cancelada', label: 'Cancelada', colorClass: 'text-rose-300 border-rose-500/30 bg-rose-500/10' },
];
