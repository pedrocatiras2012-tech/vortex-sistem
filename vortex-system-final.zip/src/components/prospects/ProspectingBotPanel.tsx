import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Bot,
  CheckCircle2,
  ChevronDown,
  ExternalLink,
  Eye,
  Filter,
  Globe,
  Loader2,
  MapPin,
  MessageCircle,
  Phone,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
} from 'lucide-react';
import {
  BRAZIL_STATES_LIST,
  SEGMENT_DEFINITIONS,
  calculateLeadScore,
  normalizeText,
  type GeoValidationStatus,
  type LeadScoreResult,
  type SearchMode,
  type WebsiteStatus,
} from '../../lib/leadScoring';
import { PROSPECT_STATUS_OPTIONS } from '../../lib/constants';
import { formatDateTime, todayISO } from '../../lib/formatters';
import { getSupabaseClient } from '../../lib/supabase';
import * as db from '../../services/database';
import type { Company, Prospect, ProspectStatus, UserProfile } from '../../types';
import { useToast } from '../../contexts/ToastContext';
import { EmptyState } from '../ui/EmptyState';
import { Modal } from '../ui/Modal';
import { Pagination } from '../ui/Pagination';
import { StatusTag } from '../ui/StatusTag';

interface IbgeMunicipality {
  id: number;
  name: string;
  normalizedName: string;
}

interface ContinuationItem {
  queryTerm: string;
  pageToken?: string;
  pageNumber: number;
}

interface RawBotPlaceResult {
  placeId: string;
  name: string;
  address: string;
  city: string;
  state: string;
  detectedCity: string;
  detectedState: string;
  geoStatus: GeoValidationStatus;
  phone: string;
  internationalPhone: string;
  whatsappDigits: string;
  whatsappUrl: string;
  website: string;
  websiteStatus: WebsiteStatus;
  hasWebsiteListed: boolean;
  category: string;
  types: string[];
  businessStatus: string;
  rating: number | null;
  userRatingCount: number | null;
  googleMapsUri: string;
  matchedQuery: string;
}

interface EnrichedBotPlace extends RawBotPlaceResult {
  score: LeadScoreResult;
  searchedAt: string;
}

interface ProspectingBotPanelProps {
  prospects: Prospect[];
  companies: Company[];
  profiles: UserProfile[];
  currentUser: UserProfile;
  canDistributeLeads: boolean;
  onRefresh: () => Promise<void>;
}

function normalizePhoneKey(raw: string): string {
  const digits = (raw || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('55') && digits.length >= 12) {
    return digits.slice(2);
  }
  return digits;
}

function normalizeHostKey(rawUrl: string): string {
  if (!rawUrl) return '';
  try {
    const withProto = rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`;
    const u = new URL(withProto);
    return u.hostname.replace(/^www\./i, '').toLowerCase();
  } catch {
    return rawUrl
      .replace(/^https?:\/\//i, '')
      .replace(/^www\./i, '')
      .split('/')[0]
      .toLowerCase()
      .trim();
  }
}

function scoreColorClasses(classification: 'alto' | 'medio' | 'baixo'): string {
  if (classification === 'alto') {
    return 'text-emerald-300 border-emerald-500/35 bg-emerald-500/10';
  }
  if (classification === 'medio') {
    return 'text-amber-300 border-amber-500/35 bg-amber-500/10';
  }
  return 'text-slate-300 border-slate-600/60 bg-slate-700/20';
}

function extractCityPart(cityField: string): string {
  return normalizeText((cityField || '').split('-')[0].split('/')[0]);
}

export function ProspectingBotPanel({
  prospects,
  companies,
  profiles,
  currentUser,
  canDistributeLeads,
  onRefresh,
}: ProspectingBotPanelProps) {
  const { showSuccess, showError, showInfo } = useToast();

  const [apiConfigured, setApiConfigured] = useState<boolean | null>(null);
  const [checkingStatus, setCheckingStatus] = useState(true);

  // Part 1: State -> IBGE Municipalities Cache & Searchable Combobox
  const cityCacheRef = useRef<Map<string, IbgeMunicipality[]>>(new Map());
  const cityDropdownRef = useRef<HTMLDivElement | null>(null);

  const [stateUf, setStateUf] = useState('');
  const [municipalities, setMunicipalities] = useState<IbgeMunicipality[]>([]);
  const [loadingCities, setLoadingCities] = useState(false);
  const [citiesError, setCitiesError] = useState<string | null>(null);

  const [citySearchText, setCitySearchText] = useState('');
  const [selectedCity, setSelectedCity] = useState<IbgeMunicipality | null>(null);
  const [cityDropdownOpen, setCityDropdownOpen] = useState(false);

  // Segment & Mode
  const [selectedSegmentId, setSelectedSegmentId] = useState(SEGMENT_DEFINITIONS[0].id);
  const [customSegment, setCustomSegment] = useState('');
  const [searchMode, setSearchMode] = useState<SearchMode>('padrao');
  const [onlyWithoutWebsiteOnSearch, setOnlyWithoutWebsiteOnSearch] = useState(false);

  // Search State & Results
  const [searching, setSearching] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [progressMessage, setProgressMessage] = useState<string | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [results, setResults] = useState<EnrichedBotPlace[]>([]);
  const [continuationQueue, setContinuationQueue] = useState<ContinuationItem[]>([]);
  const [hasMore, setHasMore] = useState(false);

  // Session Metadata
  const [lastQuery, setLastQuery] = useState<{
    city: string;
    state: string;
    stateName: string;
    segment: string;
    mode: SearchMode;
    queriesExecuted: string[];
    filteredOutGeoCount: number;
    filteredOutClosedCount: number;
    unconfirmedGeoCount: number;
    searchedAt: string;
  } | null>(null);
  const [apiCallsSession, setApiCallsSession] = useState(0);

  // Part 5: Filters & Sorting
  const [resultFilterText, setResultFilterText] = useState('');
  const [potentialFilter, setPotentialFilter] = useState<'todos' | 'alto' | 'medio' | 'baixo'>('todos');
  const [websiteFilter, setWebsiteFilter] = useState<'todos' | 'sem_site' | 'com_site'>('todos');
  const [phoneFilter, setPhoneFilter] = useState<'todos' | 'com_telefone' | 'sem_telefone'>('todos');
  const [crmFilter, setCrmFilter] = useState<'todos' | 'nao_cadastrados' | 'ja_cadastrados'>('todos');
  const [operationalFilter, setOperationalFilter] = useState<'todos' | 'operacional'>('todos');
  const [geoFilter, setGeoFilter] = useState<'todos' | 'confirmada' | 'nao_confirmada'>('todos');
  const [sortBy, setSortBy] = useState<
    'score_desc' | 'score_asc' | 'name_asc' | 'category_asc' | 'city_asc' | 'date_desc'
  >('score_desc');
  const [page, setPage] = useState(1);
  const pageSize = 10;

  // WhatsApp Manual Greeting
  const [whatsappTemplate, setWhatsappTemplate] = useState(
    'Olá! Vi o perfil da {{empresa}} no Google e gostaria de apresentar uma oportunidade para fortalecer a presença digital de vocês.'
  );

  // Detail Modal ("Ficha completa") & Save States
  const [detailPlace, setDetailPlace] = useState<EnrichedBotPlace | null>(null);
  const [savingPlaceIds, setSavingPlaceIds] = useState<Record<string, boolean>>({});
  const [recentlySavedIds, setRecentlySavedIds] = useState<Record<string, boolean>>({});

  // Save defaults into CRM (responsible/unassigned, initial stage, optional activity)
  const [saveResponsibleId, setSaveResponsibleId] = useState<string>(currentUser.id);
  const [saveInitialStatus, setSaveInitialStatus] = useState<ProspectStatus>('novo');
  const [saveNextActivityTitle, setSaveNextActivityTitle] = useState<string>('');
  const [saveNextActivityDate, setSaveNextActivityDate] = useState<string>('');

  useEffect(() => {
    let active = true;
    const checkStatus = async () => {
      setCheckingStatus(true);
      try {
        const res = await fetch('/api/prospecting/status', { cache: 'no-store' });
        const data = (await res.json()) as { configured?: boolean };
        if (active) setApiConfigured(Boolean(data.configured));
      } catch {
        if (active) setApiConfigured(false);
      } finally {
        if (active) setCheckingStatus(false);
      }
    };
    void checkStatus();
    return () => {
      active = false;
    };
  }, []);

  // Close city dropdown when clicking outside
  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (cityDropdownRef.current && !cityDropdownRef.current.contains(e.target as Node)) {
        setCityDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const loadCitiesForState = async (uf: string) => {
    if (!uf) {
      setMunicipalities([]);
      return;
    }

    const cached = cityCacheRef.current.get(uf);
    if (cached) {
      setMunicipalities(cached);
      setCitiesError(null);
      return;
    }

    setLoadingCities(true);
    setCitiesError(null);
    try {
      const res = await fetch(`/api/prospecting/municipalities?uf=${encodeURIComponent(uf)}`);
      const payload = (await res.json().catch(() => ({}))) as {
        municipalities?: IbgeMunicipality[];
        error?: string;
      };
      if (!res.ok || !Array.isArray(payload.municipalities)) {
        throw new Error(
          payload.error || `Falha ao carregar municípios de ${uf} na base do IBGE.`
        );
      }
      cityCacheRef.current.set(uf, payload.municipalities);
      setMunicipalities(payload.municipalities);
    } catch (err) {
      setMunicipalities([]);
      setCitiesError(
        err instanceof Error
          ? err.message
          : 'Não foi possível carregar os municípios do IBGE no momento.'
      );
    } finally {
      setLoadingCities(false);
    }
  };

  // Part 1.3: Changing UF clears city, clears old results, invalidates pagination tokens
  const handleStateChange = (newUf: string) => {
    setStateUf(newUf);
    setSelectedCity(null);
    setCitySearchText('');
    setCityDropdownOpen(false);
    setResults([]);
    setContinuationQueue([]);
    setHasMore(false);
    setLastQuery(null);
    setSearchError(null);
    setDetailPlace(null);
    setPage(1);
    void loadCitiesForState(newUf);
  };

  // Filtered municipalities ONLY from selected UF, normalized for accents/case
  const filteredMunicipalities = useMemo(() => {
    const qNorm = normalizeText(citySearchText);
    if (!qNorm) return municipalities;
    const startsWith: IbgeMunicipality[] = [];
    const contains: IbgeMunicipality[] = [];
    for (const m of municipalities) {
      if (m.normalizedName.startsWith(qNorm)) {
        startsWith.push(m);
      } else if (m.normalizedName.includes(qNorm)) {
        contains.push(m);
      }
    }
    return [...startsWith, ...contains];
  }, [municipalities, citySearchText]);

  const activeSegmentLabel = useMemo(() => {
    if (selectedSegmentId === '__custom__') return customSegment.trim();
    return (
      SEGMENT_DEFINITIONS.find((s) => s.id === selectedSegmentId)?.label || ''
    );
  }, [selectedSegmentId, customSegment]);

  // Part 6: Deduplication index (PlaceID primary -> normalized phone -> website host -> name + city)
  const duplicateIndex = useMemo(() => {
    const prospectByPlaceId = new Map<string, Prospect>();
    const prospectByPhone = new Map<string, Prospect>();
    const prospectByHost = new Map<string, Prospect>();
    const prospectByNameCity = new Map<string, Prospect>();

    for (const p of prospects) {
      if (p.place_id) {
        prospectByPlaceId.set(p.place_id.trim(), p);
      }
      const placeIdMatch = (p.notes || '').match(/\[PlaceID:\s*([^\]]+)\]/i);
      if (placeIdMatch?.[1]) {
        prospectByPlaceId.set(placeIdMatch[1].trim(), p);
      }

      const p1 = normalizePhoneKey(p.phone);
      const p2 = normalizePhoneKey(p.whatsapp);
      if (p1.length >= 8) prospectByPhone.set(p1, p);
      if (p2.length >= 8) prospectByPhone.set(p2, p);

      const hKey = normalizeHostKey(p.website);
      if (hKey) prospectByHost.set(hKey, p);

      const nKey = normalizeText(p.company_name);
      const cKey = extractCityPart(p.city);
      if (nKey) {
        prospectByNameCity.set(`${nKey}|${cKey}`, p);
      }
    }

    const companyByPhone = new Map<string, Company>();
    const companyByNameCity = new Map<string, Company>();

    for (const c of companies) {
      const c1 = normalizePhoneKey(c.phone);
      const c2 = normalizePhoneKey(c.whatsapp);
      if (c1.length >= 8) companyByPhone.set(c1, c);
      if (c2.length >= 8) companyByPhone.set(c2, c);

      const nKey = normalizeText(c.name);
      const cKey = extractCityPart(c.city);
      if (nKey) {
        companyByNameCity.set(`${nKey}|${cKey}`, c);
      }
    }

    return {
      prospectByPlaceId,
      prospectByPhone,
      prospectByHost,
      prospectByNameCity,
      companyByPhone,
      companyByNameCity,
    };
  }, [prospects, companies]);

  const checkDuplicate = (item: EnrichedBotPlace): {
    isDuplicate: boolean;
    target?: 'prospect' | 'company';
    reason?: string;
  } => {
    if (item.placeId && recentlySavedIds[item.placeId]) {
      return { isDuplicate: true, target: 'prospect', reason: 'Salvo nesta sessão (PlaceID)' };
    }
    if (item.placeId && duplicateIndex.prospectByPlaceId.has(item.placeId)) {
      return { isDuplicate: true, target: 'prospect', reason: 'Mesmo Place ID no CRM' };
    }

    const phoneKeys = [
      normalizePhoneKey(item.phone),
      normalizePhoneKey(item.internationalPhone),
      normalizePhoneKey(item.whatsappDigits),
    ].filter((k) => k.length >= 8);

    for (const pk of phoneKeys) {
      if (duplicateIndex.prospectByPhone.has(pk)) {
        return { isDuplicate: true, target: 'prospect', reason: 'Telefone já cadastrado em Prospecção' };
      }
      if (duplicateIndex.companyByPhone.has(pk)) {
        return { isDuplicate: true, target: 'company', reason: 'Telefone já cadastrado em Empresas' };
      }
    }

    const hostKey = normalizeHostKey(item.website);
    if (hostKey && duplicateIndex.prospectByHost.has(hostKey)) {
      return { isDuplicate: true, target: 'prospect', reason: 'Mesmo domínio/site no CRM' };
    }

    // Name must match together with city (or if existing record has blank city)
    const nameKey = normalizeText(item.name);
    const cityKey = normalizeText(item.city);
    if (nameKey) {
      if (
        duplicateIndex.prospectByNameCity.has(`${nameKey}|${cityKey}`) ||
        duplicateIndex.prospectByNameCity.has(`${nameKey}|`)
      ) {
        return {
          isDuplicate: true,
          target: 'prospect',
          reason: `Empresa e cidade (${item.city}) já em Prospecção`,
        };
      }
      if (
        duplicateIndex.companyByNameCity.has(`${nameKey}|${cityKey}`) ||
        duplicateIndex.companyByNameCity.has(`${nameKey}|`)
      ) {
        return {
          isDuplicate: true,
          target: 'company',
          reason: `Empresa e cidade (${item.city}) já em Empresas`,
        };
      }
    }

    return { isDuplicate: false };
  };

  const resolveValidatedCity = (): IbgeMunicipality | null => {
    if (selectedCity && normalizeText(selectedCity.name) === normalizeText(citySearchText)) {
      return selectedCity;
    }
    const typedNorm = normalizeText(citySearchText);
    if (!typedNorm) return null;
    return municipalities.find((m) => m.normalizedName === typedNorm) || null;
  };

  const executeSearch = async (opts?: { isLoadMore?: boolean }) => {
    if (searching || loadingMore) return;

    const isLoadMore = Boolean(opts?.isLoadMore);
    const targetState = isLoadMore ? lastQuery?.state || stateUf : stateUf;
    const validCityObj = isLoadMore ? null : resolveValidatedCity();
    const targetCity = isLoadMore ? lastQuery?.city || '' : validCityObj?.name || '';
    const targetSegment = isLoadMore ? lastQuery?.segment || '' : activeSegmentLabel;
    const targetMode = isLoadMore ? lastQuery?.mode || searchMode : searchMode;

    if (!targetState) {
      showError('Estado obrigatório', 'Selecione primeiro um estado brasileiro (UF).');
      return;
    }

    if (!targetCity) {
      setSearchError(
        `Selecione um município válido de ${targetState} na lista filtrada. Cidades de outros estados não são aceitas.`
      );
      showError(
        'Município inválido ou não selecionado',
        `Escolha um município pertencente a ${targetState} antes de buscar.`
      );
      return;
    }

    if (!targetSegment) {
      showError('Segmento obrigatório', 'Selecione ou digite o segmento empresarial.');
      return;
    }

    if (isLoadMore) {
      setLoadingMore(true);
      setProgressMessage('Carregando mais empresas e validando localização...');
    } else {
      setSearching(true);
      setSearchError(null);
      setPage(1);
      setProgressMessage(
        targetMode === 'aprofundada'
          ? `Executando pesquisa aprofundada de ${targetSegment} em ${targetCity} - ${targetState}...`
          : `Consultando ${targetSegment} em ${targetCity} - ${targetState} no Google Places...`
      );
    }

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      try {
        const sb = getSupabaseClient();
        const { data: sess } = await sb.auth.getSession();
        if (!sess.session?.access_token) {
          throw new Error('Sua sessão não está válida. Entre novamente para pesquisar empresas.');
        }
        headers.Authorization = `Bearer ${sess.session.access_token}`;
      } catch (authError) {
        if (authError instanceof Error && authError.message.includes('sessão')) throw authError;
        throw new Error('Não foi possível validar seu acesso. Entre novamente e tente outra vez.');
      }

      const response = await fetch('/api/prospecting/search', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          city: targetCity,
          state: targetState,
          segment: targetSegment,
          mode: targetMode,
          continuationQueue: isLoadMore ? continuationQueue : undefined,
          seenPlaceIds: isLoadMore ? results.map((r) => r.placeId).filter(Boolean) : undefined,
          currentTotal: isLoadMore ? results.length : 0,
          pageSize: 20,
        }),
      });

      const rawBody = await response.text();
      let payload: {
        configured?: boolean;
        quotaExceeded?: boolean;
        city?: string;
        state?: string;
        stateName?: string;
        mode?: SearchMode;
        query?: string;
        queriesExecuted?: string[];
        apiCallsUsed?: number;
        filteredOutGeoCount?: number;
        filteredOutClosedCount?: number;
        unconfirmedGeoCount?: number;
        results?: RawBotPlaceResult[];
        continuationQueue?: ContinuationItem[];
        hasMore?: boolean;
        searchedAt?: string;
        error?: string;
        details?: string;
      } = {};

      try {
        payload = JSON.parse(rawBody);
      } catch {
        payload = {};
      }

      if (response.status === 429 || payload.quotaExceeded) {
        if (payload.quotaExceeded) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        setSearchError(
          payload.error || 'Limite de consultas atingido no momento. Tente novamente mais tarde.'
        );
        return;
      }

      if (!response.ok) {
        if (payload.configured === false) {
          setApiConfigured(false);
        }
        const detailSuffix = payload.details ? ` (${payload.details})` : '';
        setSearchError(
          payload.error
            ? `${payload.error}${detailSuffix}`
            : `Não foi possível consultar empresas no momento (HTTP ${response.status}).`
        );
        return;
      }

      setApiConfigured(true);
      const searchedAt = payload.searchedAt || new Date().toISOString();
      const incomingRaw = Array.isArray(payload.results) ? payload.results : [];
      const enrichedIncoming: EnrichedBotPlace[] = incomingRaw.map((item) => ({
        ...item,
        score: calculateLeadScore({
          name: item.name,
          category: item.category,
          address: item.address,
          phone: item.phone,
          websiteStatus: item.websiteStatus,
          website: item.website,
          businessStatus: item.businessStatus,
          geoStatus: item.geoStatus,
          searchedSegment: targetSegment,
          types: item.types || [],
        }),
        searchedAt,
      }));

      setApiCallsSession((prev) => prev + (Number(payload.apiCallsUsed) || 1));

      if (isLoadMore) {
        setResults((prev) => {
          const seen = new Set(prev.map((r) => r.placeId || `${r.name}|${r.address}`));
          const merged = [...prev];
          for (const item of enrichedIncoming) {
            const key = item.placeId || `${item.name}|${item.address}`;
            if (!seen.has(key)) {
              seen.add(key);
              merged.push(item);
            }
          }
          return merged;
        });
        setLastQuery((prev) =>
          prev
            ? {
                ...prev,
                queriesExecuted: Array.from(
                  new Set([...prev.queriesExecuted, ...(payload.queriesExecuted || [])])
                ),
                filteredOutGeoCount:
                  prev.filteredOutGeoCount + (Number(payload.filteredOutGeoCount) || 0),
                filteredOutClosedCount:
                  prev.filteredOutClosedCount + (Number(payload.filteredOutClosedCount) || 0),
                unconfirmedGeoCount:
                  prev.unconfirmedGeoCount + (Number(payload.unconfirmedGeoCount) || 0),
              }
            : prev
        );
      } else {
        setResults(enrichedIncoming);
        setLastQuery({
          city: payload.city || targetCity,
          state: payload.state || targetState,
          stateName: payload.stateName || targetState,
          segment: targetSegment,
          mode: targetMode,
          queriesExecuted: payload.queriesExecuted || [],
          filteredOutGeoCount: Number(payload.filteredOutGeoCount) || 0,
          filteredOutClosedCount: Number(payload.filteredOutClosedCount) || 0,
          unconfirmedGeoCount: Number(payload.unconfirmedGeoCount) || 0,
          searchedAt,
        });
        if (onlyWithoutWebsiteOnSearch) {
          setWebsiteFilter('sem_site');
        }
      }

      setContinuationQueue(Array.isArray(payload.continuationQueue) ? payload.continuationQueue : []);
      setHasMore(Boolean(payload.hasMore));
    } catch (err) {
      setSearchError(
        err instanceof Error
          ? err.message
          : 'Erro de rede ao consultar o servidor de prospecção.'
      );
    } finally {
      setSearching(false);
      setLoadingMore(false);
      setProgressMessage(null);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void executeSearch({ isLoadMore: false });
  };

  const handleSaveAsProspect = async (item: EnrichedBotPlace) => {
    const dup = checkDuplicate(item);
    if (dup.isDuplicate) {
      showInfo('Empresa já cadastrada', dup.reason || 'Este registro já consta no CRM.');
      return;
    }

    setSavingPlaceIds((prev) => ({ ...prev, [item.placeId || item.name]: true }));
    try {
      const cityLabel = `${item.city} - ${item.state}`;
      const websiteNote =
        item.websiteStatus === 'site_informado'
          ? `Site informado: ${item.website}`
          : item.websiteStatus === 'sem_site_informado'
            ? 'Site: Sem site informado no Google (requer validação manual)'
            : 'Site: Não verificado';

      const noteLines = [
        `Captado via Bot de Prospecção (${lastQuery?.mode === 'aprofundada' ? 'Pesquisa Aprofundada' : 'Pesquisa Padrão'})`,
        `Pontuação de Potencial: ${item.score.total}/100 (${item.score.classificationLabel})`,
        `Categoria: ${item.category}`,
        `Endereço: ${item.address}`,
        `Localização: ${item.geoStatus === 'confirmed' ? 'Confirmada' : 'Não confirmada automaticamente'}`,
        websiteNote,
        `Oportunidades: ${item.score.opportunities.join(' | ')}`,
        `Justificativa: ${item.score.justification}`,
        item.googleMapsUri ? `Google Maps: ${item.googleMapsUri}` : '',
        item.placeId ? `[PlaceID: ${item.placeId}]` : '',
      ].filter(Boolean);

      const effectiveResponsibleId =
        saveResponsibleId === '__unassigned__'
          ? null
          : saveResponsibleId || currentUser.id;
      const respProfile = effectiveResponsibleId
        ? profiles.find((u) => u.id === effectiveResponsibleId) || currentUser
        : null;
      const effectiveResponsibleName = respProfile ? respProfile.full_name : 'Sem responsável definido';

      const createdProspect = await db.createProspect({
        company_name: item.name,
        contact_name: 'Contato comercial',
        phone: item.phone || '',
        whatsapp: item.whatsappDigits ? item.phone : '',
        email: '',
        city: cityLabel,
        state: item.state,
        address: item.address,
        segment: item.category || lastQuery?.segment || activeSegmentLabel,
        instagram: '',
        website: item.website || '',
        website_status: item.websiteStatus,
        geo_confirmed: item.geoStatus === 'confirmed',
        place_id: item.placeId || null,
        lead_score: item.score.total,
        lead_classification: item.score.classificationLabel,
        score_justification: item.score.justification,
        commercial_opportunities: item.score.opportunities.join('\n'),
        google_rating: item.rating,
        google_reviews_count: item.userRatingCount,
        search_date: item.searchedAt,
        origin: 'Google / Maps',
        responsible_id: effectiveResponsibleId,
        responsible_name: effectiveResponsibleName,
        notes: noteLines.join('\n'),
        first_contact_date: todayISO(),
        next_contact_date: saveNextActivityDate || '',
        next_activity_title: saveNextActivityTitle.trim() || '',
        status: saveInitialStatus,
      });

      if (saveNextActivityDate && saveNextActivityTitle.trim()) {
        try {
          await db.createProspectActivity({
            prospect_id: createdProspect.id,
            title: saveNextActivityTitle.trim(),
            description: `Agendada ao importar lead do Bot de Prospecção (${item.name}).`,
            due_date: saveNextActivityDate,
            due_time: '',
            responsible_id: effectiveResponsibleId || currentUser.id,
            responsible_name: effectiveResponsibleId ? effectiveResponsibleName : currentUser.full_name,
            priority: 'media',
            status: 'pendente',
          });
        } catch {
          // Non-blocking if activities table hasn't been migrated yet
        }
      }

      if (item.placeId) {
        setRecentlySavedIds((prev) => ({ ...prev, [item.placeId]: true }));
      }
      showSuccess(
        'Prospect salvo no CRM',
        `${item.name} (${item.score.total} pts · ${item.score.classificationLabel}) adicionado em Prospecção.`
      );
      await onRefresh();
    } catch (err) {
      showError(
        'Erro ao salvar prospect',
        err instanceof Error ? err.message : 'Verifique sua conexão com o Supabase.'
      );
    } finally {
      setSavingPlaceIds((prev) => {
        const next = { ...prev };
        delete next[item.placeId || item.name];
        return next;
      });
    }
  };

  const buildManualWhatsAppHref = (item: EnrichedBotPlace) => {
    if (!item.whatsappUrl) return '';
    const rawMsg = whatsappTemplate.trim();
    if (!rawMsg) return item.whatsappUrl;
    const msg = rawMsg.replace(/\{\{empresa\}\}/gi, item.name);
    return `${item.whatsappUrl}?text=${encodeURIComponent(msg)}`;
  };

  // Summary metrics
  const stats = useMemo(() => {
    let highPotential = 0;
    let withoutSite = 0;
    let withPhone = 0;
    let alreadyRegistered = 0;
    for (const item of results) {
      if (item.score.classification === 'alto') highPotential += 1;
      if (item.websiteStatus === 'sem_site_informado') withoutSite += 1;
      if (item.whatsappUrl || item.phone) withPhone += 1;
      if (checkDuplicate(item).isDuplicate) alreadyRegistered += 1;
    }
    return {
      total: results.length,
      highPotential,
      withoutSite,
      withPhone,
      alreadyRegistered,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [results, duplicateIndex, recentlySavedIds]);

  // Combined Filters + Sorting
  const filteredAndSortedResults = useMemo(() => {
    const q = normalizeText(resultFilterText);
    const list = results.filter((item) => {
      if (potentialFilter !== 'todos' && item.score.classification !== potentialFilter) {
        return false;
      }
      if (websiteFilter === 'sem_site' && item.websiteStatus !== 'sem_site_informado') {
        return false;
      }
      if (websiteFilter === 'com_site' && item.websiteStatus !== 'site_informado') {
        return false;
      }

      const hasPhone = (item.phone || '').replace(/\D/g, '').length >= 8;
      if (phoneFilter === 'com_telefone' && !hasPhone) return false;
      if (phoneFilter === 'sem_telefone' && hasPhone) return false;

      if (operationalFilter === 'operacional' && item.businessStatus !== 'OPERATIONAL') {
        return false;
      }

      if (geoFilter === 'confirmada' && item.geoStatus !== 'confirmed') return false;
      if (geoFilter === 'nao_confirmada' && item.geoStatus !== 'unconfirmed') return false;

      const dup = checkDuplicate(item);
      if (crmFilter === 'nao_cadastrados' && dup.isDuplicate) return false;
      if (crmFilter === 'ja_cadastrados' && !dup.isDuplicate) return false;

      if (!q) return true;
      const searchable = normalizeText(
        `${item.name} ${item.category} ${item.address} ${item.city} ${item.phone} ${item.website} ${item.score.opportunities.join(' ')}`
      );
      return searchable.includes(q);
    });

    const sorted = [...list];
    sorted.sort((a, b) => {
      if (sortBy === 'score_desc') return b.score.total - a.score.total || a.name.localeCompare(b.name, 'pt-BR');
      if (sortBy === 'score_asc') return a.score.total - b.score.total || a.name.localeCompare(b.name, 'pt-BR');
      if (sortBy === 'name_asc') return a.name.localeCompare(b.name, 'pt-BR');
      if (sortBy === 'category_asc') return a.category.localeCompare(b.category, 'pt-BR');
      if (sortBy === 'city_asc') return a.city.localeCompare(b.city, 'pt-BR');
      if (sortBy === 'date_desc') return b.searchedAt.localeCompare(a.searchedAt);
      return 0;
    });

    return sorted;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    results,
    resultFilterText,
    potentialFilter,
    websiteFilter,
    phoneFilter,
    crmFilter,
    operationalFilter,
    geoFilter,
    sortBy,
    duplicateIndex,
    recentlySavedIds,
  ]);

  const paginatedResults = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredAndSortedResults.slice(start, start + pageSize);
  }, [filteredAndSortedResults, page]);

  // Reset to page 1 only if filter reduces total pages below current page
  useEffect(() => {
    const maxPages = Math.max(1, Math.ceil(filteredAndSortedResults.length / pageSize));
    if (page > maxPages) {
      setPage(1);
    }
  }, [filteredAndSortedResults.length, page]);

  const clearAllResultFilters = () => {
    setResultFilterText('');
    setPotentialFilter('todos');
    setWebsiteFilter('todos');
    setPhoneFilter('todos');
    setCrmFilter('todos');
    setOperationalFilter('todos');
    setGeoFilter('todos');
    setSortBy('score_desc');
    setPage(1);
  };

  return (
    <div className="space-y-4">
      {/* Configuration Notice if API Key missing */}
      {!checkingStatus && apiConfigured === false && (
        <div className="bg-[#111C30] border border-amber-500/35 rounded-lg p-5">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-2 text-xs text-[#A3B6D4] leading-relaxed">
              <p className="font-semibold text-white text-sm">
                Integração com Google Places API (New) aguardando chave nos Secrets
              </p>
              <p>
                Para buscar empresas reais sem simulação ou dados fictícios, o backend utiliza{' '}
                <code className="font-mono text-amber-300 bg-[#080D18] px-1.5 py-0.5 rounded border border-[#1C2B45]">
                  GOOGLE_MAPS_API_KEY
                </code>{' '}
                de forma segura no servidor.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Search Form Card */}
      <form
        onSubmit={handleSearchSubmit}
        className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4 space-y-4"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#1C2B45]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-[#2563EB]/15 border border-[#2563EB]/30 flex items-center justify-center text-[#3B82F6]">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">
                Inteligência Comercial & Bot de Prospecção
              </h3>
              <p className="text-[11px] text-[#8FA3C4]">
                Municípios oficiais IBGE por estado, validação geográfica e Lead Scoring automático (0–100)
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {apiCallsSession > 0 && (
              <span className="text-[11px] font-mono tabular-nums text-[#8FA3C4] bg-[#080D18] border border-[#1C2B45] px-2.5 py-1 rounded">
                Consultas na sessão: {apiCallsSession}
              </span>
            )}
            {checkingStatus ? (
              <span className="text-[11px] text-[#8FA3C4]">Verificando integração...</span>
            ) : apiConfigured ? (
              <StatusTag
                label="Google Places API ativa"
                colorClass="text-emerald-300 border-emerald-500/30 bg-emerald-500/10"
                icon={<ShieldCheck className="w-3.5 h-3.5" />}
              />
            ) : (
              <StatusTag
                label="Chave não configurada"
                colorClass="text-amber-300 border-amber-500/30 bg-amber-500/10"
                icon={<AlertCircle className="w-3.5 h-3.5" />}
              />
            )}
          </div>
        </div>

        {/* Row 1: Estado -> Cidade IBGE -> Segmento -> Modo -> Botão */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-3 items-end">
          {/* 1. Estado (UF) */}
          <div className="lg:col-span-2">
            <label className="block text-[11px] font-medium text-[#8FA3C4] mb-1">
              1. Estado (UF) *
            </label>
            <select
              value={stateUf}
              onChange={(e) => handleStateChange(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              required
            >
              <option value="">Selecione o estado...</option>
              {BRAZIL_STATES_LIST.map((st) => (
                <option key={st.uf} value={st.uf}>
                  {st.name} ({st.uf})
                </option>
              ))}
            </select>
          </div>

          {/* 2. Cidade filtrada exclusivamente pela UF via IBGE */}
          <div className="lg:col-span-3 relative" ref={cityDropdownRef}>
            <label className="block text-[11px] font-medium text-[#8FA3C4] mb-1">
              2. Cidade ({stateUf ? `municípios de ${stateUf}` : 'selecione UF'}) *
            </label>
            <div className="relative">
              <input
                type="text"
                disabled={!stateUf || loadingCities}
                value={citySearchText}
                onFocus={() => {
                  if (stateUf && !loadingCities) setCityDropdownOpen(true);
                }}
                onChange={(e) => {
                  setCitySearchText(e.target.value);
                  setSelectedCity(null);
                  setCityDropdownOpen(true);
                }}
                placeholder={
                  !stateUf
                    ? 'Selecione primeiro o estado'
                    : loadingCities
                      ? `Carregando municípios de ${stateUf}...`
                      : `Pesquisar cidade em ${stateUf}...`
                }
                className="w-full pl-3 pr-8 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6] disabled:opacity-55 disabled:cursor-not-allowed"
              />
              <button
                type="button"
                disabled={!stateUf || loadingCities}
                onClick={() => setCityDropdownOpen((prev) => !prev)}
                aria-label="Abrir lista de municípios"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-[#7D92B5] hover:text-white disabled:opacity-40"
              >
                {loadingCities ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <ChevronDown className="w-3.5 h-3.5" />
                )}
              </button>
            </div>

            {cityDropdownOpen && stateUf && !loadingCities && (
              <div className="absolute z-40 mt-1 w-full bg-[#0D1424] border border-[#2A3F66] rounded-md shadow-xl overflow-hidden">
                <div className="px-3 py-1.5 bg-[#080D18] border-b border-[#1C2B45] text-[10px] text-[#8FA3C4] flex items-center justify-between">
                  <span>Municípios exclusivos de {stateUf}</span>
                  <span className="font-mono tabular-nums">{filteredMunicipalities.length}</span>
                </div>
                <div className="max-h-56 overflow-y-auto divide-y divide-[#1C2B45]/50">
                  {filteredMunicipalities.length === 0 ? (
                    <div className="px-3 py-3 text-xs text-[#8FA3C4]">
                      Nenhum município de {stateUf} encontrado para "{citySearchText}".
                    </div>
                  ) : (
                    filteredMunicipalities.slice(0, 120).map((m) => (
                      <button
                        key={m.id || m.name}
                        type="button"
                        onClick={() => {
                          setSelectedCity(m);
                          setCitySearchText(m.name);
                          setCityDropdownOpen(false);
                          setSearchError(null);
                        }}
                        className={`w-full text-left px-3 py-2 text-xs transition-colors flex items-center justify-between ${
                          selectedCity?.name === m.name
                            ? 'bg-[#2563EB]/25 text-white font-medium'
                            : 'text-slate-200 hover:bg-[#15223B]'
                        }`}
                      >
                        <span>{m.name}</span>
                        <span className="text-[10px] font-mono text-[#7D92B5]">{stateUf}</span>
                      </button>
                    ))
                  )}
                </div>
              </div>
            )}

            {citiesError && (
              <div className="mt-1 flex items-center gap-2 text-[11px] text-rose-300">
                <span>{citiesError}</span>
                <button
                  type="button"
                  onClick={() => void loadCitiesForState(stateUf)}
                  className="underline hover:text-white"
                >
                  Tentar novamente
                </button>
              </div>
            )}
          </div>

          {/* 3. Segmento Empresarial */}
          <div className={selectedSegmentId === '__custom__' ? 'lg:col-span-2' : 'lg:col-span-3'}>
            <label className="block text-[11px] font-medium text-[#8FA3C4] mb-1">
              3. Segmento empresarial *
            </label>
            <select
              value={selectedSegmentId}
              onChange={(e) => setSelectedSegmentId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
            >
              {SEGMENT_DEFINITIONS.map((seg) => (
                <option key={seg.id} value={seg.id}>
                  {seg.label}
                </option>
              ))}
              <option value="__custom__">Outro segmento (digitar manualmente)</option>
            </select>
          </div>

          {selectedSegmentId === '__custom__' && (
            <div className="lg:col-span-2">
              <label className="block text-[11px] font-medium text-[#8FA3C4] mb-1">
                Segmento personalizado *
              </label>
              <input
                type="text"
                value={customSegment}
                onChange={(e) => setCustomSegment(e.target.value)}
                placeholder="Ex: Marcenaria, Vidraçaria"
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                required
              />
            </div>
          )}

          {/* 4. Modo de Pesquisa */}
          <div className={selectedSegmentId === '__custom__' ? 'lg:col-span-1' : 'lg:col-span-2'}>
            <label className="block text-[11px] font-medium text-[#8FA3C4] mb-1">
              4. Modo de pesquisa
            </label>
            <select
              value={searchMode}
              onChange={(e) => setSearchMode(e.target.value as SearchMode)}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
            >
              <option value="padrao">Padrão (direta)</option>
              <option value="aprofundada">Aprofundada (variações)</option>
            </select>
          </div>

          {/* 5. Botão Buscar */}
          <div className="lg:col-span-2">
            <button
              type="submit"
              disabled={searching || loadingMore || !stateUf || !citySearchText.trim()}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] disabled:opacity-55 disabled:cursor-not-allowed rounded-md transition-colors whitespace-nowrap"
            >
              {searching ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Pesquisando...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  Buscar empresas
                </>
              )}
            </button>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-2 border-t border-[#1C2B45]">
          <label className="inline-flex items-center gap-2 text-xs text-slate-200 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={onlyWithoutWebsiteOnSearch}
              onChange={(e) => {
                const checked = e.target.checked;
                setOnlyWithoutWebsiteOnSearch(checked);
                if (results.length > 0) {
                  setWebsiteFilter(checked ? 'sem_site' : 'todos');
                  setPage(1);
                }
              }}
              className="w-3.5 h-3.5 rounded border-[#2E4670] bg-[#080D18] text-[#2563EB] focus:ring-[#3B82F6]"
            />
            <span>Filtrar empresas sem site informado no Google</span>
          </label>

          <p className="text-[11px] text-[#7D92B5]">
            {searchMode === 'aprofundada'
              ? 'Modo aprofundado gera variações relacionadas ao segmento (até 60 empresas únicas por sessão).'
              : 'Modo padrão executa consulta direta no município selecionado (até 20 por página, máx. 60).'}
          </p>
        </div>
      </form>

      {/* Progress Indicator */}
      {progressMessage && (
        <div className="bg-[#111C30] border border-[#2563EB]/40 rounded-lg p-3.5 flex items-center gap-3">
          <Loader2 className="w-4 h-4 text-[#3B82F6] animate-spin shrink-0" />
          <p className="text-xs text-slate-200">{progressMessage}</p>
        </div>
      )}

      {/* Search Error */}
      {searchError && (
        <div className="bg-rose-500/10 border border-rose-500/30 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <p className="text-xs text-rose-200">{searchError}</p>
        </div>
      )}

      {/* Results Area */}
      {results.length > 0 && (
        <div className="space-y-4">
          {/* Summary KPI Strip */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg px-4 py-3">
              <p className="text-[11px] text-[#8FA3C4]">Empresas validadas</p>
              <p className="text-lg font-semibold text-white tabular-nums mt-0.5">{stats.total}</p>
            </div>
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg px-4 py-3">
              <p className="text-[11px] text-[#8FA3C4]">Alto potencial (80–100)</p>
              <p className="text-lg font-semibold text-emerald-300 tabular-nums mt-0.5">
                {stats.highPotential}
              </p>
            </div>
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg px-4 py-3">
              <p className="text-[11px] text-[#8FA3C4]">Sem site informado</p>
              <p className="text-lg font-semibold text-amber-300 tabular-nums mt-0.5">
                {stats.withoutSite}
              </p>
            </div>
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg px-4 py-3">
              <p className="text-[11px] text-[#8FA3C4]">Com telefone público</p>
              <p className="text-lg font-semibold text-sky-300 tabular-nums mt-0.5">
                {stats.withPhone}
              </p>
            </div>
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg px-4 py-3">
              <p className="text-[11px] text-[#8FA3C4]">Já cadastradas no CRM</p>
              <p className="text-lg font-semibold text-slate-200 tabular-nums mt-0.5">
                {stats.alreadyRegistered}
              </p>
            </div>
          </div>

          {/* Query Metadata Banner */}
          {lastQuery && (
            <div className="bg-[#0D1424] border border-[#1C2B45] rounded-lg px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#8FA3C4]">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-white font-medium">
                  {lastQuery.city} - {lastQuery.state}
                </span>
                <span>·</span>
                <span>Segmento: {lastQuery.segment}</span>
                <span>·</span>
                <span>
                  Variações executadas: {lastQuery.queriesExecuted.length}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-3 tabular-nums">
                {lastQuery.filteredOutGeoCount > 0 && (
                  <span>
                    {lastQuery.filteredOutGeoCount} fora do município filtrados
                  </span>
                )}
                {lastQuery.filteredOutClosedCount > 0 && (
                  <span>
                    {lastQuery.filteredOutClosedCount} fechados perm. ocultados
                  </span>
                )}
                {lastQuery.unconfirmedGeoCount > 0 && (
                  <span className="text-amber-300">
                    {lastQuery.unconfirmedGeoCount} com localização não confirmada
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Filters, Sorting & WhatsApp Template */}
          <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              <div className="relative">
                <Filter className="w-3.5 h-3.5 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={resultFilterText}
                  onChange={(e) => {
                    setResultFilterText(e.target.value);
                    setPage(1);
                  }}
                  placeholder="Buscar nome, categoria, endereço..."
                  className="w-full pl-8 pr-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                />
              </div>

              <select
                value={potentialFilter}
                onChange={(e) => {
                  setPotentialFilter(e.target.value as typeof potentialFilter);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="todos">Potencial: Todos os leads</option>
                <option value="alto">Alto potencial (80–100 pts)</option>
                <option value="medio">Médio potencial (60–79 pts)</option>
                <option value="baixo">Baixo potencial (0–59 pts)</option>
              </select>

              <select
                value={websiteFilter}
                onChange={(e) => {
                  setWebsiteFilter(e.target.value as typeof websiteFilter);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="todos">Site: Todos</option>
                <option value="sem_site">Sem site informado</option>
                <option value="com_site">Com site informado</option>
              </select>

              <select
                value={phoneFilter}
                onChange={(e) => {
                  setPhoneFilter(e.target.value as typeof phoneFilter);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="todos">Telefone: Todos</option>
                <option value="com_telefone">Com telefone público</option>
                <option value="sem_telefone">Sem telefone público</option>
              </select>

              <select
                value={crmFilter}
                onChange={(e) => {
                  setCrmFilter(e.target.value as typeof crmFilter);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="todos">CRM: Todos</option>
                <option value="nao_cadastrados">Ainda não cadastrado</option>
                <option value="ja_cadastrados">Já cadastrado</option>
              </select>

              <select
                value={operationalFilter}
                onChange={(e) => {
                  setOperationalFilter(e.target.value as typeof operationalFilter);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="todos">Operação: Todas</option>
                <option value="operacional">Somente empresa operacional</option>
              </select>

              <select
                value={geoFilter}
                onChange={(e) => {
                  setGeoFilter(e.target.value as typeof geoFilter);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="todos">Localização: Todas</option>
                <option value="confirmada">Localização confirmada</option>
                <option value="nao_confirmada">Localização não confirmada</option>
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="score_desc">Ordenar: Maior pontuação</option>
                <option value="score_asc">Ordenar: Menor pontuação</option>
                <option value="name_asc">Ordenar: Nome da empresa (A–Z)</option>
                <option value="category_asc">Ordenar: Categoria</option>
                <option value="city_asc">Ordenar: Cidade</option>
                <option value="date_desc">Ordenar: Data da pesquisa</option>
              </select>
            </div>

            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5 pt-2 border-t border-[#1C2B45]">
              <div className="flex-1">
                <input
                  type="text"
                  value={whatsappTemplate}
                  onChange={(e) => setWhatsappTemplate(e.target.value)}
                  placeholder="Mensagem inicial opcional para abertura manual no WhatsApp (use {{empresa}})..."
                  className="w-full px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                />
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={clearAllResultFilters}
                  className="px-3 py-1.5 text-xs text-[#8FA3C4] hover:text-white bg-[#080D18] border border-[#1C2B45] rounded-md transition-colors"
                >
                  Limpar filtros
                </button>

                {hasMore && (
                  <button
                    type="button"
                    disabled={loadingMore || results.length >= 60}
                    onClick={() => void executeSearch({ isLoadMore: true })}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#1D3566] hover:bg-[#254587] border border-[#2E4F94] rounded-md transition-colors disabled:opacity-55"
                  >
                    {loadingMore ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <RefreshCw className="w-3.5 h-3.5" />
                    )}
                    Carregar mais resultados
                  </button>
                )}
              </div>
            </div>

            {/* Save-to-CRM Configuration Strip */}
            <div className="pt-2.5 border-t border-[#1C2B45] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 items-end">
              <div>
                <label className="block text-[10px] font-medium text-[#8FA3C4] mb-1">
                  Responsável ao salvar no CRM
                </label>
                <select
                  value={saveResponsibleId}
                  onChange={(e) => setSaveResponsibleId(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
                >
                  <option value={currentUser.id}>{currentUser.full_name} (você)</option>
                  {canDistributeLeads && (
                    <option value="__unassigned__">Sem responsável definido (distribuir depois)</option>
                  )}
                  {canDistributeLeads &&
                    profiles
                      .filter((u) => u.status === 'ativo' && u.id !== currentUser.id)
                      .map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.full_name}
                        </option>
                      ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-medium text-[#8FA3C4] mb-1">
                  Estágio inicial no funil
                </label>
                <select
                  value={saveInitialStatus}
                  onChange={(e) => setSaveInitialStatus(e.target.value as ProspectStatus)}
                  className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
                >
                  {PROSPECT_STATUS_OPTIONS.filter((s) => s.value !== 'convertido' && s.value !== 'perdido').map((s) => (
                    <option key={s.value} value={s.value}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-medium text-[#8FA3C4] mb-1">
                  Próxima atividade (opcional)
                </label>
                <input
                  type="text"
                  value={saveNextActivityTitle}
                  onChange={(e) => setSaveNextActivityTitle(e.target.value)}
                  placeholder="Ex: Enviar mensagem inicial"
                  className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                />
              </div>

              <div>
                <label className="block text-[10px] font-medium text-[#8FA3C4] mb-1">
                  Data da atividade (opcional)
                </label>
                <input
                  type="date"
                  value={saveNextActivityDate}
                  onChange={(e) => setSaveNextActivityDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white focus:outline-none focus:border-[#3B82F6]"
                />
              </div>
            </div>
          </div>

          {/* Results List */}
          {filteredAndSortedResults.length === 0 ? (
            <EmptyState
              icon={<Search className="w-5 h-5" />}
              title="Nenhum lead corresponde aos filtros aplicados"
              description="Ajuste ou limpe os filtros de pontuação, site, telefone ou localização para visualizar os resultados carregados."
            />
          ) : (
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
              <div className="divide-y divide-[#1C2B45]">
                {paginatedResults.map((item) => {
                  const dup = checkDuplicate(item);
                  const isSaving = Boolean(savingPlaceIds[item.placeId || item.name]);
                  const waHref = buildManualWhatsAppHref(item);

                  return (
                    <div
                      key={item.placeId || `${item.name}-${item.address}`}
                      className="p-4 hover:bg-[#15223B]/55 transition-colors space-y-3"
                    >
                      {/* Top Header Row: Name + Score + CRM Status */}
                      <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                        <div className="space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <h4 className="text-sm font-semibold text-white">{item.name}</h4>
                            <StatusTag
                              label={`${item.score.total}/100 · ${item.score.classificationLabel}`}
                              colorClass={`${scoreColorClasses(item.score.classification)} tabular-nums`}
                              icon={<Sparkles className="w-3 h-3" />}
                            />
                            {dup.isDuplicate && (
                              <StatusTag
                                label={
                                  dup.target === 'company' ? 'Já é cliente' : 'Já cadastrado'
                                }
                                colorClass="text-emerald-300 border-emerald-500/30 bg-emerald-500/10"
                                icon={<CheckCircle2 className="w-3 h-3" />}
                              />
                            )}
                            {item.geoStatus === 'unconfirmed' && (
                              <StatusTag
                                label="Localização não confirmada"
                                colorClass="text-amber-300 border-amber-500/30 bg-amber-500/10"
                                icon={<AlertTriangle className="w-3 h-3" />}
                              />
                            )}
                          </div>

                          <p className="text-xs text-[#8FA3C4]">
                            <span className="text-slate-200">{item.category}</span> · {item.city} - {item.state}
                            {item.businessStatus === 'CLOSED_TEMPORARILY' && (
                              <span className="text-amber-300 ml-2">(Fechado temporariamente)</span>
                            )}
                            {item.rating !== null && (
                              <span className="inline-flex items-center gap-1 ml-2 text-[#7D92B5] tabular-nums">
                                <Star className="w-3 h-3 text-amber-400/80" />
                                {item.rating.toFixed(1)}
                                {item.userRatingCount !== null ? ` (${item.userRatingCount})` : ''}
                              </span>
                            )}
                          </p>
                        </div>

                        {/* Actions */}
                        <div className="flex flex-wrap items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => setDetailPlace(item)}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] font-medium text-slate-200 bg-[#080D18] hover:bg-[#192846] border border-[#1C2B45] rounded transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5 text-[#3B82F6]" />
                            Ficha completa
                          </button>

                          {item.googleMapsUri && (
                            <a
                              href={item.googleMapsUri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] font-medium text-slate-200 bg-[#080D18] hover:bg-[#192846] border border-[#1C2B45] rounded transition-colors"
                            >
                              <MapPin className="w-3.5 h-3.5 text-sky-400" />
                              Google Maps
                            </a>
                          )}

                          {waHref ? (
                            <a
                              href={waHref}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] font-medium text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded transition-colors"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              Abrir WhatsApp
                            </a>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] text-[#566C8E] bg-[#080D18] border border-[#1C2B45] rounded cursor-not-allowed">
                              <MessageCircle className="w-3.5 h-3.5" />
                              Sem número
                            </span>
                          )}

                          <button
                            type="button"
                            disabled={dup.isDuplicate || isSaving}
                            onClick={() => void handleSaveAsProspect(item)}
                            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-medium rounded transition-colors ${
                              dup.isDuplicate
                                ? 'bg-[#080D18] text-[#647B9E] border border-[#1C2B45] cursor-not-allowed'
                                : 'bg-[#2563EB] hover:bg-[#3B82F6] text-white disabled:opacity-60'
                            }`}
                          >
                            {isSaving ? (
                              <>
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                Salvando...
                              </>
                            ) : dup.isDuplicate ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Já cadastrado
                              </>
                            ) : (
                              <>
                                <Plus className="w-3.5 h-3.5" />
                                Salvar no CRM
                              </>
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Middle Grid: Contact, Website, Address */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
                        <div className="bg-[#080D18]/70 border border-[#1C2B45] rounded p-2.5">
                          <p className="text-[10px] text-[#7D92B5] mb-1">Telefone comercial</p>
                          {item.phone ? (
                            <p className="font-mono tabular-nums text-slate-200 flex items-center gap-1.5">
                              <Phone className="w-3.5 h-3.5 text-[#3B82F6]" />
                              {item.phone}
                            </p>
                          ) : (
                            <p className="text-[#647B9E]">Não informado no Google</p>
                          )}
                        </div>

                        <div className="bg-[#080D18]/70 border border-[#1C2B45] rounded p-2.5">
                          <p className="text-[10px] text-[#7D92B5] mb-1">Presença digital (Site)</p>
                          {item.websiteStatus === 'site_informado' ? (
                            <a
                              href={item.website}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 text-sky-300 hover:text-sky-200 max-w-full"
                            >
                              <Globe className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{normalizeHostKey(item.website) || item.website}</span>
                              <ExternalLink className="w-3 h-3 shrink-0" />
                            </a>
                          ) : item.websiteStatus === 'sem_site_informado' ? (
                            <span className="text-amber-300 font-medium">
                              Sem site informado no Google
                            </span>
                          ) : (
                            <span className="text-[#8FA3C4]">Site não verificado</span>
                          )}
                        </div>

                        <div className="bg-[#080D18]/70 border border-[#1C2B45] rounded p-2.5">
                          <p className="text-[10px] text-[#7D92B5] mb-1">Endereço</p>
                          <p className="text-slate-300 truncate" title={item.address}>
                            {item.address}
                          </p>
                        </div>
                      </div>

                      {/* Opportunities & Score Justification preview */}
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 text-[11px] bg-[#0D1424]/70 border border-[#1C2B45] rounded px-3 py-2">
                        <p className="text-slate-200">
                          <span className="text-[#3B82F6] font-medium">Oportunidade sugerida:</span>{' '}
                          {item.score.opportunities[0]}
                        </p>
                        <button
                          type="button"
                          onClick={() => setDetailPlace(item)}
                          className="text-[#3B82F6] hover:text-sky-300 font-medium whitespace-nowrap shrink-0 text-left"
                        >
                          Ver justificativa da pontuação ({item.score.total} pts)
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              <Pagination
                currentPage={page}
                totalItems={filteredAndSortedResults.length}
                pageSize={pageSize}
                onPageChange={setPage}
              />
            </div>
          )}
        </div>
      )}

      {!searching && results.length === 0 && !searchError && lastQuery && (
        <EmptyState
          icon={<Search className="w-5 h-5" />}
          title="Nenhuma empresa validada nesse município"
          description={`A consulta em ${lastQuery.city} - ${lastQuery.state} não retornou empresas ativas confirmadas para este segmento. Tente o modo de Pesquisa Aprofundada ou um termo mais amplo.`}
        />
      )}

      {!searching && results.length === 0 && !searchError && !lastQuery && (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-8 text-center">
          <Bot className="w-8 h-8 text-[#3B82F6] mx-auto mb-3" />
          <h4 className="text-sm font-semibold text-white">
            Prospecção Inteligente por Estado e Município
          </h4>
          <p className="text-xs text-[#8FA3C4] mt-1 max-w-2xl mx-auto leading-relaxed">
            Selecione primeiro o estado (UF), escolha um município oficial do IBGE pertencente a esse estado, defina o segmento e o modo de pesquisa. Cada empresa é validada geograficamente e classificada automaticamente de 0 a 100 pontos.
          </p>
        </div>
      )}

      {/* Business Enrichment Dossier Modal ("Ficha Completa") */}
      <Modal
        open={Boolean(detailPlace)}
        onClose={() => setDetailPlace(null)}
        title={detailPlace?.name || ''}
        subtitle={
          detailPlace
            ? `${detailPlace.category} · ${detailPlace.city} - ${detailPlace.state}`
            : ''
        }
        maxWidthClass="max-w-3xl"
      >
        {detailPlace && (
          <div className="space-y-5 text-xs">
            {/* 1. Identificação & 7. Pontuação */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-[#080D18] border border-[#1C2B45] rounded-md p-3.5 space-y-1.5">
                <p className="text-[11px] font-semibold text-[#8FA3C4]">1. Identificação da empresa</p>
                <p className="text-sm font-semibold text-white">{detailPlace.name}</p>
                <p className="text-slate-300">Categoria: {detailPlace.category}</p>
                <p className="text-[#7D92B5] font-mono text-[11px]">
                  Place ID: {detailPlace.placeId || 'Não informado'}
                </p>
              </div>

              <div className="bg-[#080D18] border border-[#1C2B45] rounded-md p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-semibold text-[#8FA3C4]">7. Pontuação de potencial</p>
                  <StatusTag
                    label={detailPlace.score.classificationLabel}
                    colorClass={scoreColorClasses(detailPlace.score.classification)}
                  />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-white tabular-nums">
                    {detailPlace.score.total}
                  </span>
                  <span className="text-[#7D92B5]">/ 100 pontos</span>
                </div>
                <div className="w-full h-2 bg-[#111C30] rounded overflow-hidden">
                  <div
                    className="h-full bg-[#2563EB]"
                    style={{ width: `${detailPlace.score.total}%` }}
                  />
                </div>
              </div>
            </div>

            {/* 2. Localização & 3. Contato & 4. Presença digital */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="bg-[#080D18] border border-[#1C2B45] rounded-md p-3.5 space-y-1.5">
                <p className="text-[11px] font-semibold text-[#8FA3C4]">2. Localização</p>
                <p className="text-slate-200">
                  {detailPlace.city} - {detailPlace.state}
                </p>
                <p className="text-[#7D92B5] leading-relaxed">{detailPlace.address}</p>
                <p className="text-[11px]">
                  Status:{' '}
                  <span
                    className={
                      detailPlace.geoStatus === 'confirmed' ? 'text-emerald-300' : 'text-amber-300'
                    }
                  >
                    {detailPlace.geoStatus === 'confirmed'
                      ? 'Município e UF confirmados'
                      : 'Localização não confirmada'}
                  </span>
                </p>
              </div>

              <div className="bg-[#080D18] border border-[#1C2B45] rounded-md p-3.5 space-y-1.5">
                <p className="text-[11px] font-semibold text-[#8FA3C4]">3. Informações de contato</p>
                <p className="text-slate-200 font-mono tabular-nums">
                  {detailPlace.phone || 'Telefone não informado'}
                </p>
                {detailPlace.whatsappUrl && (
                  <a
                    href={buildManualWhatsAppHref(detailPlace)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-emerald-300 hover:text-emerald-200"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    Abrir WhatsApp manualmente
                  </a>
                )}
              </div>

              <div className="bg-[#080D18] border border-[#1C2B45] rounded-md p-3.5 space-y-1.5">
                <p className="text-[11px] font-semibold text-[#8FA3C4]">4. Presença digital</p>
                {detailPlace.websiteStatus === 'site_informado' ? (
                  <a
                    href={detailPlace.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-sky-300 hover:text-sky-200 break-all"
                  >
                    <Globe className="w-3.5 h-3.5 shrink-0" />
                    {detailPlace.website}
                  </a>
                ) : detailPlace.websiteStatus === 'sem_site_informado' ? (
                  <p className="text-amber-300 font-medium">Sem site informado no Google</p>
                ) : (
                  <p className="text-slate-300">Site não verificado</p>
                )}
                <p className="text-[11px] text-[#7D92B5]">
                  {detailPlace.websiteStatus === 'sem_site_informado'
                    ? 'A empresa pode não possuir site ou apenas não tê-lo cadastrado no perfil público.'
                    : 'Endereço web público informado no perfil.'}
                </p>
              </div>
            </div>

            {/* 5. Dados públicos do Google */}
            <div className="bg-[#080D18] border border-[#1C2B45] rounded-md p-3.5 space-y-1.5">
              <p className="text-[11px] font-semibold text-[#8FA3C4]">5. Dados públicos do Google</p>
              <div className="flex flex-wrap items-center gap-4 text-slate-200">
                <span>
                  Situação operacional:{' '}
                  <strong>
                    {detailPlace.businessStatus === 'OPERATIONAL'
                      ? 'Operacional'
                      : detailPlace.businessStatus}
                  </strong>
                </span>
                <span>
                  Avaliação pública (informativa):{' '}
                  <strong className="tabular-nums">
                    {detailPlace.rating !== null
                      ? `${detailPlace.rating.toFixed(1)} (${detailPlace.userRatingCount ?? 0} avaliações)`
                      : 'Não informada'}
                  </strong>
                </span>
                <span>Consulta: {formatDateTime(detailPlace.searchedAt)}</span>
              </div>
            </div>

            {/* 6. Oportunidades comerciais identificadas */}
            <div className="bg-[#080D18] border border-[#1C2B45] rounded-md p-3.5 space-y-2">
              <p className="text-[11px] font-semibold text-[#8FA3C4]">
                6. Oportunidades comerciais identificadas (hipóteses para investigação)
              </p>
              <ul className="space-y-1.5 text-slate-200 list-disc list-inside">
                {detailPlace.score.opportunities.map((op, idx) => (
                  <li key={idx}>{op}</li>
                ))}
              </ul>
            </div>

            {/* 8. Justificativa da pontuação */}
            <div className="bg-[#080D18] border border-[#1C2B45] rounded-md p-3.5 space-y-2">
              <p className="text-[11px] font-semibold text-[#8FA3C4]">
                8. Justificativa detalhada da pontuação
              </p>
              <div className="divide-y divide-[#1C2B45]">
                {detailPlace.score.breakdown.map((b) => (
                  <div key={b.key} className="py-2 flex items-start justify-between gap-4">
                    <div>
                      <p className="font-medium text-white">{b.label}</p>
                      <p className="text-[#8FA3C4] mt-0.5">{b.reason}</p>
                    </div>
                    <span className="font-mono tabular-nums text-slate-200 shrink-0">
                      +{b.points}/{b.maxPoints}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#1C2B45]">
              {!checkDuplicate(detailPlace).isDuplicate && (
                <button
                  type="button"
                  disabled={Boolean(savingPlaceIds[detailPlace.placeId || detailPlace.name])}
                  onClick={() => void handleSaveAsProspect(detailPlace)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Salvar no CRM
                </button>
              )}
              <button
                type="button"
                onClick={() => setDetailPlace(null)}
                className="px-4 py-2 text-xs font-medium text-slate-200 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md"
              >
                Fechar ficha
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
