import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  Clock,
  Database,
  Search,
  Trash2,
} from 'lucide-react';
import { ACTIVITY_PRIORITY_OPTIONS } from '../../lib/constants';
import { formatDate, formatDateTime, todayISO } from '../../lib/formatters';
import * as db from '../../services/database';
import type { Prospect, ProspectActivity, UserProfile } from '../../types';
import { useToast } from '../../contexts/ToastContext';
import { EmptyState } from '../ui/EmptyState';
import { Modal } from '../ui/Modal';
import { StatusTag } from '../ui/StatusTag';

interface CommercialActivitiesViewProps {
  activities: ProspectActivity[];
  prospects: Prospect[];
  profiles: UserProfile[];
  tableMissing: boolean;
  onOpenLead: (prospect: Prospect) => void;
  onOpenSettingsSchema: () => void;
  onRefresh: () => Promise<void>;
}

export function CommercialActivitiesView({
  activities,
  prospects,
  profiles,
  tableMissing,
  onOpenLead,
  onOpenSettingsSchema,
  onRefresh,
}: CommercialActivitiesViewProps) {
  const { showSuccess, showError } = useToast();
  const today = todayISO();

  const [search, setSearch] = useState('');
  const [responsibleFilter, setResponsibleFilter] = useState('todos');
  const [bucketFilter, setBucketFilter] = useState<'todas' | 'atrasadas' | 'hoje' | 'proximas' | 'concluidas'>('todas');

  const [completingActivity, setCompletingActivity] = useState<ProspectActivity | null>(null);
  const [completionOutcome, setCompletionOutcome] = useState('');
  const [savingComplete, setSavingComplete] = useState(false);

  const prospectMap = useMemo(() => {
    const map = new Map<string, Prospect>();
    prospects.forEach((p) => map.set(p.id, p));
    return map;
  }, [prospects]);

  const categorized = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = activities.filter((a) => {
      if (responsibleFilter !== 'todos' && a.responsible_id !== responsibleFilter) return false;
      const lead = prospectMap.get(a.prospect_id);
      if (q) {
        const hay = `${a.title} ${a.description} ${a.responsible_name} ${lead?.company_name || ''} ${lead?.contact_name || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const atrasadas: ProspectActivity[] = [];
    const hoje: ProspectActivity[] = [];
    const proximas: ProspectActivity[] = [];
    const concluidas: ProspectActivity[] = [];

    for (const act of filtered) {
      if (act.status === 'concluida' || act.status === 'cancelada') {
        concluidas.push(act);
      } else if (act.due_date < today) {
        atrasadas.push(act);
      } else if (act.due_date === today) {
        hoje.push(act);
      } else {
        proximas.push(act);
      }
    }

    return { atrasadas, hoje, proximas, concluidas };
  }, [activities, responsibleFilter, search, prospectMap, today]);

  const handleConfirmComplete = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!completingActivity) return;
    setSavingComplete(true);
    try {
      await db.completeProspectActivity(completingActivity, completionOutcome);
      showSuccess('Atividade concluída', 'Resultado registrado no histórico do lead.');
      setCompletingActivity(null);
      setCompletionOutcome('');
      await onRefresh();
    } catch (err) {
      showError('Erro ao concluir atividade', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSavingComplete(false);
    }
  };

  const handleDeleteActivity = async (act: ProspectActivity) => {
    try {
      await db.deleteProspectActivity(act.id);
      showSuccess('Atividade excluída', `"${act.title}" removida.`);
      await onRefresh();
    } catch (err) {
      showError('Erro ao excluir atividade', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  if (tableMissing) {
    return (
      <div className="bg-[#111C30] border border-amber-500/30 rounded-lg p-6">
        <div className="flex items-start gap-3">
          <Database className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <h3 className="font-display text-base font-semibold text-white">
              Tabela <code className="font-mono">prospect_activities</code> aguardando migração SQL
            </h3>
            <p className="text-xs text-[#8FA3C4] mt-1 leading-relaxed max-w-2xl">
              Execute a migração incremental <code className="font-mono text-slate-200">supabase/migrations/004_commercial_team_evolution.sql</code> no SQL Editor do Supabase para habilitar a agenda completa de retornos, lembretes e atividades comerciais.
            </p>
            <button
              type="button"
              onClick={onOpenSettingsSchema}
              className="mt-4 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md"
            >
              Verificar Estrutura Supabase
            </button>
          </div>
        </div>
      </div>
    );
  }

  const sections: {
    key: 'atrasadas' | 'hoje' | 'proximas' | 'concluidas';
    title: string;
    subtitle: string;
    items: ProspectActivity[];
    highlight?: 'danger' | 'today' | 'normal' | 'done';
  }[] = [
    {
      key: 'atrasadas',
      title: 'Atividades atrasadas',
      subtitle: 'Retornos vencidos aguardando execução imediata',
      items: categorized.atrasadas,
      highlight: 'danger',
    },
    {
      key: 'hoje',
      title: 'Atividades de hoje',
      subtitle: 'Agenda comercial programada para hoje',
      items: categorized.hoje,
      highlight: 'today',
    },
    {
      key: 'proximas',
      title: 'Próximas atividades',
      subtitle: 'Retornos e reuniões agendadas para os próximos dias',
      items: categorized.proximas,
      highlight: 'normal',
    },
    {
      key: 'concluidas',
      title: 'Concluídas',
      subtitle: 'Histórico de atividades finalizadas e resultados',
      items: categorized.concluidas,
      highlight: 'done',
    },
  ];

  const visibleSections =
    bucketFilter === 'todas' ? sections : sections.filter((s) => s.key === bucketFilter);

  return (
    <div className="space-y-4">
      {/* KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <button
          type="button"
          onClick={() => setBucketFilter(bucketFilter === 'atrasadas' ? 'todas' : 'atrasadas')}
          className={`text-left rounded-lg p-4 border transition-colors ${
            bucketFilter === 'atrasadas'
              ? 'bg-rose-500/15 border-rose-500/50'
              : categorized.atrasadas.length > 0
                ? 'bg-[#111C30] border-rose-500/35 hover:border-rose-400/50'
                : 'bg-[#111C30] border-[#1C2B45]'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-rose-300">
            <span>Atrasadas</span>
            <AlertTriangle className="w-4 h-4" />
          </div>
          <p className="text-xl font-mono font-bold tabular-nums text-white mt-1">
            {categorized.atrasadas.length}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setBucketFilter(bucketFilter === 'hoje' ? 'todas' : 'hoje')}
          className={`text-left rounded-lg p-4 border transition-colors ${
            bucketFilter === 'hoje'
              ? 'bg-[#2563EB]/20 border-[#3B82F6]'
              : 'bg-[#111C30] border-[#1C2B45] hover:border-[#2C4166]'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-sky-300">
            <span>Para hoje</span>
            <Clock className="w-4 h-4" />
          </div>
          <p className="text-xl font-mono font-bold tabular-nums text-white mt-1">
            {categorized.hoje.length}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setBucketFilter(bucketFilter === 'proximas' ? 'todas' : 'proximas')}
          className={`text-left rounded-lg p-4 border transition-colors ${
            bucketFilter === 'proximas'
              ? 'bg-[#2563EB]/20 border-[#3B82F6]'
              : 'bg-[#111C30] border-[#1C2B45] hover:border-[#2C4166]'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-[#8FA3C4]">
            <span>Próximas</span>
            <CalendarClock className="w-4 h-4 text-[#3B82F6]" />
          </div>
          <p className="text-xl font-mono font-bold tabular-nums text-white mt-1">
            {categorized.proximas.length}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setBucketFilter(bucketFilter === 'concluidas' ? 'todas' : 'concluidas')}
          className={`text-left rounded-lg p-4 border transition-colors ${
            bucketFilter === 'concluidas'
              ? 'bg-emerald-500/15 border-emerald-500/50'
              : 'bg-[#111C30] border-[#1C2B45] hover:border-[#2C4166]'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-emerald-300">
            <span>Concluídas</span>
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <p className="text-xl font-mono font-bold tabular-nums text-white mt-1">
            {categorized.concluidas.length}
          </p>
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5">
        <div className="relative">
          <Search className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar atividade, empresa ou responsável..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E]"
          />
        </div>

        <select
          value={responsibleFilter}
          onChange={(e) => setResponsibleFilter(e.target.value)}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
        >
          <option value="todos">Todos os responsáveis</option>
          {profiles.map((u) => (
            <option key={u.id} value={u.id}>{u.full_name}</option>
          ))}
        </select>

        <select
          value={bucketFilter}
          onChange={(e) => setBucketFilter(e.target.value as typeof bucketFilter)}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
        >
          <option value="todas">Exibir todas as seções</option>
          <option value="atrasadas">Somente atrasadas</option>
          <option value="hoje">Somente hoje</option>
          <option value="proximas">Somente próximas</option>
          <option value="concluidas">Somente concluídas</option>
        </select>
      </div>

      {activities.length === 0 ? (
        <EmptyState
          icon={<CalendarClock className="w-5 h-5" />}
          title="Nenhuma atividade comercial agendada"
          description="Abra qualquer lead no CRM de Prospecção e use a aba 'Atividades & Retornos' para agendar follow-ups, ligações ou reuniões."
        />
      ) : (
        <div className="space-y-4">
          {visibleSections.map((section) => (
            <div
              key={section.key}
              className={`bg-[#111C30] rounded-lg border overflow-hidden ${
                section.highlight === 'danger' && section.items.length > 0
                  ? 'border-rose-500/40'
                  : 'border-[#1C2B45]'
              }`}
            >
              <div className="px-4 py-3 bg-[#0D1424] border-b border-[#1C2B45] flex items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs font-semibold text-white flex items-center gap-2">
                    {section.highlight === 'danger' && section.items.length > 0 && (
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    )}
                    {section.title}
                  </h3>
                  <p className="text-[11px] text-[#7D92B5]">{section.subtitle}</p>
                </div>
                <span className="text-xs font-mono tabular-nums text-[#8FA3C4]">
                  {section.items.length}
                </span>
              </div>

              {section.items.length === 0 ? (
                <p className="px-4 py-5 text-xs text-[#647B9E]">Nenhuma atividade nesta seção.</p>
              ) : (
                <div className="divide-y divide-[#1C2B45]">
                  {section.items.map((act) => {
                    const lead = prospectMap.get(act.prospect_id);
                    const prio = ACTIVITY_PRIORITY_OPTIONS.find((p) => p.value === act.priority);
                    const isOverdue = act.status === 'pendente' && act.due_date < today;
                    return (
                      <div
                        key={act.id}
                        className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs hover:bg-[#15223B]/50 transition-colors"
                      >
                        <div className="space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-semibold text-white">{act.title}</span>
                            {prio && <StatusTag label={prio.label} colorClass={prio.colorClass} />}
                            {isOverdue && (
                              <StatusTag
                                label="Atrasada"
                                colorClass="text-rose-300 border-rose-500/40 bg-rose-500/15"
                              />
                            )}
                          </div>
                          {act.description && <p className="text-[#8FA3C4]">{act.description}</p>}
                          <div className="flex flex-wrap items-center gap-3 text-[11px] text-[#7D92B5]">
                            {lead ? (
                              <button
                                type="button"
                                onClick={() => onOpenLead(lead)}
                                className="text-[#3B82F6] hover:underline font-medium"
                              >
                                Lead: {lead.company_name}
                              </button>
                            ) : (
                              <span>Lead vinculado</span>
                            )}
                            <span>Responsável: {act.responsible_name || '—'}</span>
                            <span className="font-mono tabular-nums">
                              Prazo: {formatDate(act.due_date)}
                              {act.due_time ? ` às ${act.due_time}` : ''}
                            </span>
                            {act.completed_at && (
                              <span className="text-emerald-300 font-mono tabular-nums">
                                Concluída em {formatDateTime(act.completed_at)}
                              </span>
                            )}
                          </div>
                          {act.completion_outcome && (
                            <p className="text-[11px] text-emerald-300">
                              Resultado: {act.completion_outcome}
                            </p>
                          )}
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {lead && (
                            <button
                              type="button"
                              onClick={() => onOpenLead(lead)}
                              className="px-2.5 py-1.5 text-[11px] font-medium text-slate-200 bg-[#080D18] hover:bg-[#1C2D4D] border border-[#1C2B45] rounded"
                            >
                              Abrir lead
                            </button>
                          )}
                          {act.status === 'pendente' && (
                            <button
                              type="button"
                              onClick={() => {
                                setCompletingActivity(act);
                                setCompletionOutcome('');
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Concluir
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => void handleDeleteActivity(act)}
                            title="Excluir atividade"
                            className="p-1.5 rounded text-rose-400 hover:bg-rose-500/10"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Complete Activity Modal */}
      <Modal
        open={Boolean(completingActivity)}
        onClose={() => setCompletingActivity(null)}
        title="Concluir Atividade Comercial"
        subtitle={completingActivity?.title || ''}
        maxWidthClass="max-w-md"
      >
        <form onSubmit={handleConfirmComplete} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Resultado / observação da conclusão *
            </label>
            <textarea
              rows={3}
              required
              value={completionOutcome}
              onChange={(e) => setCompletionOutcome(e.target.value)}
              placeholder="Descreva o que aconteceu e o retorno do cliente..."
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E]"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-[#1C2B45]">
            <button
              type="button"
              onClick={() => setCompletingActivity(null)}
              className="px-3.5 py-2 text-xs text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={savingComplete}
              className="px-4 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded-md disabled:opacity-50"
            >
              {savingComplete ? 'Salvando...' : 'Confirmar conclusão'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
