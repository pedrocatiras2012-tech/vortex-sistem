import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRightLeft,
  Calendar,
  CalendarClock,
  CheckCircle2,
  Eye,
  FileText,
  History,
  MessageCircle,
  Phone,
  Plus,
  Trash2,
  UserPlus,
  Users,
  XCircle,
} from 'lucide-react';
import {
  ACTIVITY_PRIORITY_OPTIONS,
  CONTACT_TYPE_OPTIONS,
  PROPOSAL_STATUS_OPTIONS,
  PROSPECT_STATUS_OPTIONS,
  SALE_PARTICIPATION_ROLE_OPTIONS,
  SERVICE_TYPE_OPTIONS,
} from '../../lib/constants';
import {
  formatCurrency,
  formatDate,
  formatDateTime,
  toDateInputValue,
  toDateTimeInputValue,
  todayISO,
} from '../../lib/formatters';
import * as db from '../../services/database';
import type {
  ActivityPriority,
  CommercialProposal,
  ContactType,
  LeadAssignmentHistory,
  ParticipatingCollaborator,
  ProposalStatus,
  Prospect,
  ProspectActivity,
  ProspectInteraction,
  ProspectStatus,
  SaleParticipationRole,
  ServiceType,
  UserProfile,
} from '../../types';
import { useToast } from '../../contexts/ToastContext';
import { Modal } from '../ui/Modal';
import { StatusTag } from '../ui/StatusTag';

interface ProspectDetailModalProps {
  prospect: Prospect | null;
  onClose: () => void;
  profiles: UserProfile[];
  currentUser: UserProfile;
  canDistributeLeads: boolean;
  interactions: ProspectInteraction[];
  activities: ProspectActivity[];
  proposals: CommercialProposal[];
  assignmentsHistory: LeadAssignmentHistory[];
  onQuickStatusChange: (p: Prospect, status: ProspectStatus) => Promise<void>;
  onOpenEditModal: (p: Prospect) => void;
  onOpenConvertModal: (p: Prospect) => void;
  onUpdateProspectLocal: (p: Prospect) => void;
  onRefresh: () => Promise<void>;
}

type DetailTab = 'visao_geral' | 'historico' | 'atividades' | 'propostas' | 'fechamento';

export function ProspectDetailModal({
  prospect,
  onClose,
  profiles,
  currentUser,
  canDistributeLeads,
  interactions,
  activities,
  proposals,
  assignmentsHistory,
  onQuickStatusChange,
  onOpenEditModal,
  onOpenConvertModal,
  onUpdateProspectLocal,
  onRefresh,
}: ProspectDetailModalProps) {
  const { showSuccess, showError } = useToast();
  const [tab, setTab] = useState<DetailTab>('visao_geral');

  // Estimated value + Assignment states
  const [estimatedValueInput, setEstimatedValueInput] = useState('');
  const [savingValue, setSavingValue] = useState(false);

  const [assignResponsibleId, setAssignResponsibleId] = useState('');
  const [assignmentNotes, setAssignmentNotes] = useState('');
  const [participating, setParticipating] = useState<ParticipatingCollaborator[]>([]);
  const [newParticipantId, setNewParticipantId] = useState('');
  const [newParticipantRole, setNewParticipantRole] = useState<SaleParticipationRole>('atendimento');
  const [savingAssignment, setSavingAssignment] = useState(false);

  // Interactions state
  const [interactionForm, setInteractionForm] = useState({
    contact_at: toDateTimeInputValue(null),
    contact_type: 'whatsapp' as ContactType,
    summary: '',
    responsible_id: currentUser.id,
    outcome: '',
    next_action: '',
    update_next_contact_date: '',
  });
  const [savingInteraction, setSavingInteraction] = useState(false);

  // Activities state
  const [activityForm, setActivityForm] = useState({
    title: '',
    description: '',
    due_date: todayISO(),
    due_time: '',
    responsible_id: currentUser.id,
    priority: 'media' as ActivityPriority,
  });
  const [savingActivity, setSavingActivity] = useState(false);
  const [completingActId, setCompletingActId] = useState<string | null>(null);
  const [completeOutcomeText, setCompleteOutcomeText] = useState('');

  // Proposals state
  const [proposalForm, setProposalForm] = useState({
    title: '',
    service_type: 'presenca_digital' as ServiceType,
    value: '',
    sent_date: todayISO(),
    valid_until: '',
    responsible_id: currentUser.id,
    status: 'enviada' as ProposalStatus,
    notes: '',
  });
  const [savingProposal, setSavingProposal] = useState(false);

  // Loss reason state
  const [lossStatusTarget, setLossStatusTarget] = useState<'perdido' | 'sem_interesse'>('perdido');
  const [lossReasonInput, setLossReasonInput] = useState('');
  const [savingLoss, setSavingLoss] = useState(false);

  useEffect(() => {
    if (!prospect) return;
    setTab('visao_geral');
    setEstimatedValueInput(prospect.estimated_value != null ? String(prospect.estimated_value) : '');
    setAssignResponsibleId(prospect.responsible_id || '');
    setAssignmentNotes('');
    setParticipating(prospect.participating_collaborators || []);
    setLossReasonInput(prospect.loss_reason || '');
    setInteractionForm({
      contact_at: toDateTimeInputValue(null),
      contact_type: 'whatsapp',
      summary: '',
      responsible_id: currentUser.id,
      outcome: '',
      next_action: '',
      update_next_contact_date: toDateInputValue(prospect.next_contact_date),
    });
    setActivityForm({
      title: '',
      description: '',
      due_date: todayISO(),
      due_time: '',
      responsible_id: prospect.responsible_id || currentUser.id,
      priority: 'media',
    });
    setProposalForm({
      title: `Proposta ${prospect.company_name}`,
      service_type: (prospect.contracted_service as ServiceType) || 'presenca_digital',
      value: prospect.estimated_value != null ? String(prospect.estimated_value) : '',
      sent_date: todayISO(),
      valid_until: '',
      responsible_id: prospect.responsible_id || currentUser.id,
      status: 'enviada',
      notes: '',
    });
  }, [prospect?.id, currentUser.id]);

  const leadInteractions = useMemo(
    () => (prospect ? interactions.filter((i) => i.prospect_id === prospect.id) : []),
    [interactions, prospect]
  );

  const leadActivities = useMemo(
    () => (prospect ? activities.filter((a) => a.prospect_id === prospect.id) : []),
    [activities, prospect]
  );

  const leadProposals = useMemo(
    () => (prospect ? proposals.filter((pr) => pr.prospect_id === prospect.id) : []),
    [proposals, prospect]
  );

  const leadAssignments = useMemo(
    () => (prospect ? assignmentsHistory.filter((h) => h.prospect_id === prospect.id) : []),
    [assignmentsHistory, prospect]
  );

  if (!prospect) return null;

  const waDigits = (prospect.whatsapp || prospect.phone || '').replace(/\D/g, '');
  const waHref =
    waDigits.length >= 10
      ? `https://wa.me/${waDigits.startsWith('55') ? waDigits : `55${waDigits}`}`
      : '';

  const handleSaveEstimatedValue = async () => {
    setSavingValue(true);
    try {
      const updated = await db.updateProspect(prospect.id, {
        estimated_value: estimatedValueInput ? Number(estimatedValueInput) : null,
      });
      onUpdateProspectLocal(updated);
      showSuccess('Valor atualizado', 'Valor estimado da oportunidade salvo.');
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar valor', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSavingValue(false);
    }
  };

  const handleAddParticipant = () => {
    if (!newParticipantId) return;
    const user = profiles.find((u) => u.id === newParticipantId);
    if (!user) return;
    if (participating.some((p) => p.id === user.id && p.participation_role === newParticipantRole)) {
      return;
    }
    setParticipating((prev) => [
      ...prev,
      { id: user.id, name: user.full_name, participation_role: newParticipantRole },
    ]);
    setNewParticipantId('');
  };

  const handleSaveDistribution = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetUser = assignResponsibleId ? profiles.find((u) => u.id === assignResponsibleId) : null;
    setSavingAssignment(true);
    try {
      const updated = await db.assignOrTransferProspect({
        prospect,
        newResponsibleId: targetUser ? targetUser.id : null,
        newResponsibleName: targetUser ? targetUser.full_name : 'Sem responsável definido',
        actor: currentUser,
        notes: assignmentNotes,
        participatingCollaborators: participating,
      });
      onUpdateProspectLocal(updated);
      setAssignmentNotes('');
      showSuccess('Distribuição salva', 'Responsável e participantes atualizados no histórico.');
      await onRefresh();
    } catch (err) {
      showError('Erro na distribuição', err instanceof Error ? err.message : 'Verifique permissões.');
    } finally {
      setSavingAssignment(false);
    }
  };

  const handleAddInteraction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!interactionForm.summary.trim()) {
      showError('Resumo obrigatório', 'Descreva o contato realizado.');
      return;
    }
    const resp = profiles.find((u) => u.id === interactionForm.responsible_id);
    setSavingInteraction(true);
    try {
      await db.createProspectInteraction({
        prospect_id: prospect.id,
        company_id: prospect.converted_company_id || null,
        contact_at: new Date(interactionForm.contact_at).toISOString(),
        contact_type: interactionForm.contact_type,
        summary: interactionForm.summary,
        responsible_id: interactionForm.responsible_id || currentUser.id,
        responsible_name: resp?.full_name || currentUser.full_name,
        outcome: interactionForm.outcome,
        next_action: interactionForm.next_action,
      });

      if (interactionForm.update_next_contact_date !== toDateInputValue(prospect.next_contact_date)) {
        const updated = await db.updateProspect(prospect.id, {
          next_contact_date: interactionForm.update_next_contact_date,
        });
        onUpdateProspectLocal(updated);
      }

      setInteractionForm({
        contact_at: toDateTimeInputValue(null),
        contact_type: 'whatsapp',
        summary: '',
        responsible_id: currentUser.id,
        outcome: '',
        next_action: '',
        update_next_contact_date: interactionForm.update_next_contact_date,
      });
      showSuccess('Contato registrado', 'Histórico individual atualizado.');
      await onRefresh();
    } catch (err) {
      showError('Erro ao registrar contato', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSavingInteraction(false);
    }
  };

  const handleCreateActivity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activityForm.title.trim() || !activityForm.due_date) {
      showError('Campos obrigatórios', 'Informe título e data da atividade.');
      return;
    }
    const resp = profiles.find((u) => u.id === activityForm.responsible_id);
    setSavingActivity(true);
    try {
      await db.createProspectActivity({
        prospect_id: prospect.id,
        title: activityForm.title,
        description: activityForm.description,
        due_date: activityForm.due_date,
        due_time: activityForm.due_time,
        responsible_id: activityForm.responsible_id || currentUser.id,
        responsible_name: resp?.full_name || currentUser.full_name,
        priority: activityForm.priority,
        status: 'pendente',
      });
      setActivityForm({
        title: '',
        description: '',
        due_date: todayISO(),
        due_time: '',
        responsible_id: prospect.responsible_id || currentUser.id,
        priority: 'media',
      });
      showSuccess('Atividade agendada', 'Lembrete salvo e sincronizado com o lead.');
      await onRefresh();
    } catch (err) {
      showError('Erro ao agendar atividade', err instanceof Error ? err.message : 'Verifique a migração 004.');
    } finally {
      setSavingActivity(false);
    }
  };

  const handleCompleteActivity = async (act: ProspectActivity) => {
    try {
      await db.completeProspectActivity(act, completeOutcomeText);
      setCompletingActId(null);
      setCompleteOutcomeText('');
      showSuccess('Atividade concluída', 'Conclusão registrada no histórico.');
      await onRefresh();
    } catch (err) {
      showError('Erro ao concluir', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  const handleDeleteActivity = async (id: string) => {
    try {
      await db.deleteProspectActivity(id);
      showSuccess('Atividade excluída');
      await onRefresh();
    } catch (err) {
      showError('Erro ao excluir', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  const handleCreateProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!proposalForm.title.trim()) {
      showError('Título obrigatório', 'Informe o título da proposta.');
      return;
    }
    const resp = profiles.find((u) => u.id === proposalForm.responsible_id);
    setSavingProposal(true);
    try {
      await db.createCommercialProposal({
        prospect_id: prospect.id,
        company_id: prospect.converted_company_id || null,
        title: proposalForm.title,
        service_type: proposalForm.service_type,
        value: Number(proposalForm.value) || 0,
        sent_date: proposalForm.sent_date,
        valid_until: proposalForm.valid_until || null,
        responsible_id: proposalForm.responsible_id || currentUser.id,
        responsible_name: resp?.full_name || currentUser.full_name,
        status: proposalForm.status,
        notes: proposalForm.notes,
      });
      setProposalForm({
        ...proposalForm,
        title: '',
        notes: '',
      });
      showSuccess('Proposta registrada', 'Proposta comercial vinculada ao lead.');
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar proposta', err instanceof Error ? err.message : 'Verifique a migração 004.');
    } finally {
      setSavingProposal(false);
    }
  };

  const handleProposalStatusChange = async (pr: CommercialProposal, nextStatus: ProposalStatus) => {
    try {
      await db.updateCommercialProposal(pr.id, {
        status: nextStatus,
        viewed_confirmed_at:
          nextStatus === 'visualizada' ? pr.viewed_confirmed_at || new Date().toISOString() : pr.viewed_confirmed_at,
      });
      showSuccess('Proposta atualizada', `Status alterado para ${PROPOSAL_STATUS_OPTIONS.find((s) => s.value === nextStatus)?.label}.`);
      await onRefresh();
    } catch (err) {
      showError('Erro ao atualizar proposta', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  const handleDeleteProposal = async (id: string) => {
    try {
      await db.deleteCommercialProposal(id);
      showSuccess('Proposta removida');
      await onRefresh();
    } catch (err) {
      showError('Erro ao remover proposta', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  const handleMarkLoss = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lossReasonInput.trim()) {
      showError('Motivo obrigatório', 'Informe o motivo da perda ou desinteresse.');
      return;
    }
    setSavingLoss(true);
    try {
      const updated = await db.updateProspect(prospect.id, {
        status: lossStatusTarget,
        sale_status: 'perdida',
        loss_reason: lossReasonInput.trim(),
        closed_at: todayISO(),
      });
      onUpdateProspectLocal(updated);
      showSuccess('Oportunidade encerrada', 'Motivo de perda registrado para relatórios.');
      await onRefresh();
    } catch (err) {
      showError('Erro ao registrar perda', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSavingLoss(false);
    }
  };

  return (
    <Modal
      open={Boolean(prospect)}
      onClose={onClose}
      title={prospect.company_name}
      subtitle={`${prospect.contact_name} · ${prospect.segment || 'Sem segmento'} · ${prospect.city || 'Sem cidade'}`}
      maxWidthClass="max-w-5xl"
    >
      <div className="space-y-5 text-xs">
        {/* Top Summary & Stage Control */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b border-[#1C2B45]">
          <div className="space-y-1.5">
            <p className="text-[#8FA3C4]">Contatos & Canais</p>
            <p className="text-white flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-[#3B82F6]" />
              <span>{prospect.whatsapp || prospect.phone || '—'}</span>
              {waHref && (
                <a
                  href={waHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ml-1 inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded"
                >
                  <MessageCircle className="w-3 h-3" />
                  WhatsApp
                </a>
              )}
            </p>
            <p className="text-[#8FA3C4]">Instagram: <span className="text-slate-200">{prospect.instagram || '—'}</span></p>
            <p className="text-[#8FA3C4] truncate">Site: <span className="text-slate-200">{prospect.website || 'Sem site informado'}</span></p>
          </div>

          <div className="space-y-1.5">
            <p className="text-[#8FA3C4]">Comercial & Responsável</p>
            <p className="text-slate-200">
              Responsável: <strong className="text-white">{prospect.responsible_name || 'Sem responsável'}</strong>
            </p>
            <p className="text-slate-200 font-mono tabular-nums">
              1º contato: {formatDate(prospect.first_contact_date)} · Próx.: {formatDate(prospect.next_contact_date)}
            </p>
            {typeof prospect.lead_score === 'number' && (
              <p className="text-emerald-300 font-mono tabular-nums">
                Score: {prospect.lead_score}/100 ({prospect.lead_classification || '—'})
              </p>
            )}
          </div>

          <div className="flex flex-col justify-between gap-2">
            <div>
              <label className="block text-[11px] text-[#8FA3C4] mb-1">Etapa do funil</label>
              <select
                value={prospect.status}
                onChange={(e) => void onQuickStatusChange(prospect, e.target.value as ProspectStatus)}
                className="w-full px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white focus:outline-none focus:border-[#3B82F6]"
              >
                {PROSPECT_STATUS_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onOpenEditModal(prospect)}
                className="flex-1 px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded"
              >
                Editar cadastro
              </button>
              {prospect.status !== 'convertido' ? (
                <button
                  type="button"
                  onClick={() => onOpenConvertModal(prospect)}
                  className="flex-1 px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded inline-flex items-center justify-center gap-1"
                >
                  <ArrowRightLeft className="w-3.5 h-3.5" />
                  Fechar venda
                </button>
              ) : (
                <span className="flex-1 px-3 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded inline-flex items-center justify-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Venda fechada
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#0D1424] border border-[#1C2B45] rounded-md">
          <ModalTabBtn active={tab === 'visao_geral'} onClick={() => setTab('visao_geral')} icon={<Users className="w-3.5 h-3.5" />} label="Visão Geral & Distribuição" />
          <ModalTabBtn active={tab === 'historico'} onClick={() => setTab('historico')} icon={<History className="w-3.5 h-3.5" />} label={`Histórico (${leadInteractions.length})`} />
          <ModalTabBtn active={tab === 'atividades'} onClick={() => setTab('atividades')} icon={<CalendarClock className="w-3.5 h-3.5" />} label={`Atividades (${leadActivities.filter((a) => a.status === 'pendente').length})`} />
          <ModalTabBtn active={tab === 'propostas'} onClick={() => setTab('propostas')} icon={<FileText className="w-3.5 h-3.5" />} label={`Propostas (${leadProposals.length})`} />
          <ModalTabBtn active={tab === 'fechamento'} onClick={() => setTab('fechamento')} icon={<CheckCircle2 className="w-3.5 h-3.5" />} label="Fechamento & Venda" />
        </div>

        {/* TAB 1: VISÃO GERAL & DISTRIBUIÇÃO */}
        {tab === 'visao_geral' && (
          <div className="space-y-4">
            {/* Estimated Value + Score */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-3.5 space-y-2">
                <p className="font-semibold text-white">Valor Estimado da Oportunidade</p>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={estimatedValueInput}
                    onChange={(e) => setEstimatedValueInput(e.target.value)}
                    placeholder="Ex: 2500.00"
                    className="flex-1 px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white font-mono tabular-nums"
                  />
                  <button
                    type="button"
                    disabled={savingValue}
                    onClick={() => void handleSaveEstimatedValue()}
                    className="px-3 py-1.5 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded disabled:opacity-50"
                  >
                    {savingValue ? 'Salvando...' : 'Salvar valor'}
                  </button>
                </div>
                {prospect.deal_value != null && prospect.deal_value > 0 && (
                  <p className="text-[11px] text-emerald-300 font-mono tabular-nums">
                    Valor fechado confirmado: {formatCurrency(prospect.deal_value)}
                  </p>
                )}
              </div>

              {typeof prospect.lead_score === 'number' && (
                <div className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-3.5 space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-semibold text-white">Qualificação Comercial</p>
                    <span className="font-mono font-semibold text-emerald-300">{prospect.lead_score}/100 pts</span>
                  </div>
                  {prospect.score_justification && <p className="text-[#8FA3C4]">{prospect.score_justification}</p>}
                </div>
              )}
            </div>

            {Array.isArray(prospect.commercial_opportunities) && prospect.commercial_opportunities.length > 0 && (
              <div className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-3.5 space-y-1.5">
                <p className="font-semibold text-white">Oportunidades comerciais identificadas</p>
                <ul className="space-y-1 text-[#8FA3C4] list-disc list-inside">
                  {prospect.commercial_opportunities.map((opp, idx) => (
                    <li key={idx}>{opp}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Lead Assignment & Participating Collaborators */}
            <form onSubmit={handleSaveDistribution} className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h4 className="font-semibold text-white">Distribuição de Lead & Colaboradores Participantes</h4>
                  <p className="text-[11px] text-[#7D92B5]">
                    {prospect.assigned_at
                      ? `Última atribuição em ${formatDateTime(prospect.assigned_at)}${prospect.assigned_by_name ? ` por ${prospect.assigned_by_name}` : ''}`
                      : 'Defina ou transfira o responsável principal e participantes na negociação'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Responsável principal</label>
                  <select
                    disabled={!canDistributeLeads && prospect.responsible_id !== currentUser.id}
                    value={assignResponsibleId}
                    onChange={(e) => setAssignResponsibleId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white disabled:opacity-60"
                  >
                    <option value="">Sem responsável definido</option>
                    {profiles.filter((u) => u.status === 'ativo').map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.full_name} ({u.job_title})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Observação da atribuição / transferência</label>
                  <input
                    type="text"
                    value={assignmentNotes}
                    onChange={(e) => setAssignmentNotes(e.target.value)}
                    placeholder="Motivo ou contexto da transferência..."
                    className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-[#1C2B45] space-y-2">
                <p className="text-[11px] font-medium text-slate-300">Colaboradores participantes (opcional)</p>
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={newParticipantId}
                    onChange={(e) => setNewParticipantId(e.target.value)}
                    className="flex-1 min-w-[180px] px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    <option value="">Adicionar participante...</option>
                    {profiles.filter((u) => u.status === 'ativo').map((u) => (
                      <option key={u.id} value={u.id}>{u.full_name}</option>
                    ))}
                  </select>
                  <select
                    value={newParticipantRole}
                    onChange={(e) => setNewParticipantRole(e.target.value as SaleParticipationRole)}
                    className="px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    {SALE_PARTICIPATION_ROLE_OPTIONS.map((r) => (
                      <option key={r.value} value={r.value}>{r.label}</option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={handleAddParticipant}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    Incluir
                  </button>
                </div>

                {participating.length > 0 && (
                  <div className="space-y-1.5 pt-1">
                    {participating.map((part, idx) => (
                      <div
                        key={`${part.id}-${part.participation_role}-${idx}`}
                        className="flex items-center justify-between px-3 py-1.5 bg-[#080D18] border border-[#1C2B45] rounded"
                      >
                        <span className="text-slate-200">
                          {part.name} ·{' '}
                          <span className="text-[#3B82F6]">
                            {SALE_PARTICIPATION_ROLE_OPTIONS.find((r) => r.value === part.participation_role)?.label ||
                              part.participation_role}
                          </span>
                        </span>
                        <button
                          type="button"
                          onClick={() => setParticipating((prev) => prev.filter((_, i) => i !== idx))}
                          className="text-rose-400 hover:text-rose-300 text-[11px]"
                        >
                          Remover
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={savingAssignment}
                  className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
                >
                  {savingAssignment ? 'Salvando distribuição...' : 'Salvar atribuição e participantes'}
                </button>
              </div>
            </form>

            {leadAssignments.length > 0 && (
              <div className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-3.5 space-y-2">
                <p className="font-semibold text-white">Histórico de transferências do lead ({leadAssignments.length})</p>
                <div className="divide-y divide-[#1C2B45]">
                  {leadAssignments.map((h) => (
                    <div key={h.id} className="py-2 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                      <span className="text-slate-200">
                        {h.previous_responsible_name || 'Sem responsável'} →{' '}
                        <strong className="text-white">{h.new_responsible_name || 'Sem responsável'}</strong>{' '}
                        <span className="text-[#7D92B5]">(por {h.assigned_by_name})</span>
                        {h.notes ? ` · ${h.notes}` : ''}
                      </span>
                      <span className="font-mono tabular-nums text-[#8FA3C4]">{formatDateTime(h.created_at)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {prospect.notes && (
              <div className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-3.5">
                <p className="font-medium text-slate-300 mb-1">Observações gerais</p>
                <p className="text-[#8FA3C4] whitespace-pre-wrap">{prospect.notes}</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: HISTÓRICO DE CONTATOS (12 TIPOS) */}
        {tab === 'historico' && (
          <div className="space-y-4">
            <form onSubmit={handleAddInteraction} className="bg-[#0D1424] border border-[#1C2B45] rounded-lg p-4 space-y-3">
              <h4 className="font-semibold text-white font-display">Registrar novo acontecimento / contato</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Data e hora</label>
                  <input
                    type="datetime-local"
                    required
                    value={interactionForm.contact_at}
                    onChange={(e) => setInteractionForm({ ...interactionForm, contact_at: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Tipo de contato / evento</label>
                  <select
                    value={interactionForm.contact_type}
                    onChange={(e) => setInteractionForm({ ...interactionForm, contact_type: e.target.value as ContactType })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    {CONTACT_TYPE_OPTIONS.map((t) => (
                      <option key={t.value} value={t.value}>{t.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Responsável</label>
                  <select
                    value={interactionForm.responsible_id}
                    onChange={(e) => setInteractionForm({ ...interactionForm, responsible_id: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    {profiles.map((u) => (
                      <option key={u.id} value={u.id}>{u.full_name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-[#8FA3C4] mb-1">Descrição detalhada *</label>
                <textarea
                  rows={2}
                  required
                  value={interactionForm.summary}
                  onChange={(e) => setInteractionForm({ ...interactionForm, summary: e.target.value })}
                  placeholder="O que foi conversado, enviado ou observado neste contato?"
                  className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white placeholder:text-[#566C8E]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Resultado</label>
                  <input
                    type="text"
                    value={interactionForm.outcome}
                    onChange={(e) => setInteractionForm({ ...interactionForm, outcome: e.target.value })}
                    placeholder="Ex: Pediu proposta"
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Próxima ação</label>
                  <input
                    type="text"
                    value={interactionForm.next_action}
                    onChange={(e) => setInteractionForm({ ...interactionForm, next_action: e.target.value })}
                    placeholder="Ex: Ligar sexta"
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Atualizar próximo contato</label>
                  <input
                    type="date"
                    value={interactionForm.update_next_contact_date}
                    onChange={(e) => setInteractionForm({ ...interactionForm, update_next_contact_date: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={savingInteraction}
                  className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
                >
                  {savingInteraction ? 'Registrando...' : 'Adicionar ao histórico'}
                </button>
              </div>
            </form>

            {leadInteractions.length === 0 ? (
              <p className="text-xs text-[#8FA3C4] py-6 border border-dashed border-[#1C2B45] rounded-md text-center">
                Nenhum contato registrado para este lead até o momento.
              </p>
            ) : (
              <div className="divide-y divide-[#1C2B45] border border-[#1C2B45] rounded-lg bg-[#0D1424]">
                {leadInteractions.map((inter) => (
                  <div key={inter.id} className="p-3.5 space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-[#15223B] border border-[#24375A] text-[#3B82F6] font-medium">
                          {CONTACT_TYPE_OPTIONS.find((t) => t.value === inter.contact_type)?.label || inter.contact_type}
                        </span>
                        <span className="text-slate-200 font-medium">{inter.responsible_name || 'Equipe'}</span>
                      </div>
                      <span className="text-[#8FA3C4] font-mono tabular-nums inline-flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDateTime(inter.contact_at)}
                      </span>
                    </div>
                    <p className="text-slate-200 leading-relaxed">{inter.summary}</p>
                    {(inter.outcome || inter.next_action) && (
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-[#8FA3C4]">
                        {inter.outcome && <span>Resultado: <strong className="text-slate-300 font-normal">{inter.outcome}</strong></span>}
                        {inter.next_action && <span>Próxima ação: <strong className="text-slate-300 font-normal">{inter.next_action}</strong></span>}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: ATIVIDADES & RETORNOS */}
        {tab === 'atividades' && (
          <div className="space-y-4">
            <form onSubmit={handleCreateActivity} className="bg-[#0D1424] border border-[#1C2B45] rounded-lg p-4 space-y-3">
              <h4 className="font-semibold text-white font-display">Agendar próxima atividade / retorno</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Título da atividade *</label>
                  <input
                    type="text"
                    required
                    value={activityForm.title}
                    onChange={(e) => setActivityForm({ ...activityForm, title: e.target.value })}
                    placeholder="Ex: Enviar proposta revisada / Ligar para decisor"
                    className="w-full px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Data *</label>
                  <input
                    type="date"
                    required
                    value={activityForm.due_date}
                    onChange={(e) => setActivityForm({ ...activityForm, due_date: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Horário (opcional)</label>
                  <input
                    type="time"
                    value={activityForm.due_time}
                    onChange={(e) => setActivityForm({ ...activityForm, due_time: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Responsável</label>
                  <select
                    value={activityForm.responsible_id}
                    onChange={(e) => setActivityForm({ ...activityForm, responsible_id: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    {profiles.filter((u) => u.status === 'ativo').map((u) => (
                      <option key={u.id} value={u.id}>{u.full_name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Prioridade</label>
                  <select
                    value={activityForm.priority}
                    onChange={(e) => setActivityForm({ ...activityForm, priority: e.target.value as ActivityPriority })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    {ACTIVITY_PRIORITY_OPTIONS.map((p) => (
                      <option key={p.value} value={p.value}>{p.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Observação</label>
                  <input
                    type="text"
                    value={activityForm.description}
                    onChange={(e) => setActivityForm({ ...activityForm, description: e.target.value })}
                    placeholder="Contexto do lembrete..."
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={savingActivity}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
                >
                  <Plus className="w-3.5 h-3.5" />
                  {savingActivity ? 'Agendando...' : 'Agendar atividade'}
                </button>
              </div>
            </form>

            {leadActivities.length === 0 ? (
              <p className="text-xs text-[#8FA3C4] py-6 border border-dashed border-[#1C2B45] rounded-md text-center">
                Nenhuma atividade agendada para este lead.
              </p>
            ) : (
              <div className="divide-y divide-[#1C2B45] border border-[#1C2B45] rounded-lg bg-[#0D1424]">
                {leadActivities.map((act) => {
                  const prio = ACTIVITY_PRIORITY_OPTIONS.find((p) => p.value === act.priority);
                  const isOverdue = act.status === 'pendente' && act.due_date < todayISO();
                  return (
                    <div key={act.id} className="p-3.5 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-white">{act.title}</span>
                          {prio && <StatusTag label={prio.label} colorClass={prio.colorClass} />}
                          {isOverdue && (
                            <StatusTag label="Atrasada" colorClass="text-rose-300 border-rose-500/40 bg-rose-500/15" />
                          )}
                          {act.status === 'concluida' && (
                            <StatusTag label="Concluída" colorClass="text-emerald-300 border-emerald-500/30 bg-emerald-500/10" />
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {act.status === 'pendente' && (
                            <button
                              type="button"
                              onClick={() => {
                                setCompletingActId(completingActId === act.id ? null : act.id);
                                setCompleteOutcomeText('');
                              }}
                              className="px-2.5 py-1 text-[11px] font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded"
                            >
                              Concluir
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => void handleDeleteActivity(act.id)}
                            className="p-1 text-rose-400 hover:bg-rose-500/10 rounded"
                            title="Excluir atividade"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {act.description && <p className="text-[#8FA3C4]">{act.description}</p>}
                      <p className="text-[11px] text-[#7D92B5] font-mono tabular-nums">
                        Prazo: {formatDate(act.due_date)}{act.due_time ? ` às ${act.due_time}` : ''} · Responsável: {act.responsible_name}
                      </p>
                      {act.completion_outcome && (
                        <p className="text-[11px] text-emerald-300">Resultado: {act.completion_outcome}</p>
                      )}

                      {completingActId === act.id && (
                        <div className="flex items-center gap-2 pt-2 border-t border-[#1C2B45]">
                          <input
                            type="text"
                            value={completeOutcomeText}
                            onChange={(e) => setCompleteOutcomeText(e.target.value)}
                            placeholder="Resultado real obtido na atividade..."
                            className="flex-1 px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                          />
                          <button
                            type="button"
                            onClick={() => void handleCompleteActivity(act)}
                            className="px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded"
                          >
                            Confirmar
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: PROPOSTAS COMERCIAIS */}
        {tab === 'propostas' && (
          <div className="space-y-4">
            <form onSubmit={handleCreateProposal} className="bg-[#0D1424] border border-[#1C2B45] rounded-lg p-4 space-y-3">
              <h4 className="font-semibold text-white font-display">Registrar nova proposta comercial</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Título da proposta *</label>
                  <input
                    type="text"
                    required
                    value={proposalForm.title}
                    onChange={(e) => setProposalForm({ ...proposalForm, title: e.target.value })}
                    placeholder="Ex: Site Institucional + SEO Local"
                    className="w-full px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Serviço</label>
                  <select
                    value={proposalForm.service_type}
                    onChange={(e) => setProposalForm({ ...proposalForm, service_type: e.target.value as ServiceType })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    {SERVICE_TYPE_OPTIONS.map((s) => (
                      <option key={s.value} value={s.value}>{s.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Valor da proposta (R$) *</label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    value={proposalForm.value}
                    onChange={(e) => setProposalForm({ ...proposalForm, value: e.target.value })}
                    placeholder="2500.00"
                    className="w-full px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white font-mono tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Data de envio</label>
                  <input
                    type="date"
                    required
                    value={proposalForm.sent_date}
                    onChange={(e) => setProposalForm({ ...proposalForm, sent_date: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Validade (opcional)</label>
                  <input
                    type="date"
                    value={proposalForm.valid_until}
                    onChange={(e) => setProposalForm({ ...proposalForm, valid_until: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Responsável</label>
                  <select
                    value={proposalForm.responsible_id}
                    onChange={(e) => setProposalForm({ ...proposalForm, responsible_id: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    {profiles.filter((u) => u.status === 'ativo').map((u) => (
                      <option key={u.id} value={u.id}>{u.full_name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Status inicial</label>
                  <select
                    value={proposalForm.status}
                    onChange={(e) => setProposalForm({ ...proposalForm, status: e.target.value as ProposalStatus })}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  >
                    {PROPOSAL_STATUS_OPTIONS.filter((s) => s.value !== 'visualizada').map((s) => (
                      <option key={s.value} value={s.value}>{s.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#8FA3C4] mb-1">Observações</label>
                  <input
                    type="text"
                    value={proposalForm.notes}
                    onChange={(e) => setProposalForm({ ...proposalForm, notes: e.target.value })}
                    placeholder="Condições ou escopo..."
                    className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={savingProposal}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
                >
                  <Plus className="w-3.5 h-3.5" />
                  {savingProposal ? 'Salvando...' : 'Registrar proposta'}
                </button>
              </div>
            </form>

            {leadProposals.length === 0 ? (
              <p className="text-xs text-[#8FA3C4] py-6 border border-dashed border-[#1C2B45] rounded-md text-center">
                Nenhuma proposta cadastrada para este lead.
              </p>
            ) : (
              <div className="divide-y divide-[#1C2B45] border border-[#1C2B45] rounded-lg bg-[#0D1424]">
                {leadProposals.map((pr) => {
                  const st = PROPOSAL_STATUS_OPTIONS.find((s) => s.value === pr.status);
                  const srv = SERVICE_TYPE_OPTIONS.find((s) => s.value === pr.service_type);
                  return (
                    <div key={pr.id} className="p-3.5 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-white">{pr.title}</span>
                          <span className="font-mono font-semibold text-emerald-400 tabular-nums">
                            {formatCurrency(pr.value)}
                          </span>
                          {st && <StatusTag label={st.label} colorClass={st.colorClass} />}
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          {pr.status !== 'visualizada' && pr.status !== 'aceita' && (
                            <button
                              type="button"
                              onClick={() => void handleProposalStatusChange(pr, 'visualizada')}
                              title="Registrar confirmação real de visualização pelo cliente"
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded"
                            >
                              <Eye className="w-3 h-3" />
                              Confirmar visualização
                            </button>
                          )}
                          <select
                            aria-label={`Status da proposta ${pr.title}`}
                            value={pr.status}
                            onChange={(e) => void handleProposalStatusChange(pr, e.target.value as ProposalStatus)}
                            className="px-2 py-1 text-[11px] bg-[#080D18] border border-[#1C2B45] rounded text-slate-200"
                          >
                            {PROPOSAL_STATUS_OPTIONS.map((opt) => (
                              <option key={opt.value} value={opt.value}>{opt.label}</option>
                            ))}
                          </select>
                          <button
                            type="button"
                            onClick={() => void handleDeleteProposal(pr.id)}
                            className="p-1 text-rose-400 hover:bg-rose-500/10 rounded"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <p className="text-[11px] text-[#7D92B5] font-mono tabular-nums">
                        {srv?.label || pr.service_type} · Enviada em {formatDate(pr.sent_date)}
                        {pr.valid_until ? ` · Válida até ${formatDate(pr.valid_until)}` : ''} · Responsável: {pr.responsible_name}
                        {pr.viewed_confirmed_at ? ` · Visualização confirmada em ${formatDateTime(pr.viewed_confirmed_at)}` : ''}
                      </p>
                      {pr.notes && <p className="text-[#8FA3C4]">{pr.notes}</p>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: FECHAMENTO & VENDA */}
        {tab === 'fechamento' && (
          <div className="space-y-4">
            {prospect.status === 'convertido' ? (
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-5 space-y-2">
                <p className="text-sm font-semibold text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  Venda Fechada e Integrada ao Módulo Empresas
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <div>
                    <p className="text-[11px] text-[#8FA3C4]">Serviço contratado</p>
                    <p className="text-white font-medium">
                      {SERVICE_TYPE_OPTIONS.find((s) => s.value === prospect.contracted_service)?.label ||
                        prospect.contracted_service ||
                        'Conforme cadastro em Empresas'}
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-[#8FA3C4]">Valor negociado</p>
                    <p className="text-emerald-300 font-mono font-semibold tabular-nums">
                      {prospect.deal_value != null ? formatCurrency(prospect.deal_value) : '—'}
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-[#8FA3C4]">Data do fechamento</p>
                    <p className="text-white font-mono tabular-nums">
                      {formatDate(prospect.closed_at || prospect.converted_at)}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-[#0D1424] border border-emerald-500/30 rounded-lg p-4 space-y-3">
                  <h4 className="font-semibold text-white flex items-center gap-2">
                    <ArrowRightLeft className="w-4 h-4 text-emerald-400" />
                    Fechar Venda e Converter em Cliente
                  </h4>
                  <p className="text-[#8FA3C4] leading-relaxed">
                    Ao confirmar o fechamento, o sistema cria o registro em <strong>Empresas</strong> sem duplicação, preserva todo o histórico de contatos/propostas e permite lançar comissões configuráveis para vendedor e colaboradores participantes.
                  </p>
                  <button
                    type="button"
                    onClick={() => onOpenConvertModal(prospect)}
                    className="w-full py-2.5 px-4 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded-md"
                  >
                    Abrir Assistente de Fechamento & Comissões
                  </button>
                </div>

                <form onSubmit={handleMarkLoss} className="bg-[#0D1424] border border-rose-500/30 rounded-lg p-4 space-y-3">
                  <h4 className="font-semibold text-white flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-rose-400" />
                    Registrar Perda ou Desinteresse
                  </h4>
                  <div>
                    <label className="block text-[11px] text-[#8FA3C4] mb-1">Classificação final</label>
                    <select
                      value={lossStatusTarget}
                      onChange={(e) => setLossStatusTarget(e.target.value as 'perdido' | 'sem_interesse')}
                      className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                    >
                      <option value="perdido">Venda perdida</option>
                      <option value="sem_interesse">Sem interesse</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] text-[#8FA3C4] mb-1">Motivo da perda *</label>
                    <input
                      type="text"
                      required
                      value={lossReasonInput}
                      onChange={(e) => setLossReasonInput(e.target.value)}
                      placeholder="Ex: Sem orçamento no momento, fechou com concorrente..."
                      className="w-full px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={savingLoss}
                    className="w-full py-2 px-4 text-xs font-medium text-rose-200 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 rounded-md disabled:opacity-50"
                  >
                    {savingLoss ? 'Registrando...' : 'Registrar motivo e encerrar'}
                  </button>
                </form>
              </div>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
}

function ModalTabBtn({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
        active ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}
