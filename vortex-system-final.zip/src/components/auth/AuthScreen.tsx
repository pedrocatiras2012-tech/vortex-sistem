import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Database, Eye, EyeOff, KeyRound, Lock, Mail, User } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { isValidEmail } from '../../lib/formatters';

type AuthMode = 'login' | 'signup' | 'recovery';

function translateAuthError(msg: string): string {
  const lower = msg.toLowerCase();
  if (lower.includes('invalid login credentials')) return 'E-mail ou senha incorretos.';
  if (lower.includes('email not confirmed')) return 'Confirme seu e-mail antes de acessar o sistema.';
  if (lower.includes('user already registered')) return 'Este e-mail já está cadastrado.';
  if (lower.includes('password should be at least')) return 'A senha deve ter no mínimo 6 caracteres.';
  if (lower.includes('rate limit')) return 'Muitas tentativas recentes. Aguarde alguns instantes.';
  if (lower.includes('invalid api key')) {
    return 'Chave de API do Supabase inválida. Verifique se VITE_SUPABASE_ANON_KEY nos Secrets corresponde à chave anon/publishable do mesmo projeto de VITE_SUPABASE_URL.';
  }
  if (lower.includes('invalid path specified in request url')) {
    return 'VITE_SUPABASE_URL contém caminho extra (como /rest/v1/). Use apenas a URL raiz: https://seu-projeto.supabase.co';
  }
  return msg;
}

export function AuthScreen() {
  const { configured, configError, signIn, signUp, resetPassword } = useAuth();
  const { showSuccess, showError } = useToast();

  const [mode, setMode] = useState<AuthMode>('login');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [recoverySent, setRecoverySent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !isValidEmail(email)) {
      showError('E-mail inválido', 'Informe um endereço de e-mail válido.');
      return;
    }

    if (mode === 'recovery') {
      setSubmitting(true);
      try {
        await resetPassword(email);
        setRecoverySent(true);
        showSuccess('Instruções enviadas', 'Verifique sua caixa de entrada para redefinir a senha.');
      } catch (err) {
        showError('Erro na recuperação', translateAuthError(err instanceof Error ? err.message : 'Falha ao enviar e-mail.'));
      } finally {
        setSubmitting(false);
      }
      return;
    }

    if (password.length < 6) {
      showError('Senha inválida', 'A senha deve possuir pelo menos 6 caracteres.');
      return;
    }

    if (mode === 'signup') {
      if (fullName.trim().length < 2) {
        showError('Nome obrigatório', 'Informe seu nome completo.');
        return;
      }
      if (password !== confirmPassword) {
        showError('Senhas divergentes', 'A confirmação de senha não confere.');
        return;
      }
    }

    setSubmitting(true);
    try {
      if (mode === 'login') {
        await signIn(email, password);
        showSuccess('Sessão iniciada', 'Bem-vindo ao VORTEX SYSTEM.');
      } else {
        const res = await signUp(email, password, fullName);
        if (res.needsEmailConfirmation) {
          showSuccess('Cadastro realizado', 'Confirme seu e-mail para liberar o acesso ao sistema.');
          setMode('login');
        } else {
          showSuccess('Conta criada', 'Seu acesso ao VORTEX SYSTEM foi configurado.');
        }
      }
    } catch (err) {
      showError('Falha na autenticação', translateAuthError(err instanceof Error ? err.message : 'Tente novamente.'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080D18] text-slate-100 flex flex-col lg:flex-row">
      {/* Left Brand Panel */}
      <div className="lg:w-[46%] bg-[#0D1424] border-b lg:border-b-0 lg:border-r border-[#1C2B45] p-8 sm:p-12 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-3">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true">
              <rect width="32" height="32" rx="6" fill="#2563EB" />
              <path d="M8.5 9.5L16 23L23.5 9.5H19.8L16 16.8L12.2 9.5H8.5Z" fill="#FFFFFF" />
            </svg>
            <span className="font-display font-bold text-lg tracking-tight text-white">
              VORTEX SYSTEM
            </span>
          </div>

          <div className="mt-12 lg:mt-20 max-w-md">
            <h1 className="font-display text-2xl sm:text-3xl font-semibold text-white leading-tight">
              Gestão inteligente, resultados reais.
            </h1>
            <p className="mt-4 text-sm text-[#8FA3C4] leading-relaxed">
              Plataforma corporativa integrada para prospecção comercial, relacionamento com clientes, controle de comissões, fluxo financeiro e produtividade de equipe.
            </p>

            <div className="mt-8 border-t border-[#1C2B45] pt-6 grid grid-cols-2 gap-6 text-xs">
              <div>
                <p className="font-semibold text-white">CRM & Prospecção</p>
                <p className="text-[#8FA3C4] mt-1">Funil Kanban, histórico permanente e conversão segura em clientes.</p>
              </div>
              <div>
                <p className="font-semibold text-white">Comissões & Finanças</p>
                <p className="text-[#8FA3C4] mt-1">Cálculo automático, datas efetivas de pagamento e relatórios CSV.</p>
              </div>
            </div>
          </div>
        </div>

        <p className="text-xs text-[#647B9E] mt-10">
          VORTEX SYSTEM · Acesso restrito a colaboradores autorizados
        </p>
      </div>

      {/* Right Auth / Config Panel */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          {!configured ? (
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-6 sm:p-8">
              <div className="flex items-center gap-3 text-amber-400 mb-4">
                <Database className="w-5 h-5 shrink-0" />
                <h2 className="font-display text-lg font-semibold text-white">
                  Configuração do Supabase pendente
                </h2>
              </div>
              <p className="text-sm text-[#8FA3C4] leading-relaxed">
                Para conectar o VORTEX SYSTEM ao seu projeto Supabase existente sem expor chaves secretas, adicione os dois parâmetros públicos abaixo no painel <strong className="text-white">Secrets</strong> do Google AI Studio (ou no arquivo <code className="font-mono text-slate-200">.env</code>):
              </p>

              {configError && (
                <div className="mt-4 p-3 rounded-md border border-rose-500/40 bg-rose-500/10 text-xs text-rose-200">
                  {configError}
                </div>
              )}

              <div className="mt-4 bg-[#080D18] border border-[#1C2B45] rounded-md p-4 font-mono text-xs text-slate-300 space-y-1.5">
                <div>VITE_SUPABASE_URL=https://seu-projeto.supabase.co</div>
                <div>VITE_SUPABASE_ANON_KEY=sua-chave-anon-publica</div>
              </div>

              <div className="mt-5 space-y-2 text-xs text-[#8FA3C4]">
                <p className="text-slate-200 font-medium">Como o aplicativo lê essas variáveis:</p>
                <p>• O servidor interno (<code className="font-mono text-slate-300">server.ts</code>) lê os Secrets configurados em tempo de execução e entrega apenas a URL e a chave pública <code className="font-mono text-slate-300">anon</code>.</p>
                <p>• Nenhuma tabela existente será apagada ou modificada automaticamente.</p>
              </div>
            </div>
          ) : (
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-6 sm:p-8">
              <div className="mb-6">
                <h2 className="font-display text-xl font-semibold text-white">
                  {mode === 'login' && 'Acessar plataforma'}
                  {mode === 'signup' && 'Criar conta de acesso'}
                  {mode === 'recovery' && 'Recuperar senha'}
                </h2>
                <p className="text-xs text-[#8FA3C4] mt-1">
                  {mode === 'login' && 'Informe suas credenciais corporativas para continuar.'}
                  {mode === 'signup' && 'Cadastre seu usuário. O proprietário definirá suas permissões.'}
                  {mode === 'recovery' && 'Enviaremos um link de redefinição para o seu e-mail.'}
                </p>
              </div>

              {mode === 'recovery' && recoverySent ? (
                <div className="p-4 rounded-md border border-emerald-500/30 bg-emerald-500/10 text-sm text-emerald-200 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">E-mail de recuperação enviado</p>
                    <p className="text-xs text-emerald-200/80 mt-1">
                      Confira sua caixa de entrada e spam para concluir a redefinição de senha.
                    </p>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {mode === 'signup' && (
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Nome completo
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="Ex: Mariana Almeida"
                          className="w-full pl-9 pr-3 py-2.5 text-sm bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                        />
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      E-mail
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="nome@empresa.com.br"
                        className="w-full pl-9 pr-3 py-2.5 text-sm bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                      />
                    </div>
                  </div>

                  {mode !== 'recovery' && (
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="block text-xs font-medium text-slate-300">Senha</label>
                        {mode === 'login' && (
                          <button
                            type="button"
                            onClick={() => {
                              setRecoverySent(false);
                              setMode('recovery');
                            }}
                            className="text-xs text-[#3B82F6] hover:text-blue-400 transition-colors"
                          >
                            Esqueci minha senha
                          </button>
                        )}
                      </div>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required
                          minLength={6}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full pl-9 pr-10 py-2.5 text-sm bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword((v) => !v)}
                          aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-[#647B9E] hover:text-slate-300"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  )}

                  {mode === 'signup' && (
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Confirmar senha
                      </label>
                      <div className="relative">
                        <KeyRound className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required
                          minLength={6}
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full pl-9 pr-3 py-2.5 text-sm bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                        />
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-2.5 px-4 bg-[#2563EB] hover:bg-[#3B82F6] text-white text-sm font-medium rounded-md transition-colors inline-flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <span>
                      {submitting
                        ? 'Processando...'
                        : mode === 'login'
                        ? 'Entrar no sistema'
                        : mode === 'signup'
                        ? 'Criar conta'
                        : 'Enviar link de recuperação'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              )}

              <div className="mt-6 pt-5 border-t border-[#1C2B45] flex items-center justify-between text-xs text-[#8FA3C4]">
                {mode === 'login' ? (
                  <>
                    <span>Ainda não possui acesso?</span>
                    <button
                      type="button"
                      onClick={() => setMode('signup')}
                      className="text-[#3B82F6] hover:text-blue-400 font-medium"
                    >
                      Cadastrar usuário
                    </button>
                  </>
                ) : (
                  <>
                    <span>Já possui uma conta ativa?</span>
                    <button
                      type="button"
                      onClick={() => {
                        setRecoverySent(false);
                        setMode('login');
                      }}
                      className="text-[#3B82F6] hover:text-blue-400 font-medium"
                    >
                      Voltar para o login
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
