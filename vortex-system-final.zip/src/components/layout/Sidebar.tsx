import React from 'react';
import {
  BarChart3,
  Briefcase,
  Building2,
  CheckSquare,
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  Percent,
  Settings,
  Target,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import type { AppPage, ModulePermissions } from '../../types';

export interface NavItem {
  id: AppPage;
  label: string;
  permissionKey: keyof ModulePermissions;
  icon: React.ComponentType<{ className?: string }>;
}

export const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', permissionKey: 'dashboard', icon: LayoutDashboard },
  { id: 'prospeccao', label: 'Prospecção', permissionKey: 'prospeccao', icon: Target },
  { id: 'empresas', label: 'Empresas', permissionKey: 'empresas', icon: Building2 },
  { id: 'equipe', label: 'Equipe', permissionKey: 'equipe', icon: Users },
  { id: 'comissoes', label: 'Comissões', permissionKey: 'comissoes', icon: Percent },
  { id: 'financeiro', label: 'Financeiro', permissionKey: 'financeiro', icon: Wallet },
  { id: 'marketing', label: 'Marketing e Tarefas', permissionKey: 'marketing', icon: CheckSquare },
  { id: 'relatorios', label: 'Relatórios', permissionKey: 'relatorios', icon: BarChart3 },
  { id: 'configuracoes', label: 'Configurações', permissionKey: 'configuracoes', icon: Settings },
];

interface SidebarProps {
  activePage: AppPage;
  onNavigate: (page: AppPage) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  hasPermission: (key: keyof ModulePermissions) => boolean;
  organizationName: string;
}

export function Sidebar({
  activePage,
  onNavigate,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
  hasPermission,
  organizationName,
}: SidebarProps) {
  const visibleItems = NAV_ITEMS.filter((item) => {
    if (item.id === 'configuracoes') return true; // Perfil & Preferências sempre acessíveis
    return hasPermission(item.permissionKey);
  });

  const navContent = (isMobile: boolean) => (
    <div className="flex flex-col h-full bg-[#0D1424] border-r border-[#1C2B45]">
      {/* Brand header */}
      <div className="h-16 px-4 flex items-center justify-between border-b border-[#1C2B45] shrink-0">
        <button
          type="button"
          onClick={() => {
            onNavigate('dashboard');
            if (isMobile) onCloseMobile();
          }}
          className="flex items-center gap-3 min-w-0 text-left"
        >
          <svg width="28" height="28" viewBox="0 0 32 32" fill="none" className="shrink-0" aria-hidden="true">
            <rect width="32" height="32" rx="6" fill="#2563EB" />
            <path d="M8.5 9.5L16 23L23.5 9.5H19.8L16 16.8L12.2 9.5H8.5Z" fill="#FFFFFF" />
          </svg>
          {(!collapsed || isMobile) && (
            <div className="min-w-0">
              <span className="block font-display font-bold text-sm tracking-tight text-white truncate">
                VORTEX SYSTEM
              </span>
              <span className="block text-[11px] text-[#7D92B5] truncate">
                {organizationName || 'Gestão empresarial'}
              </span>
            </div>
          )}
        </button>

        {isMobile ? (
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Fechar menu"
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-[#16223A]"
          >
            <X className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={onToggleCollapse}
            aria-label={collapsed ? 'Expandir barra lateral' : 'Recolher barra lateral'}
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-[#16223A] transition-colors shrink-0"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        )}
      </div>

      {/* Navigation links */}
      <nav className="flex-1 overflow-y-auto py-4 px-2.5 space-y-1" aria-label="Navegação principal">
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onNavigate(item.id);
                if (isMobile) onCloseMobile();
              }}
              title={collapsed && !isMobile ? item.label : undefined}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${
                isActive
                  ? 'bg-[#2563EB] text-white'
                  : 'text-[#9BB0D1] hover:text-white hover:bg-[#152138]'
              } ${collapsed && !isMobile ? 'justify-center px-2' : ''}`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {(!collapsed || isMobile) && <span className="truncate">{item.label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Bottom tagline */}
      {(!collapsed || isMobile) && (
        <div className="px-4 py-3.5 border-t border-[#1C2B45] text-[11px] text-[#6E84A8] flex items-center gap-2">
          <Briefcase className="w-3.5 h-3.5 shrink-0 text-[#3B82F6]" />
          <span className="truncate">Gestão inteligente, resultados reais</span>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop fixed sidebar */}
      <aside
        className={`hidden lg:block fixed inset-y-0 left-0 z-30 transition-[width] duration-200 ${
          collapsed ? 'w-[72px]' : 'w-64'
        }`}
      >
        {navContent(false)}
      </aside>

      {/* Mobile slide-over */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-[1px]"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative w-64 max-w-[80vw] h-full z-50">
            {navContent(true)}
          </aside>
        </div>
      )}
    </>
  );
}
