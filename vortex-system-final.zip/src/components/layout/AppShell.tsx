import React, { useState } from 'react';
import { LogOut, Menu, UserCircle2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { ROLE_LABELS } from '../../lib/constants';
import type { AppPage } from '../../types';
import { NAV_ITEMS, Sidebar } from './Sidebar';

interface AppShellProps {
  activePage: AppPage;
  onNavigate: (page: AppPage) => void;
  organizationName: string;
  children: React.ReactNode;
}

export function AppShell({
  activePage,
  onNavigate,
  organizationName,
  children,
}: AppShellProps) {
  const { profile, hasPermission, signOut } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const currentNav = NAV_ITEMS.find((i) => i.id === activePage);
  const initials = (profile?.full_name || 'VS')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');

  return (
    <div className="min-h-screen bg-[#080D18] text-slate-100 flex">
      <Sidebar
        activePage={activePage}
        onNavigate={onNavigate}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((v) => !v)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        hasPermission={hasPermission}
        organizationName={organizationName}
      />

      <div
        className={`flex-1 flex flex-col min-w-0 transition-[padding] duration-200 ${
          collapsed ? 'lg:pl-[72px]' : 'lg:pl-64'
        }`}
      >
        {/* Top bar following clean contract: Breadcrumb — Profile & Sign out */}
        <header className="h-16 bg-[#0D1424]/95 border-b border-[#1C2B45] px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-20 backdrop-blur-sm">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Abrir navegação"
              className="lg:hidden p-2 rounded-md text-slate-300 hover:text-white hover:bg-[#16223A]"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-[#7D92B5] hidden sm:inline whitespace-nowrap">VORTEX SYSTEM</span>
              <span className="text-[#4B6186] hidden sm:inline" aria-hidden="true">/</span>
              <h1 className="font-display font-semibold text-white truncate">
                {currentNav?.label || 'Dashboard'}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('configuracoes')}
              className="flex items-center gap-2.5 px-2.5 py-1.5 rounded-md hover:bg-[#152138] transition-colors text-left"
              title="Abrir perfil e configurações"
            >
              <div className="w-8 h-8 rounded-md bg-[#2563EB]/20 border border-[#3B82F6]/30 flex items-center justify-center text-xs font-semibold text-[#3B82F6] shrink-0">
                {initials || <UserCircle2 className="w-4 h-4" />}
              </div>
              <div className="hidden sm:block min-w-0">
                <p className="text-xs font-medium text-white truncate max-w-[160px]">
                  {profile?.full_name || 'Usuário'}
                </p>
                <p className="text-[11px] text-[#8FA3C4] truncate">
                  {profile ? ROLE_LABELS[profile.role] : 'Colaborador'}
                </p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => void signOut()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-[#111C30] hover:bg-[#192844] border border-[#1C2B45] rounded-md transition-colors whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sair</span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1600px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
