import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PaginationProps {
  currentPage: number;
  totalItems: number;
  pageSize: number;
  onPageChange: (page: number) => void;
}

export function Pagination({
  currentPage,
  totalItems,
  pageSize,
  onPageChange,
}: PaginationProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const start = totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1;
  const end = Math.min(totalItems, currentPage * pageSize);

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 border-t border-[#1C2B45] bg-[#0D1424]/60 text-xs text-[#8FA3C4]">
      <div className="tabular-nums">
        Exibindo <span className="text-slate-200 font-medium">{start}</span>–
        <span className="text-slate-200 font-medium">{end}</span> de{' '}
        <span className="text-slate-200 font-medium">{totalItems}</span> registros
      </div>

      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => onPageChange(Math.max(1, currentPage - 1))}
          disabled={currentPage <= 1}
          aria-label="Página anterior"
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded border border-[#1C2B45] bg-[#111C30] text-slate-300 hover:text-white hover:border-[#2C4166] disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
          Anterior
        </button>

        <span className="px-2.5 py-1 text-slate-200 tabular-nums font-mono">
          {currentPage} / {totalPages}
        </span>

        <button
          type="button"
          onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage >= totalPages}
          aria-label="Próxima página"
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded border border-[#1C2B45] bg-[#111C30] text-slate-300 hover:text-white hover:border-[#2C4166] disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0"
        >
          Próxima
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
