import React from 'react';

interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({
  icon,
  title,
  description,
  actionLabel,
  onAction,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-14 px-6 border border-[#1C2B45] rounded-lg bg-[#111C30]">
      <div className="p-3 rounded-lg bg-[#0D1424] border border-[#1C2B45] text-[#3B82F6] mb-3">
        {icon}
      </div>
      <h3 className="text-sm font-semibold text-white font-display">{title}</h3>
      <p className="text-xs text-[#8FA3C4] max-w-md mt-1 leading-relaxed">{description}</p>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="mt-4 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

export function TableSkeleton({ rows = 6, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="border border-[#1C2B45] rounded-lg bg-[#111C30] overflow-hidden">
      <div className="h-10 bg-[#0D1424] border-b border-[#1C2B45]" />
      <div className="divide-y divide-[#1C2B45]">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="flex items-center gap-4 px-4 h-11 animate-pulse">
            {Array.from({ length: cols }).map((__, c) => (
              <div
                key={c}
                className="h-3 bg-[#1A2842] rounded flex-1"
                style={{ maxWidth: c === 0 ? '220px' : '140px' }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
