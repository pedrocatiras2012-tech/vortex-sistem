import React from 'react';

interface StatusTagProps {
  label: string;
  colorClass: string;
  icon?: React.ReactNode;
}

/**
 * Clean enterprise rectangular status tag (no rounded-full capsules, no pulsing dots).
 */
export function StatusTag({ label, colorClass, icon }: StatusTagProps) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded border text-xs font-medium whitespace-nowrap shrink-0 ${colorClass}`}
    >
      {icon}
      <span>{label}</span>
    </span>
  );
}
