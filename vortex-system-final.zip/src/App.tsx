import { useCallback, useEffect, useMemo, useState } from 'react';
import { ShieldAlert } from 'lucide-react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ToastProvider, useToast } from './contexts/ToastContext';
import * as db from './services/database';
import type {
  AppPage,
  CommercialProposal,
  Commission,
  Company,
  Expense,
  LeadAssignmentHistory,
  MarketingTask,
  Payment,
  Prospect,
  ProspectActivity,
  ProspectInteraction,
  SaleCollaborator,
  SystemSettings,
  TeamInvite,
  UserProfile,
} from './types';
import { AuthScreen } from './components/auth/AuthScreen';
import { AppShell } from './components/layout/AppShell';
import { DashboardPage } from './pages/DashboardPage';
import { ProspectsPage } from './pages/ProspectsPage';
import { CompaniesPage } from './pages/CompaniesPage';
import { TeamPage } from './pages/TeamPage';
import { CommissionsPage } from './pages/CommissionsPage';
import { FinancePage } from './pages/FinancePage';
import { MarketingTasksPage } from './pages/MarketingTasksPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';

const INITIAL_SETTINGS: SystemSettings = {
  id: 'default',
  organization_name: 'VORTEX SYSTEM',
  organization_cnpj: '',
  organization_email: '',
  organization_phone: '',
  organization_city: '',
  default_commission_pct: 10,
  currency: 'BRL',
  preferences: {
    compactTables: false,
    defaultPeriodDays: 30,
    customJobRoles: [],
    customDepartments: [],
  },
};

function VortexWorkspace() {
  const {
    session,
    profile,
    loading: authLoading,
    configured,
    isAdminOrOwner,
    isManagerOrAbove,
    canViewAllLeads,
    canDistributeLeads,
    hasPermission,
    signOut,
  } = useAuth();
  const { showError } = useToast();

  const [activePage, setActivePage] = useState<AppPage>('dashboard');
  const [settingsTab, setSettingsTab] = useState<'perfil' | 'empresa' | 'preferencias' | 'banco'>('perfil');

  const [dataLoading, setDataLoading] = useState(false);
  const [prospectsMissing, setProspectsMissing] = useState(false);
  const [activitiesMissing, setActivitiesMissing] = useState(false);
  const [proposalsMissing, setProposalsMissing] = useState(false);
  const [invitesMissing, setInvitesMissing] = useState(false);

  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [teamInvites, setTeamInvites] = useState<TeamInvite[]>([]);
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [interactions, setInteractions] = useState<ProspectInteraction[]>([]);
  const [activities, setActivities] = useState<ProspectActivity[]>([]);
  const [proposals, setProposals] = useState<CommercialProposal[]>([]);
  const [assignmentsHistory, setAssignmentsHistory] = useState<LeadAssignmentHistory[]>([]);
  const [saleCollaborators, setSaleCollaborators] = useState<SaleCollaborator[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [tasks, setTasks] = useState<MarketingTask[]>([]);
  const [settings, setSettings] = useState<SystemSettings>(INITIAL_SETTINGS);
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState(false);

  useEffect(() => {
    const handleQuota = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuota);
  }, []);

  const loadAllData = useCallback(async () => {
    if (!session || !profile || profile.status === 'inativo') return;
    setDataLoading(true);
    try {
      const [
        resProfiles,
        resInvites,
        resProspects,
        resInteractions,
        resActivities,
        resProposals,
        resAssignments,
        resSaleCollabs,
        resCompanies,
        resCommissions,
        resPayments,
        resExpenses,
        resTasks,
        resSettings,
      ] = await Promise.allSettled([
        db.fetchProfiles(),
        db.fetchTeamInvites(),
        db.fetchProspects(),
        db.fetchProspectInteractions(),
        db.fetchProspectActivities(),
        db.fetchCommercialProposals(),
        db.fetchLeadAssignmentsHistory(),
        db.fetchSaleCollaborators(),
        db.fetchCompanies(),
        db.fetchCommissions(),
        db.fetchPayments(),
        db.fetchExpenses(),
        db.fetchMarketingTasks(),
        db.fetchSystemSettings(),
      ]);

      if (resProfiles.status === 'fulfilled') setProfiles(resProfiles.value);
      if (resInvites.status === 'fulfilled') {
        setTeamInvites(resInvites.value.items);
        setInvitesMissing(resInvites.value.tableMissing);
      }
      if (resProspects.status === 'fulfilled') {
        setProspects(resProspects.value.items);
        setProspectsMissing(resProspects.value.tableMissing);
      }
      if (resInteractions.status === 'fulfilled') setInteractions(resInteractions.value.items);
      if (resActivities.status === 'fulfilled') {
        setActivities(resActivities.value.items);
        setActivitiesMissing(resActivities.value.tableMissing);
      }
      if (resProposals.status === 'fulfilled') {
        setProposals(resProposals.value.items);
        setProposalsMissing(resProposals.value.tableMissing);
      }
      if (resAssignments.status === 'fulfilled') setAssignmentsHistory(resAssignments.value);
      if (resSaleCollabs.status === 'fulfilled') setSaleCollaborators(resSaleCollabs.value);
      if (resCompanies.status === 'fulfilled') setCompanies(resCompanies.value);
      if (resCommissions.status === 'fulfilled') setCommissions(resCommissions.value);
      if (resPayments.status === 'fulfilled') setPayments(resPayments.value);
      if (resExpenses.status === 'fulfilled') setExpenses(resExpenses.value);
      if (resTasks.status === 'fulfilled') setTasks(resTasks.value);
      if (resSettings.status === 'fulfilled') setSettings(resSettings.value.settings);
    } catch (err) {
      showError('Erro ao carregar dados', err instanceof Error ? err.message : 'Verifique a conexão.');
    } finally {
      setDataLoading(false);
    }
  }, [session, profile, showError]);

  useEffect(() => {
    if (session && profile && profile.status === 'ativo') {
      void loadAllData();
    }
  }, [session, profile, loadAllData]);

  // Permission-aware workspace scoping (mirrors RLS even before migration 004 is applied)
  const scopedProspects = useMemo(() => {
    if (!profile) return [];
    if (canViewAllLeads) return prospects;
    return prospects.filter(
      (p) =>
        p.responsible_id === profile.id ||
        p.member_id === profile.id ||
        (p.participating_collaborators || []).some((pc) => pc.id === profile.id)
    );
  }, [prospects, profile, canViewAllLeads]);

  const scopedProspectIds = useMemo(
    () => new Set(scopedProspects.map((p) => p.id)),
    [scopedProspects]
  );

  const scopedInteractions = useMemo(() => {
    if (canViewAllLeads) return interactions;
    return interactions.filter((i) => scopedProspectIds.has(i.prospect_id));
  }, [interactions, canViewAllLeads, scopedProspectIds]);

  const scopedActivities = useMemo(() => {
    if (canViewAllLeads) return activities;
    return activities.filter(
      (a) => a.responsible_id === profile?.id || scopedProspectIds.has(a.prospect_id)
    );
  }, [activities, canViewAllLeads, profile?.id, scopedProspectIds]);

  const scopedProposals = useMemo(() => {
    if (canViewAllLeads) return proposals;
    return proposals.filter(
      (pr) => pr.responsible_id === profile?.id || scopedProspectIds.has(pr.prospect_id)
    );
  }, [proposals, canViewAllLeads, profile?.id, scopedProspectIds]);

  const canViewTeamCommissions = isManagerOrAbove || hasPermission('visualizar_comissoes_equipe');

  const scopedCommissions = useMemo(() => {
    if (!profile) return [];
    if (canViewTeamCommissions) return commissions;
    return commissions.filter((c) => c.collaborator_id === profile.id);
  }, [commissions, profile, canViewTeamCommissions]);

  const handleNavigate = (page: AppPage) => {
    if (page !== 'configuracoes' && !hasPermission(page)) {
      showError('Acesso não autorizado', 'Seu perfil não possui permissão para este módulo.');
      return;
    }
    if (page === 'configuracoes') {
      setSettingsTab('perfil');
    }
    setActivePage(page);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#080D18] flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-9 h-9 border-2 border-[#2563EB] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-[#8FA3C4]">Inicializando VORTEX SYSTEM...</p>
        </div>
      </div>
    );
  }

  if (!configured || !session || !profile) {
    return <AuthScreen />;
  }

  if (profile.status === 'inativo') {
    return (
      <div className="min-h-screen bg-[#080D18] flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-[#111C30] border border-rose-500/30 rounded-lg p-6 text-center space-y-4">
          <ShieldAlert className="w-10 h-10 text-rose-400 mx-auto" />
          <h2 className="font-display text-lg font-semibold text-white">Acesso Desativado</h2>
          <p className="text-xs text-[#8FA3C4] leading-relaxed">
            Seu usuário está marcado como inativo no sistema. Entre em contato com o proprietário ou administrador para reativação.
          </p>
          <button
            type="button"
            onClick={() => void signOut()}
            className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md"
          >
            Encerrar sessão
          </button>
        </div>
      </div>
    );
  }

  const renderPage = () => {
    if (activePage !== 'configuracoes' && !hasPermission(activePage)) {
      return (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-8 text-center">
          <ShieldAlert className="w-8 h-8 text-amber-400 mx-auto mb-3" />
          <h3 className="font-display text-base font-semibold text-white">Módulo restrito</h3>
          <p className="text-xs text-[#8FA3C4] mt-1">
            Você não possui permissão atribuída para visualizar este módulo.
          </p>
        </div>
      );
    }

    switch (activePage) {
      case 'dashboard':
        return (
          <DashboardPage
            companies={companies}
            prospects={scopedProspects}
            commissions={scopedCommissions}
            payments={payments}
            expenses={expenses}
            tasks={tasks}
            interactions={scopedInteractions}
            activities={scopedActivities}
            proposals={scopedProposals}
            profiles={profiles}
            currentUser={profile}
            canViewTeamOverview={isManagerOrAbove || hasPermission('equipe')}
            canViewFinance={hasPermission('financeiro')}
            loading={dataLoading}
            onNavigate={handleNavigate}
          />
        );
      case 'prospeccao':
        return (
          <ProspectsPage
            prospects={scopedProspects}
            allProspectsForDedup={prospects}
            companies={companies}
            interactions={scopedInteractions}
            activities={scopedActivities}
            proposals={scopedProposals}
            assignmentsHistory={assignmentsHistory}
            profiles={profiles}
            currentUser={profile}
            canDistributeLeads={canDistributeLeads}
            defaultCommissionPct={settings.default_commission_pct}
            tableMissing={prospectsMissing}
            activitiesTableMissing={activitiesMissing}
            proposalsTableMissing={proposalsMissing}
            loading={dataLoading}
            onRefresh={loadAllData}
            onOpenSettingsSchema={() => {
              setSettingsTab('banco');
              setActivePage('configuracoes');
            }}
          />
        );
      case 'empresas':
        return (
          <CompaniesPage
            companies={companies}
            profiles={profiles}
            commissions={scopedCommissions}
            payments={payments}
            interactions={interactions}
            saleCollaborators={saleCollaborators}
            currentUser={profile}
            loading={dataLoading}
            onRefresh={loadAllData}
          />
        );
      case 'equipe':
        return (
          <TeamPage
            profiles={profiles}
            teamInvites={teamInvites}
            invitesTableMissing={invitesMissing}
            prospects={prospects}
            interactions={interactions}
            activities={activities}
            proposals={proposals}
            companies={companies}
            commissions={commissions}
            settings={settings}
            currentUser={profile}
            isAdminOrOwner={isAdminOrOwner}
            isManagerOrAbove={isManagerOrAbove}
            canViewTeamCommissions={canViewTeamCommissions}
            loading={dataLoading}
            onRefresh={loadAllData}
            onOpenSettingsSchema={() => {
              setSettingsTab('banco');
              setActivePage('configuracoes');
            }}
          />
        );
      case 'comissoes':
        return (
          <CommissionsPage
            commissions={scopedCommissions}
            profiles={profiles}
            companies={companies}
            prospects={scopedProspects}
            defaultCommissionPct={settings.default_commission_pct}
            canViewTeamCommissions={canViewTeamCommissions}
            loading={dataLoading}
            onRefresh={loadAllData}
          />
        );
      case 'financeiro':
        return (
          <FinancePage
            payments={payments}
            expenses={expenses}
            commissions={commissions}
            companies={companies}
            profiles={profiles}
            currentUser={profile}
            loading={dataLoading}
            onRefresh={loadAllData}
          />
        );
      case 'marketing':
        return (
          <MarketingTasksPage
            tasks={tasks}
            profiles={profiles}
            currentUser={profile}
            loading={dataLoading}
            onRefresh={loadAllData}
          />
        );
      case 'relatorios':
        return (
          <ReportsPage
            prospects={scopedProspects}
            companies={companies}
            commissions={scopedCommissions}
            payments={payments}
            expenses={expenses}
            profiles={profiles}
          />
        );
      case 'configuracoes':
        return (
          <SettingsPage
            key={settingsTab}
            currentUser={profile}
            settings={settings}
            onRefreshAll={loadAllData}
            onNavigate={handleNavigate}
            initialTab={settingsTab}
          />
        );
    }
  };

  return (
    <>
      {gmpQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}
      <AppShell
        activePage={activePage}
        onNavigate={handleNavigate}
        organizationName={settings.organization_name}
      >
        {renderPage()}
      </AppShell>
    </>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <VortexWorkspace />
      </AuthProvider>
    </ToastProvider>
  );
}
