import React, { useMemo, useState } from 'react';
import { Building2, Edit3, Eye, Plus, Search, Trash2 } from 'lucide-react';
import { COMPANY_STATUS_OPTIONS, SERVICE_TYPE_OPTIONS } from '../lib/constants';
import {
  formatCNPJ,
  formatCurrency,
  formatDate,
  formatDateTime,
  isValidEmail,
  toDateInputValue,
  todayISO,
} from '../lib/formatters';
import * as db from '../services/database';
import type {
  Commission,
  Company,
  CompanyStatus,
  Payment,
  ProspectInteraction,
  SaleCollaborator,
  ServiceType,
  UserProfile,
} from '../types';
import { useToast } from '../contexts/ToastContext';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { EmptyState, TableSkeleton } from '../components/ui/EmptyState';
import { Modal } from '../components/ui/Modal';
import { Pagination } from '../components/ui/Pagination';
import { StatusTag } from '../components/ui/StatusTag';

interface CompaniesPageProps {
  companies: Company[];
  profiles: UserProfile[];
  commissions: Commission[];
  payments: Payment[];
  interactions: ProspectInteraction[];
  saleCollaborators?: SaleCollaborator[];
  currentUser: UserProfile;
  loading: boolean;
  onRefresh: () => Promise<void>;
}

const EMPTY_COMPANY_FORM = {
  name: '',
  contact_name: '',
  phone: '',
  whatsapp: '',
  email: '',
  cnpj: '',
  city: '',
  segment: '',
  entry_date: todayISO(),
  contracted_service: 'presenca_digital' as ServiceType,
  contract_value: '',
  responsible_id: '',
  status: 'ativo' as CompanyStatus,
  origin: 'Cadastro direto',
  notes: '',
};

export function CompaniesPage({
  companies,
  profiles,
  commissions,
  payments,
  interactions,
  saleCollaborators = [],
  currentUser,
  loading,
  onRefresh,
}: CompaniesPageProps) {
  const { showSuccess, showError } = useToast();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [serviceFilter, setServiceFilter] = useState('todos');
  const [responsibleFilter, setResponsibleFilter] = useState('todos');
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Company | null>(null);
  const [formData, setFormData] = useState(EMPTY_COMPANY_FORM);
  const [saving, setSaving] = useState(false);

  const [detailCompany, setDetailCompany] = useState<Company | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Company | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return companies.filter((c) => {
      if (statusFilter !== 'todos' && c.status !== statusFilter) return false;
      if (serviceFilter !== 'todos' && c.contracted_service !== serviceFilter) return false;
      if (responsibleFilter !== 'todos' && c.responsible_id !== responsibleFilter) return false;
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        c.contact_name.toLowerCase().includes(q) ||
        c.cnpj.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q) ||
        c.segment.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q)
      );
    });
  }, [companies, search, statusFilter, serviceFilter, responsibleFilter]);

  const paginated = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page]);

  const totalPortfolioValue = useMemo(
    () =>
      filtered
        .filter((c) => c.status === 'ativo' || c.status === 'onboarding')
        .reduce((acc, c) => acc + c.contract_value, 0),
    [filtered]
  );

  const openCreate = () => {
    setEditing(null);
    setFormData({
      ...EMPTY_COMPANY_FORM,
      responsible_id: currentUser.id,
    });
    setFormOpen(true);
  };

  const openEdit = (c: Company) => {
    setEditing(c);
    setFormData({
      name: c.name,
      contact_name: c.contact_name,
      phone: c.phone,
      whatsapp: c.whatsapp,
      email: c.email,
      cnpj: c.cnpj,
      city: c.city,
      segment: c.segment,
      entry_date: toDateInputValue(c.entry_date) || todayISO(),
      contracted_service: c.contracted_service,
      contract_value: String(c.contract_value || ''),
      responsible_id: c.responsible_id || '',
      status: c.status,
      origin: c.origin || 'Cadastro direto',
      notes: c.notes,
    });
    setFormOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.contact_name.trim()) {
      showError('Campos obrigatórios', 'Informe o nome da empresa e do responsável.');
      return;
    }
    if (formData.email && !isValidEmail(formData.email)) {
      showError('E-mail inválido', 'Verifique o endereço de e-mail informado.');
      return;
    }

    const resp = profiles.find((u) => u.id === formData.responsible_id);
    const payload = {
      name: formData.name,
      contact_name: formData.contact_name,
      phone: formData.phone,
      whatsapp: formData.whatsapp,
      email: formData.email,
      cnpj: formData.cnpj,
      city: formData.city,
      segment: formData.segment,
      entry_date: formData.entry_date,
      contracted_service: formData.contracted_service,
      contract_value: Number(formData.contract_value) || 0,
      responsible_id: formData.responsible_id || null,
      responsible_name: resp?.full_name || currentUser.full_name,
      status: formData.status,
      origin: formData.origin,
      notes: formData.notes,
    };

    setSaving(true);
    try {
      if (editing) {
        const updated = await db.updateCompany(editing.id, payload);
        if (detailCompany?.id === updated.id) setDetailCompany(updated);
        showSuccess('Empresa atualizada', `${updated.name} foi salva.`);
      } else {
        await db.createCompany(payload);
        showSuccess('Empresa cadastrada', `${payload.name} foi adicionada à base de clientes.`);
      }
      setFormOpen(false);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar empresa', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await db.deleteCompany(deleteTarget.id);
      showSuccess('Empresa removida', `${deleteTarget.name} foi excluída.`);
      if (detailCompany?.id === deleteTarget.id) setDetailCompany(null);
      setDeleteTarget(null);
      await onRefresh();
    } catch (err) {
      showError('Erro ao excluir empresa', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setDeleting(false);
    }
  };

  const detailData = useMemo(() => {
    if (!detailCompany) return null;
    const clientPayments = payments.filter((p) => p.company_id === detailCompany.id);
    const clientCommissions = commissions.filter((c) => c.company_id === detailCompany.id);
    const clientInteractions = interactions.filter(
      (i) => i.company_id === detailCompany.id || (detailCompany.prospect_id && i.prospect_id === detailCompany.prospect_id)
    );
    const clientParticipants = saleCollaborators.filter(
      (sc) => sc.company_id === detailCompany.id || (detailCompany.prospect_id && sc.prospect_id === detailCompany.prospect_id)
    );
    return { clientPayments, clientCommissions, clientInteractions, clientParticipants };
  }, [detailCompany, payments, commissions, interactions, saleCollaborators]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">Empresas e Clientes</h2>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Carteira ativa: <span className="text-white font-mono tabular-nums">{formatCurrency(totalPortfolioValue)}</span> em contratos ativos/implantação
          </p>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Nova empresa
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5">
        <div className="relative">
          <Search className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Buscar empresa, CNPJ, responsável..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
        >
          <option value="todos">Todos os status</option>
          {COMPANY_STATUS_OPTIONS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>

        <select
          value={serviceFilter}
          onChange={(e) => {
            setServiceFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
        >
          <option value="todos">Todos os serviços</option>
          {SERVICE_TYPE_OPTIONS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>

        <select
          value={responsibleFilter}
          onChange={(e) => {
            setResponsibleFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
        >
          <option value="todos">Todos os responsáveis</option>
          {profiles.map((u) => (
            <option key={u.id} value={u.id}>{u.full_name}</option>
          ))}
        </select>
      </div>

      {/* Table */}
      {loading ? (
        <TableSkeleton rows={6} cols={6} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Building2 className="w-5 h-5" />}
          title="Nenhuma empresa encontrada"
          description="Cadastre um novo cliente ou converta um prospect no módulo de Prospecção."
          actionLabel="Cadastrar empresa"
          onAction={openCreate}
        />
      ) : (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                  <th className="py-3 px-4">Empresa / Responsável</th>
                  <th className="py-3 px-4">Serviço contratado</th>
                  <th className="py-3 px-4 text-right">Valor</th>
                  <th className="py-3 px-4">Entrada</th>
                  <th className="py-3 px-4">Comercial</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1C2B45] text-xs">
                {paginated.map((c) => {
                  const st = COMPANY_STATUS_OPTIONS.find((s) => s.value === c.status);
                  const srv = SERVICE_TYPE_OPTIONS.find((s) => s.value === c.contracted_service);
                  return (
                    <tr key={c.id} className="hover:bg-[#15223B]/60 transition-colors">
                      <td className="py-3 px-4">
                        <button
                          type="button"
                          onClick={() => setDetailCompany(c)}
                          className="text-left group"
                        >
                          <p className="font-medium text-white group-hover:text-[#3B82F6] transition-colors">
                            {c.name}
                          </p>
                          <p className="text-[#8FA3C4] mt-0.5">
                            {c.contact_name} {c.cnpj ? `· ${c.cnpj}` : ''}
                          </p>
                        </button>
                      </td>
                      <td className="py-3 px-4 text-slate-300">
                        <p>{srv?.label || c.contracted_service}</p>
                        <p className="text-[#7D92B5]">{c.segment || c.city || '—'}</p>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400 font-medium">
                        {formatCurrency(c.contract_value)}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-300">
                        {formatDate(c.entry_date)}
                      </td>
                      <td className="py-3 px-4 text-slate-300">{c.responsible_name || '—'}</td>
                      <td className="py-3 px-4">
                        <StatusTag
                          label={st?.label || c.status}
                          colorClass={st?.colorClass || 'text-slate-300 border-slate-600'}
                        />
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => setDetailCompany(c)}
                            title="Detalhes do cliente"
                            className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E]"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openEdit(c)}
                            title="Editar cliente"
                            className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E]"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(c)}
                            title="Excluir cliente"
                            className="p-1.5 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination
            currentPage={page}
            totalItems={filtered.length}
            pageSize={pageSize}
            onPageChange={setPage}
          />
        </div>
      )}

      {/* Create / Edit Modal */}
      <Modal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        title={editing ? 'Editar Empresa / Cliente' : 'Cadastrar Nova Empresa'}
        maxWidthClass="max-w-3xl"
      >
        <form onSubmit={handleSave} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label="Nome da empresa *" value={formData.name} onChange={(v) => setFormData({ ...formData, name: v })} required />
          <Input label="Responsável *" value={formData.contact_name} onChange={(v) => setFormData({ ...formData, contact_name: v })} required />
          <Input label="Telefone" value={formData.phone} onChange={(v) => setFormData({ ...formData, phone: v })} />
          <Input label="WhatsApp" value={formData.whatsapp} onChange={(v) => setFormData({ ...formData, whatsapp: v })} />
          <Input label="E-mail" type="email" value={formData.email} onChange={(v) => setFormData({ ...formData, email: v })} />
          <Input label="CNPJ (opcional)" value={formData.cnpj} onChange={(v) => setFormData({ ...formData, cnpj: formatCNPJ(v) })} placeholder="00.000.000/0000-00" />
          <Input label="Cidade" value={formData.city} onChange={(v) => setFormData({ ...formData, city: v })} />
          <Input label="Segmento" value={formData.segment} onChange={(v) => setFormData({ ...formData, segment: v })} />
          <Input label="Data de entrada" type="date" value={formData.entry_date} onChange={(v) => setFormData({ ...formData, entry_date: v })} required />
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Serviço contratado</label>
            <select
              value={formData.contracted_service}
              onChange={(e) => setFormData({ ...formData, contracted_service: e.target.value as ServiceType })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              {SERVICE_TYPE_OPTIONS.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>
          <Input label="Valor contratado (R$)" type="number" step="0.01" min="0" value={formData.contract_value} onChange={(v) => setFormData({ ...formData, contract_value: v })} />
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Responsável comercial</label>
            <select
              value={formData.responsible_id}
              onChange={(e) => setFormData({ ...formData, responsible_id: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              <option value="">Selecionar...</option>
              {profiles.map((u) => (
                <option key={u.id} value={u.id}>{u.full_name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Status</label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as CompanyStatus })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              {COMPANY_STATUS_OPTIONS.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>
          <Input label="Origem do cliente" value={formData.origin} onChange={(v) => setFormData({ ...formData, origin: v })} />
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-300 mb-1">Observações</label>
            <textarea
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>
          <div className="sm:col-span-2 flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
            <button type="button" onClick={() => setFormOpen(false)} className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50">
              {saving ? 'Salvando...' : editing ? 'Salvar alterações' : 'Cadastrar empresa'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Client Detail Modal */}
      <Modal
        open={Boolean(detailCompany)}
        onClose={() => setDetailCompany(null)}
        title={detailCompany?.name || ''}
        subtitle={detailCompany ? `${detailCompany.contact_name} · Origem: ${detailCompany.origin || 'Cadastro direto'}` : ''}
        maxWidthClass="max-w-3xl"
      >
        {detailCompany && detailData && (
          <div className="space-y-5 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pb-4 border-b border-[#1C2B45]">
              <div className="space-y-1">
                <p className="text-[#8FA3C4]">Contato</p>
                <p className="text-white">{detailCompany.whatsapp || detailCompany.phone || '—'}</p>
                <p className="text-slate-300">{detailCompany.email || 'Sem e-mail'}</p>
                <p className="text-[#7D92B5]">{detailCompany.city || '—'}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[#8FA3C4]">Contrato</p>
                <p className="text-white">{SERVICE_TYPE_OPTIONS.find((s) => s.value === detailCompany.contracted_service)?.label}</p>
                <p className="text-emerald-400 font-mono tabular-nums font-semibold">
                  {formatCurrency(detailCompany.contract_value)}
                </p>
                <p className="text-[#7D92B5] font-mono tabular-nums">Entrada: {formatDate(detailCompany.entry_date)}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[#8FA3C4]">Gestão</p>
                <p className="text-white">Comercial: {detailCompany.responsible_name || '—'}</p>
                <p className="text-slate-300">CNPJ: {detailCompany.cnpj || 'Não informado'}</p>
              </div>
            </div>

            {detailCompany.notes && (
              <div className="p-3 bg-[#0D1424] border border-[#1C2B45] rounded-md">
                <p className="font-medium text-slate-300 mb-1">Observações</p>
                <p className="text-[#8FA3C4] whitespace-pre-wrap">{detailCompany.notes}</p>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="border border-[#1C2B45] rounded-md p-3.5 bg-[#0D1424]">
                <p className="font-semibold text-white mb-2">Pagamentos vinculados ({detailData.clientPayments.length})</p>
                {detailData.clientPayments.length === 0 ? (
                  <p className="text-[#7D92B5]">Nenhum pagamento registrado para esta empresa.</p>
                ) : (
                  <div className="divide-y divide-[#1C2B45]">
                    {detailData.clientPayments.map((pay) => (
                      <div key={pay.id} className="py-2 flex items-center justify-between gap-2">
                        <span className="text-slate-200 truncate">{pay.description}</span>
                        <span className="font-mono tabular-nums text-emerald-400 shrink-0">{formatCurrency(pay.amount)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="border border-[#1C2B45] rounded-md p-3.5 bg-[#0D1424]">
                <p className="font-semibold text-white mb-2">Comissões vinculadas ({detailData.clientCommissions.length})</p>
                {detailData.clientCommissions.length === 0 ? (
                  <p className="text-[#7D92B5]">Nenhuma comissão vinculada.</p>
                ) : (
                  <div className="divide-y divide-[#1C2B45]">
                    {detailData.clientCommissions.map((com) => (
                      <div key={com.id} className="py-2 flex items-center justify-between gap-2">
                        <span className="text-slate-200 truncate">{com.collaborator_name}</span>
                        <span className="font-mono tabular-nums text-[#3B82F6] shrink-0">{formatCurrency(com.commission_value)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {detailData.clientParticipants.length > 0 && (
              <div className="border border-[#1C2B45] rounded-md p-3.5 bg-[#0D1424]">
                <p className="font-semibold text-white mb-2">
                  Equipe participante no fechamento ({detailData.clientParticipants.length})
                </p>
                <div className="flex flex-wrap gap-2">
                  {detailData.clientParticipants.map((part) => (
                    <span
                      key={part.id}
                      className="px-2.5 py-1 rounded bg-[#15223B] border border-[#24375A] text-slate-200"
                    >
                      {part.collaborator_name} · <span className="text-[#3B82F6]">{part.participation_role}</span>
                    </span>
                  ))}
                </div>
              </div>
            )}

            {detailData.clientInteractions.length > 0 && (
              <div className="border border-[#1C2B45] rounded-md p-3.5 bg-[#0D1424]">
                <p className="font-semibold text-white mb-2">
                  Histórico preservado da prospecção ({detailData.clientInteractions.length})
                </p>
                <div className="divide-y divide-[#1C2B45]">
                  {detailData.clientInteractions.map((inter) => (
                    <div key={inter.id} className="py-2 space-y-0.5">
                      <div className="flex justify-between text-[#8FA3C4]">
                        <span>{inter.responsible_name} · {inter.contact_type}</span>
                        <span className="font-mono tabular-nums">{formatDateTime(inter.contact_at)}</span>
                      </div>
                      <p className="text-slate-200">{inter.summary}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Excluir empresa"
        description={`Tem certeza que deseja excluir "${deleteTarget?.name}"?`}
        confirmLabel="Excluir empresa"
      />
    </div>
  );
}

function Input({
  label,
  value,
  onChange,
  type = 'text',
  required = false,
  placeholder,
  step,
  min,
}: {
  label: string;
  value: string;
  onChange: (val: string) => void;
  type?: string;
  required?: boolean;
  placeholder?: string;
  step?: string;
  min?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-300 mb-1">{label}</label>
      <input
        type={type}
        required={required}
        value={value}
        step={step}
        min={min}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
      />
    </div>
  );
}
