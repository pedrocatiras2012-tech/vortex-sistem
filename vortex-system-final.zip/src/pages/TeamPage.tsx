import React, { useMemo, useRef, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  BarChart3,
  CheckCircle2,
  Copy,
  Edit3,
  Eye,
  Link2,
  Plus,
  Search,
  Shield,
  ShieldCheck,
  Upload,
  UserCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import {
  DEFAULT_DEPARTMENTS,
  DEFAULT_JOB_ROLES,
  DEFAULT_PERMISSIONS_BY_ROLE,
  PERMISSION_LABELS,
  ROLE_LABELS,
} from '../lib/constants';
import { formatCurrency, formatDate, todayISO } from '../lib/formatters';
import * as db from '../services/database';
import type {
  CommercialProposal,
  Commission,
  Company,
  ModulePermissions,
  Prospect,
  ProspectActivity,
  ProspectInteraction,
  SystemSettings,
  TeamInvite,
  UserProfile,
  UserRole,
} from '../types';
import { useToast } from '../contexts/ToastContext';
import { EmptyState, TableSkeleton } from '../components/ui/EmptyState';
import { Modal } from '../components/ui/Modal';
import { StatusTag } from '../components/ui/StatusTag';

interface TeamPageProps {
  profiles: UserProfile[];
  teamInvites: TeamInvite[];
  invitesTableMissing: boolean;
  prospects: Prospect[];
  interactions: ProspectInteraction[];
  activities: ProspectActivity[];
  proposals: CommercialProposal[];
  companies: Company[];
  commissions: Commission[];
  settings: SystemSettings;
  currentUser: UserProfile;
  isAdminOrOwner: boolean;
  isManagerOrAbove: boolean;
  canViewTeamCommissions: boolean;
  loading: boolean;
  onRefresh: () => Promise<void>;
  onOpenSettingsSchema: () => void;
}

type PerfPeriod = '7d' | '30d' | '90d' | 'mes_atual' | 'todos';

function getPeriodStart(period: PerfPeriod): Date | null {
  if (period === 'todos') return null;
  const now = new Date();
  if (period === 'mes_atual') {
    return new Date(now.getFullYear(), now.getMonth(), 1);
  }
  const days = period === '7d' ? 7 : period === '30d' ? 30 : 90;
  const d = new Date(now);
  d.setDate(d.getDate() - days);
  return d;
}

function inPerfPeriod(dateStr: string | null | undefined, start: Date | null): boolean {
  if (!start) return true;
  if (!dateStr) return false;
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return false;
  return d >= start;
}

function getInitials(name: string): string {
  return (name || 'VS')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase())
    .join('');
}

export function TeamPage({
  profiles,
  teamInvites,
  invitesTableMissing,
  prospects,
  interactions,
  activities,
  proposals,
  companies,
  commissions,
  settings,
  currentUser,
  isAdminOrOwner,
  isManagerOrAbove,
  canViewTeamCommissions,
  loading,
  onRefresh,
  onOpenSettingsSchema,
}: TeamPageProps) {
  const { showSuccess, showError } = useToast();

  const [tab, setTab] = useState<'membros' | 'comparativo'>('membros');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'todos' | 'ativo' | 'inativo'>('todos');
  const [departmentFilter, setDepartmentFilter] = useState('todos');
  const [perfPeriod, setPerfPeriod] = useState<PerfPeriod>('30d');

  // Collaborator Profile Inspection Modal
  const [selectedMember, setSelectedMember] = useState<UserProfile | null>(null);
  const [memberPeriod, setMemberPeriod] = useState<PerfPeriod>('30d');

  // Create/Edit Collaborator Modal (either existing profile OR new pre-onboarding invite)
  const [collabModalOpen, setCollabModalOpen] = useState(false);
  const [editingProfileTarget, setEditingProfileTarget] = useState<UserProfile | null>(null);
  const [collabForm, setCollabForm] = useState({
    full_name: '',
    email: '',
    phone: '',
    job_title: 'Colaborador',
    department: 'Comercial & Vendas',
    responsibilities: '',
    entry_date: todayISO(),
    avatar_url: '',
    role: 'colaborador' as UserRole,
    status: 'ativo' as 'ativo' | 'inativo',
    linked_profile_id: '',
    permissions: { ...DEFAULT_PERMISSIONS_BY_ROLE.colaborador },
  });
  const [customRoleInput, setCustomRoleInput] = useState('');
  const [customDeptInput, setCustomDeptInput] = useState('');
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [savingCollab, setSavingCollab] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Access Control Modal
  const [editingAccessMember, setEditingAccessMember] = useState<UserProfile | null>(null);
  const [accessRole, setAccessRole] = useState<UserRole>('colaborador');
  const [accessJobTitle, setAccessJobTitle] = useState('');
  const [accessDepartment, setAccessDepartment] = useState('');
  const [accessStatus, setAccessStatus] = useState<'ativo' | 'inativo'>('ativo');
  const [accessPermissions, setAccessPermissions] = useState<ModulePermissions>(
    DEFAULT_PERMISSIONS_BY_ROLE.colaborador
  );
  const [savingAccess, setSavingAccess] = useState(false);

  const jobRoleOptions = useMemo(() => {
    const custom = settings.preferences?.customJobRoles || [];
    const fromProfiles = profiles.map((p) => p.job_title).filter(Boolean);
    return Array.from(new Set([...DEFAULT_JOB_ROLES, ...custom, ...fromProfiles]));
  }, [settings.preferences?.customJobRoles, profiles]);

  const departmentOptions = useMemo(() => {
    const custom = settings.preferences?.customDepartments || [];
    const fromProfiles = profiles.map((p) => p.department || '').filter(Boolean);
    return Array.from(new Set([...DEFAULT_DEPARTMENTS, ...custom, ...fromProfiles]));
  }, [settings.preferences?.customDepartments, profiles]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return profiles.filter((u) => {
      if (statusFilter !== 'todos' && u.status !== statusFilter) return false;
      if (departmentFilter !== 'todos' && (u.department || '') !== departmentFilter) return false;
      if (!q) return true;
      return (
        u.full_name.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.job_title.toLowerCase().includes(q) ||
        (u.department || '').toLowerCase().includes(q)
      );
    });
  }, [profiles, search, statusFilter, departmentFilter]);

  const pendingInvites = useMemo(
    () => teamInvites.filter((inv) => inv.status === 'pendente'),
    [teamInvites]
  );

  // Per-member metrics computed strictly from real DB records
  const computeMemberStats = (memberId: string, period: PerfPeriod) => {
    const start = getPeriodStart(period);

    const assignedLeads = prospects.filter(
      (p) =>
        p.responsible_id === memberId ||
        (p.participating_collaborators || []).some((pc) => pc.id === memberId)
    );
    const periodLeads = assignedLeads.filter((p) => inPerfPeriod(p.created_at, start));
    const periodContacts = interactions.filter(
      (i) => i.responsible_id === memberId && inPerfPeriod(i.contact_at, start)
    );
    const memberActivities = activities.filter((a) => a.responsible_id === memberId);
    const pendingActivities = memberActivities.filter((a) => a.status === 'pendente').length;
    const completedActivities = memberActivities.filter(
      (a) => a.status === 'concluida' && inPerfPeriod(a.completed_at || a.due_date, start)
    ).length;

    const inNegotiation = assignedLeads.filter(
      (p) =>
        p.status === 'em_negociacao' ||
        p.status === 'proposta_enviada' ||
        p.status === 'reuniao_agendada' ||
        p.status === 'interessado'
    ).length;

    const sentProposals = proposals.filter(
      (pr) => pr.responsible_id === memberId && inPerfPeriod(pr.sent_date || pr.created_at, start)
    ).length;

    const closedSalesLeads = assignedLeads.filter(
      (p) => p.status === 'convertido' && inPerfPeriod(p.closed_at || p.converted_at || p.created_at, start)
    );
    const lostLeads = assignedLeads.filter(
      (p) => (p.status === 'perdido' || p.status === 'sem_interesse') && inPerfPeriod(p.closed_at || p.updated_at || p.created_at, start)
    ).length;

    const soldCompanies = companies.filter(
      (c) => c.responsible_id === memberId && inPerfPeriod(c.entry_date || c.created_at, start)
    );
    // Avoid double-counting if company was converted from a closed prospect
    const companyIdsFromProspects = new Set(
      closedSalesLeads.map((p) => p.converted_company_id).filter(Boolean)
    );
    const extraCompanies = soldCompanies.filter((c) => !companyIdsFromProspects.has(c.id));

    const totalClosedCount = closedSalesLeads.length + extraCompanies.length;
    const totalSoldValue =
      closedSalesLeads.reduce((acc, p) => acc + (p.deal_value ?? p.estimated_value ?? 0), 0) +
      extraCompanies.reduce((acc, c) => acc + c.contract_value, 0);

    const memberComms = commissions.filter((c) => c.collaborator_id === memberId);
    const pendingComms = memberComms
      .filter((c) => c.status === 'prevista' || c.status === 'pendente' || c.status === 'aprovada')
      .reduce((acc, c) => acc + c.commission_value, 0);
    const paidComms = memberComms
      .filter((c) => c.status === 'paga' && inPerfPeriod(c.paid_at, start))
      .reduce((acc, c) => acc + c.commission_value, 0);

    return {
      assignedLeadsCount: assignedLeads.length,
      periodLeadsCount: periodLeads.length,
      contactsCount: periodContacts.length,
      pendingActivities,
      completedActivities,
      inNegotiation,
      sentProposals,
      totalClosedCount,
      lostLeads,
      totalSoldValue,
      pendingComms,
      paidComms,
    };
  };

  const memberMetricsMap = useMemo(() => {
    const map = new Map<string, ReturnType<typeof computeMemberStats>>();
    profiles.forEach((u) => {
      map.set(u.id, computeMemberStats(u.id, perfPeriod));
    });
    return map;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profiles, prospects, interactions, activities, proposals, companies, commissions, perfPeriod]);

  const comparisonChartData = useMemo(
    () =>
      profiles
        .filter((u) => u.status === 'ativo')
        .map((u) => {
          const st = memberMetricsMap.get(u.id);
          return {
            nome: u.full_name.split(' ')[0],
            contatos: st?.contactsCount || 0,
            propostas: st?.sentProposals || 0,
            vendas: st?.totalClosedCount || 0,
            valorVendido: st?.totalSoldValue || 0,
          };
        }),
    [profiles, memberMetricsMap]
  );

  // Selected Member Inspection Data & 6-Month Chart
  const inspectedMemberPerformance = useMemo(() => {
    if (!selectedMember) return null;
    const stats = computeMemberStats(selectedMember.id, memberPeriod);
    const assignedLeads = prospects.filter(
      (p) =>
        p.responsible_id === selectedMember.id ||
        (p.participating_collaborators || []).some((pc) => pc.id === selectedMember.id)
    );
    const memberActivities = activities
      .filter((a) => a.responsible_id === selectedMember.id)
      .slice(0, 10);
    const memberComms = commissions.filter((c) => c.collaborator_id === selectedMember.id);

    const now = new Date();
    const monthly: {
      key: string;
      label: string;
      contatos: number;
      atividades: number;
      propostas: number;
      vendas: number;
    }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = new Intl.DateTimeFormat('pt-BR', { month: 'short' }).format(d);
      monthly.push({ key, label, contatos: 0, atividades: 0, propostas: 0, vendas: 0 });
    }

    interactions
      .filter((i) => i.responsible_id === selectedMember.id)
      .forEach((i) => {
        const b = monthly.find((m) => m.key === i.contact_at.slice(0, 7));
        if (b) b.contatos += 1;
      });
    activities
      .filter((a) => a.responsible_id === selectedMember.id && a.status === 'concluida')
      .forEach((a) => {
        const b = monthly.find((m) => m.key === (a.completed_at || a.due_date).slice(0, 7));
        if (b) b.atividades += 1;
      });
    proposals
      .filter((pr) => pr.responsible_id === selectedMember.id)
      .forEach((pr) => {
        const b = monthly.find((m) => m.key === (pr.sent_date || pr.created_at).slice(0, 7));
        if (b) b.propostas += 1;
      });
    assignedLeads
      .filter((p) => p.status === 'convertido')
      .forEach((p) => {
        const b = monthly.find((m) => m.key === (p.closed_at || p.converted_at || p.created_at).slice(0, 7));
        if (b) b.vendas += 1;
      });

    return { stats, assignedLeads, memberActivities, memberComms, monthly };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMember, memberPeriod, prospects, interactions, activities, proposals, companies, commissions]);

  const openCreateCollaborator = () => {
    if (!isAdminOrOwner) {
      showError('Acesso restrito', 'Apenas Proprietário ou Administrador pode cadastrar colaboradores.');
      return;
    }
    setEditingProfileTarget(null);
    setCollabForm({
      full_name: '',
      email: '',
      phone: '',
      job_title: 'Consultor Comercial',
      department: 'Comercial & Vendas',
      responsibilities: '',
      entry_date: todayISO(),
      avatar_url: '',
      role: 'colaborador',
      status: 'ativo',
      linked_profile_id: '',
      permissions: { ...DEFAULT_PERMISSIONS_BY_ROLE.colaborador },
    });
    setCustomRoleInput('');
    setCustomDeptInput('');
    setCollabModalOpen(true);
  };

  const openEditCollaborator = (member: UserProfile) => {
    if (!isAdminOrOwner) {
      showError('Acesso restrito', 'Apenas Proprietário ou Administrador pode editar colaboradores.');
      return;
    }
    setEditingProfileTarget(member);
    setCollabForm({
      full_name: member.full_name,
      email: member.email,
      phone: member.phone || '',
      job_title: member.job_title,
      department: member.department || '',
      responsibilities: member.responsibilities || '',
      entry_date: member.entry_date || member.created_at.slice(0, 10),
      avatar_url: member.avatar_url || '',
      role: member.role,
      status: member.status,
      linked_profile_id: member.id,
      permissions: { ...member.permissions },
    });
    setCustomRoleInput('');
    setCustomDeptInput('');
    setCollabModalOpen(true);
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      showError('Imagem muito grande', 'Selecione uma imagem de até 3 MB.');
      return;
    }
    setUploadingAvatar(true);
    try {
      const url = await db.uploadCollaboratorAvatar(file, editingProfileTarget?.id || 'invites');
      setCollabForm((prev) => ({ ...prev, avatar_url: url }));
      showSuccess('Foto enviada', 'Avatar carregado com sucesso.');
    } catch (err) {
      showError('Falha no upload', err instanceof Error ? err.message : 'Informe uma URL manualmente se preferir.');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleAddCustomRole = async () => {
    const val = customRoleInput.trim();
    if (!val) return;
    const nextList = Array.from(new Set([...(settings.preferences.customJobRoles || []), val]));
    try {
      await db.saveSystemSettings({
        ...settings,
        preferences: { ...settings.preferences, customJobRoles: nextList },
      });
      setCollabForm((prev) => ({ ...prev, job_title: val }));
      setCustomRoleInput('');
      showSuccess('Cargo adicionado', `"${val}" salvo nos parâmetros do sistema.`);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar cargo', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  const handleAddCustomDepartment = async () => {
    const val = customDeptInput.trim();
    if (!val) return;
    const nextList = Array.from(new Set([...(settings.preferences.customDepartments || []), val]));
    try {
      await db.saveSystemSettings({
        ...settings,
        preferences: { ...settings.preferences, customDepartments: nextList },
      });
      setCollabForm((prev) => ({ ...prev, department: val }));
      setCustomDeptInput('');
      showSuccess('Área adicionada', `"${val}" salva nos parâmetros do sistema.`);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar área', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  const handleSaveCollaborator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdminOrOwner) return;
    if (!collabForm.full_name.trim() || !collabForm.email.trim()) {
      showError('Campos obrigatórios', 'Informe o nome completo e e-mail do colaborador.');
      return;
    }

    setSavingCollab(true);
    try {
      if (editingProfileTarget) {
        await db.updateCollaboratorProfile(currentUser, editingProfileTarget.id, {
          full_name: collabForm.full_name,
          email: collabForm.email,
          phone: collabForm.phone,
          job_title: collabForm.job_title,
          department: collabForm.department,
          responsibilities: collabForm.responsibilities,
          entry_date: collabForm.entry_date,
          avatar_url: collabForm.avatar_url || null,
          role: collabForm.role,
          permissions: collabForm.permissions,
          status: collabForm.status,
        });
        showSuccess('Colaborador atualizado', `${collabForm.full_name} salvo com sucesso.`);
      } else {
        await db.createTeamInvite(currentUser, {
          full_name: collabForm.full_name,
          email: collabForm.email,
          phone: collabForm.phone,
          role: collabForm.role,
          job_title: collabForm.job_title,
          department: collabForm.department,
          responsibilities: collabForm.responsibilities,
          entry_date: collabForm.entry_date,
          avatar_url: collabForm.avatar_url || null,
          permissions: collabForm.permissions,
          status: collabForm.linked_profile_id ? 'vinculado' : 'pendente',
          linked_profile_id: collabForm.linked_profile_id || null,
        });
        showSuccess(
          collabForm.linked_profile_id ? 'Conta vinculada' : 'Pré-cadastro salvo',
          collabForm.linked_profile_id
            ? `${collabForm.full_name} vinculado ao perfil selecionado.`
            : `Ao criar conta no login com ${collabForm.email}, este cargo e permissões serão aplicados automaticamente.`
        );
      }
      setCollabModalOpen(false);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar colaborador', err instanceof Error ? err.message : 'Verifique permissões e migração 004.');
    } finally {
      setSavingCollab(false);
    }
  };

  const openAccessModal = (member: UserProfile) => {
    if (!isAdminOrOwner) {
      showError('Acesso restrito', 'Apenas Proprietário ou Administrador pode gerenciar níveis e permissões.');
      return;
    }
    setEditingAccessMember(member);
    setAccessRole(member.role);
    setAccessJobTitle(member.job_title);
    setAccessDepartment(member.department || '');
    setAccessStatus(member.status);
    setAccessPermissions({ ...member.permissions });
  };

  const handleSaveAccess = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAccessMember || !isAdminOrOwner) return;
    setSavingAccess(true);
    try {
      await db.updateTeamMemberAccess(currentUser, editingAccessMember.id, {
        role: accessRole,
        permissions: accessPermissions,
        status: accessStatus,
        job_title: accessJobTitle,
        department: accessDepartment,
      });
      showSuccess('Permissões atualizadas', `Acesso de ${editingAccessMember.full_name} atualizado.`);
      setEditingAccessMember(null);
      await onRefresh();
    } catch (err) {
      showError('Erro ao atualizar equipe', err instanceof Error ? err.message : 'Verifique as políticas RLS.');
    } finally {
      setSavingAccess(false);
    }
  };

  const copySignupLink = async (email: string) => {
    try {
      await navigator.clipboard.writeText(window.location.origin);
      showSuccess('Link copiado', `Envie o endereço para ${email} realizar o cadastro com sua própria senha.`);
    } catch {
      showError('Não foi possível copiar o link');
    }
  };

  const activeCount = profiles.filter((u) => u.status === 'ativo').length;
  const inactiveCount = profiles.filter((u) => u.status === 'inativo').length;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">Gestão da Equipe</h2>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Colaboradores, cargos, áreas, permissões de acesso, vínculo de contas e desempenho comercial
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {isManagerOrAbove && (
            <div className="inline-flex items-center p-1 bg-[#0D1424] border border-[#1C2B45] rounded-md">
              <button
                type="button"
                onClick={() => setTab('membros')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                  tab === 'membros' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Colaboradores
              </button>
              <button
                type="button"
                onClick={() => setTab('comparativo')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                  tab === 'comparativo' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                Comparativo
              </button>
            </div>
          )}

          {isAdminOrOwner && (
            <button
              type="button"
              onClick={openCreateCollaborator}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors whitespace-nowrap shrink-0"
            >
              <UserPlus className="w-4 h-4" />
              Novo colaborador
            </button>
          )}
        </div>
      </div>

      {/* Summary Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Colaboradores ativos</p>
          <p className="text-xl font-mono font-bold tabular-nums text-emerald-400 mt-1">{activeCount}</p>
        </div>
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Inativos (histórico preservado)</p>
          <p className="text-xl font-mono font-bold tabular-nums text-slate-300 mt-1">{inactiveCount}</p>
        </div>
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Pré-cadastros pendentes</p>
          <p className="text-xl font-mono font-bold tabular-nums text-amber-300 mt-1">{pendingInvites.length}</p>
        </div>
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Total em vendas no período</p>
          <p className="text-xl font-mono font-bold tabular-nums text-white mt-1">
            {formatCurrency(
              Array.from(memberMetricsMap.values()).reduce((acc, m) => acc + m.totalSoldValue, 0)
            )}
          </p>
        </div>
      </div>

      {!isAdminOrOwner && (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5 text-xs text-[#8FA3C4] flex items-center gap-2.5">
          <Shield className="w-4 h-4 text-[#3B82F6] shrink-0" />
          <span>
            Modo de gestão/visualização: apenas <strong className="text-white">Proprietário</strong> ou <strong className="text-white">Administrador</strong> podem cadastrar colaboradores ou alterar permissões.
          </span>
        </div>
      )}

      {tab === 'comparativo' && isManagerOrAbove ? (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5">
            <span className="text-xs font-medium text-white">Comparativo de Desempenho da Equipe</span>
            <select
              value={perfPeriod}
              onChange={(e) => setPerfPeriod(e.target.value as PerfPeriod)}
              className="px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
            >
              <option value="7d">Últimos 7 dias</option>
              <option value="30d">Últimos 30 dias</option>
              <option value="90d">Últimos 90 dias</option>
              <option value="mes_atual">Mês atual</option>
              <option value="todos">Todo o período</option>
            </select>
          </div>

          <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5">
            <h3 className="font-display text-sm font-semibold text-white mb-4">
              Contatos, Propostas e Vendas por Colaborador
            </h3>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={comparisonChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1C2B45" vertical={false} />
                  <XAxis dataKey="nome" stroke="#7D92B5" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="#7D92B5" fontSize={11} allowDecimals={false} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0D1424',
                      borderColor: '#1C2B45',
                      borderRadius: '6px',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="contatos" name="Contatos" fill="#3B82F6" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="propostas" name="Propostas" fill="#818CF8" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="vendas" name="Vendas fechadas" fill="#10B981" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                    <th className="py-3 px-4">Colaborador</th>
                    <th className="py-3 px-4">Área</th>
                    <th className="py-3 px-4 text-right">Leads</th>
                    <th className="py-3 px-4 text-right">Contatos</th>
                    <th className="py-3 px-4 text-right">Ativ. concl.</th>
                    <th className="py-3 px-4 text-right">Propostas</th>
                    <th className="py-3 px-4 text-right">Vendas</th>
                    <th className="py-3 px-4 text-right">Total vendido</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1C2B45]">
                  {profiles.map((u) => {
                    const st = memberMetricsMap.get(u.id);
                    return (
                      <tr key={u.id} className="hover:bg-[#15223B]/60">
                        <td className="py-3 px-4 font-medium text-white">{u.full_name}</td>
                        <td className="py-3 px-4 text-[#8FA3C4]">{u.department || '—'}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">{st?.assignedLeadsCount ?? 0}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">{st?.contactsCount ?? 0}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">{st?.completedActivities ?? 0}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">{st?.sentProposals ?? 0}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400">{st?.totalClosedCount ?? 0}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400 font-semibold">
                          {formatCurrency(st?.totalSoldValue ?? 0)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5">
            <div className="relative">
              <Search className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar nome, cargo, e-mail ou área..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E]"
              />
            </div>

            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
            >
              <option value="todos">Todas as áreas</option>
              {departmentOptions.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
              className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
            >
              <option value="todos">Status: Todos</option>
              <option value="ativo">Somente ativos</option>
              <option value="inativo">Somente inativos</option>
            </select>

            <select
              value={perfPeriod}
              onChange={(e) => setPerfPeriod(e.target.value as PerfPeriod)}
              className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
            >
              <option value="7d">Métricas: 7 dias</option>
              <option value="30d">Métricas: 30 dias</option>
              <option value="90d">Métricas: 90 dias</option>
              <option value="mes_atual">Métricas: Mês atual</option>
              <option value="todos">Métricas: Todo período</option>
            </select>
          </div>

          {loading ? (
            <TableSkeleton rows={5} cols={7} />
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={<Users className="w-5 h-5" />}
              title="Nenhum colaborador encontrado"
              description="Ajuste os filtros ou cadastre um colaborador."
            />
          ) : (
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                      <th className="py-3 px-4">Colaborador</th>
                      <th className="py-3 px-4">Cargo / Área</th>
                      <th className="py-3 px-4">Nível de acesso</th>
                      <th className="py-3 px-4 text-right">Leads</th>
                      <th className="py-3 px-4 text-right">Vendas</th>
                      <th className="py-3 px-4">Entrada</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1C2B45] text-xs">
                    {filtered.map((member) => {
                      const m = memberMetricsMap.get(member.id);
                      const activePermsCount = Object.values(member.permissions).filter(Boolean).length;
                      return (
                        <tr key={member.id} className="hover:bg-[#15223B]/60 transition-colors">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              {member.avatar_url ? (
                                <img
                                  src={member.avatar_url}
                                  alt={member.full_name}
                                  className="w-9 h-9 rounded-md object-cover border border-[#24375A] shrink-0"
                                />
                              ) : (
                                <div className="w-9 h-9 rounded-md bg-[#2563EB]/20 border border-[#3B82F6]/30 flex items-center justify-center text-xs font-semibold text-[#3B82F6] shrink-0">
                                  {getInitials(member.full_name)}
                                </div>
                              )}
                              <div className="min-w-0">
                                <button
                                  type="button"
                                  onClick={() => setSelectedMember(member)}
                                  className="font-medium text-white hover:text-[#3B82F6] text-left truncate block"
                                >
                                  {member.full_name}
                                </button>
                                <p className="text-[#8FA3C4] truncate">
                                  {member.email || 'Sem e-mail'} {member.phone ? `· ${member.phone}` : ''}
                                </p>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <p className="text-slate-200">{member.job_title}</p>
                            <p className="text-[11px] text-[#7D92B5]">{member.department || 'Sem área definida'}</p>
                          </td>
                          <td className="py-3 px-4">
                            <p className="text-white font-medium">{ROLE_LABELS[member.role]}</p>
                            <p className="text-[11px] text-[#7D92B5]">{activePermsCount} permissões ativas</p>
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">
                            {m?.assignedLeadsCount ?? 0}
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400">
                            {formatCurrency(m?.totalSoldValue ?? 0)}
                          </td>
                          <td className="py-3 px-4 font-mono tabular-nums text-slate-300">
                            {formatDate(member.entry_date || member.created_at)}
                          </td>
                          <td className="py-3 px-4">
                            <StatusTag
                              label={member.status === 'ativo' ? 'Ativo' : 'Inativo'}
                              colorClass={
                                member.status === 'ativo'
                                  ? 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10'
                                  : 'text-rose-300 border-rose-500/30 bg-rose-500/10'
                              }
                            />
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => setSelectedMember(member)}
                                title="Perfil individual e painel de desempenho"
                                className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E]"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              {isAdminOrOwner && (
                                <>
                                  <button
                                    type="button"
                                    onClick={() => openEditCollaborator(member)}
                                    title="Editar ficha do colaborador"
                                    className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E]"
                                  >
                                    <Edit3 className="w-4 h-4" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => openAccessModal(member)}
                                    title="Gerenciar acesso e permissões"
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium text-[#3B82F6] hover:text-white hover:bg-[#2563EB] border border-[#24375A] transition-colors"
                                  >
                                    <ShieldCheck className="w-3.5 h-3.5" />
                                    Acesso
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Pending Pre-Onboarding / Team Invites */}
          {isAdminOrOwner && (pendingInvites.length > 0 || invitesTableMissing) && (
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs font-semibold text-white">
                    Pré-cadastros aguardando ativação pelo usuário (Supabase Auth)
                  </h3>
                  <p className="text-[11px] text-[#8FA3C4]">
                    Quando o colaborador criar sua conta na tela de login usando o mesmo e-mail, seu cargo, área e permissões serão aplicados automaticamente.
                  </p>
                </div>
                {invitesTableMissing && (
                  <button
                    type="button"
                    onClick={onOpenSettingsSchema}
                    className="text-xs text-[#3B82F6] hover:underline"
                  >
                    Aplicar migração 004
                  </button>
                )}
              </div>

              {pendingInvites.length > 0 && (
                <div className="divide-y divide-[#1C2B45] border border-[#1C2B45] rounded-md bg-[#0D1424]">
                  {pendingInvites.map((inv) => (
                    <div key={inv.id} className="p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div>
                        <p className="font-medium text-white">
                          {inv.full_name} · <span className="text-[#3B82F6]">{ROLE_LABELS[inv.role]}</span>
                        </p>
                        <p className="text-[#8FA3C4]">
                          {inv.email} · {inv.job_title} {inv.department ? `(${inv.department})` : ''}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => void copySignupLink(inv.email)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] text-slate-200 bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded"
                        >
                          <Copy className="w-3 h-3" />
                          Copiar link de cadastro
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Individual Collaborator Profile & Performance Panel Modal */}
      <Modal
        open={Boolean(selectedMember)}
        onClose={() => setSelectedMember(null)}
        title={selectedMember?.full_name || ''}
        subtitle={
          selectedMember
            ? `${selectedMember.job_title}${selectedMember.department ? ` · ${selectedMember.department}` : ''} · ${ROLE_LABELS[selectedMember.role]}`
            : ''
        }
        maxWidthClass="max-w-5xl"
      >
        {selectedMember && inspectedMemberPerformance && (
          <div className="space-y-5 text-xs">
            {/* Profile Header & Period Filter */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1C2B45]">
              <div className="flex items-center gap-3.5">
                {selectedMember.avatar_url ? (
                  <img
                    src={selectedMember.avatar_url}
                    alt={selectedMember.full_name}
                    className="w-12 h-12 rounded-md object-cover border border-[#24375A]"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-md bg-[#2563EB]/20 border border-[#3B82F6]/30 flex items-center justify-center text-sm font-semibold text-[#3B82F6]">
                    {getInitials(selectedMember.full_name)}
                  </div>
                )}
                <div className="space-y-0.5">
                  <p className="text-slate-200">{selectedMember.email || 'Sem e-mail'} {selectedMember.phone ? `· ${selectedMember.phone}` : ''}</p>
                  <p className="text-[#7D92B5]">
                    Entrada: {formatDate(selectedMember.entry_date || selectedMember.created_at)} · Status: {selectedMember.status === 'ativo' ? 'Ativo' : 'Inativo'}
                  </p>
                  {selectedMember.responsibilities && (
                    <p className="text-[#8FA3C4] max-w-xl">{selectedMember.responsibilities}</p>
                  )}
                </div>
              </div>

              <select
                value={memberPeriod}
                onChange={(e) => setMemberPeriod(e.target.value as PerfPeriod)}
                className="px-3 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
              >
                <option value="7d">Últimos 7 dias</option>
                <option value="30d">Últimos 30 dias</option>
                <option value="90d">Últimos 90 dias</option>
                <option value="mes_atual">Mês atual</option>
                <option value="todos">Todo o período</option>
              </select>
            </div>

            {/* Real Performance KPI Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <StatBox label="Leads atribuídos" value={String(inspectedMemberPerformance.stats.assignedLeadsCount)} />
              <StatBox label="Contatos registrados" value={String(inspectedMemberPerformance.stats.contactsCount)} />
              <StatBox
                label="Atividades (concl. / pend.)"
                value={`${inspectedMemberPerformance.stats.completedActivities} / ${inspectedMemberPerformance.stats.pendingActivities}`}
              />
              <StatBox label="Em negociação" value={String(inspectedMemberPerformance.stats.inNegotiation)} />
              <StatBox label="Propostas enviadas" value={String(inspectedMemberPerformance.stats.sentProposals)} />
              <StatBox
                label="Vendas fechadas / perdidas"
                value={`${inspectedMemberPerformance.stats.totalClosedCount} / ${inspectedMemberPerformance.stats.lostLeads}`}
              />
              <StatBox
                label="Valor vendido no período"
                value={formatCurrency(inspectedMemberPerformance.stats.totalSoldValue)}
                tone="text-emerald-400"
              />
              {(canViewTeamCommissions || selectedMember.id === currentUser.id) && (
                <StatBox
                  label="Comissões (pagas / pend.)"
                  value={formatCurrency(inspectedMemberPerformance.stats.paidComms)}
                  sub={`A receber: ${formatCurrency(inspectedMemberPerformance.stats.pendingComms)}`}
                  tone="text-[#3B82F6]"
                />
              )}
            </div>

            {/* 6-Month Evolution Chart */}
            <div className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-4">
              <p className="font-semibold text-white mb-3">Evolução Individual (Últimos 6 meses)</p>
              <div className="h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={inspectedMemberPerformance.monthly}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1C2B45" vertical={false} />
                    <XAxis dataKey="label" stroke="#7D92B5" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis stroke="#7D92B5" fontSize={11} allowDecimals={false} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#080D18',
                        borderColor: '#1C2B45',
                        borderRadius: '6px',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="contatos" name="Contatos" fill="#3B82F6" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="atividades" name="Atividades concluídas" fill="#06B6D4" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="propostas" name="Propostas" fill="#818CF8" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="vendas" name="Vendas fechadas" fill="#10B981" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Leads & Commissions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="border border-[#1C2B45] rounded-md p-3.5 bg-[#0D1424]">
                <p className="font-semibold text-white mb-2">
                  Carteira de leads ({inspectedMemberPerformance.assignedLeads.length})
                </p>
                {inspectedMemberPerformance.assignedLeads.length === 0 ? (
                  <p className="text-[#7D92B5]">Nenhum lead atribuído.</p>
                ) : (
                  <div className="divide-y divide-[#1C2B45] max-h-52 overflow-y-auto">
                    {inspectedMemberPerformance.assignedLeads.map((p) => (
                      <div key={p.id} className="py-2 flex items-center justify-between gap-2">
                        <span className="text-slate-200 truncate">{p.company_name}</span>
                        <span className="text-[#8FA3C4] shrink-0">{p.status}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {(canViewTeamCommissions || selectedMember.id === currentUser.id) && (
                <div className="border border-[#1C2B45] rounded-md p-3.5 bg-[#0D1424]">
                  <p className="font-semibold text-white mb-2">
                    Comissões registradas ({inspectedMemberPerformance.memberComms.length})
                  </p>
                  {inspectedMemberPerformance.memberComms.length === 0 ? (
                    <p className="text-[#7D92B5]">Nenhuma comissão registrada.</p>
                  ) : (
                    <div className="divide-y divide-[#1C2B45] max-h-52 overflow-y-auto">
                      {inspectedMemberPerformance.memberComms.map((c) => (
                        <div key={c.id} className="py-2 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-slate-200 truncate">{c.company_name || c.description}</p>
                            <p className="text-[11px] text-[#7D92B5]">{c.status}</p>
                          </div>
                          <span className="font-mono tabular-nums text-emerald-400 shrink-0">
                            {formatCurrency(c.commission_value)}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Create / Edit Collaborator Full Profile Modal */}
      <Modal
        open={collabModalOpen}
        onClose={() => setCollabModalOpen(false)}
        title={editingProfileTarget ? 'Editar Ficha do Colaborador' : 'Cadastrar / Pré-Registrar Colaborador'}
        subtitle={
          editingProfileTarget
            ? 'Atualize foto, função, área, responsabilidades e dados do membro preservando o histórico.'
            : 'Cadastre os dados do colaborador ou vincule a uma conta existente. Para novas contas, o usuário define a própria senha ao se cadastrar com o mesmo e-mail.'
        }
        maxWidthClass="max-w-3xl"
      >
        <form onSubmit={handleSaveCollaborator} className="space-y-4 text-xs">
          {/* Avatar Upload & Preview */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-3.5 rounded-md bg-[#0D1424] border border-[#1C2B45]">
            {collabForm.avatar_url ? (
              <img
                src={collabForm.avatar_url}
                alt="Avatar"
                className="w-14 h-14 rounded-md object-cover border border-[#24375A] shrink-0"
              />
            ) : (
              <div className="w-14 h-14 rounded-md bg-[#2563EB]/20 border border-[#3B82F6]/30 flex items-center justify-center text-sm font-semibold text-[#3B82F6] shrink-0">
                {getInitials(collabForm.full_name || 'VS')}
              </div>
            )}
            <div className="flex-1 space-y-2 w-full">
              <div className="flex flex-wrap items-center gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => void handleAvatarUpload(e)}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={uploadingAvatar}
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded"
                >
                  <Upload className="w-3.5 h-3.5" />
                  {uploadingAvatar ? 'Enviando foto...' : 'Enviar foto (Storage)'}
                </button>
                {collabForm.avatar_url && (
                  <button
                    type="button"
                    onClick={() => setCollabForm({ ...collabForm, avatar_url: '' })}
                    className="text-rose-400 hover:underline text-[11px]"
                  >
                    Remover foto
                  </button>
                )}
              </div>
              <input
                type="url"
                value={collabForm.avatar_url}
                onChange={(e) => setCollabForm({ ...collabForm, avatar_url: e.target.value })}
                placeholder="Ou cole a URL pública da foto (opcional)..."
                className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white placeholder:text-[#566C8E]"
              />
            </div>
          </div>

          {!editingProfileTarget && (
            <div className="p-3 rounded-md bg-[#0D1424] border border-[#1C2B45] space-y-1.5">
              <label className="block text-[11px] font-medium text-slate-300 flex items-center gap-1.5">
                <Link2 className="w-3.5 h-3.5 text-[#3B82F6]" />
                Vincular a usuário já autenticado (opcional)
              </label>
              <select
                value={collabForm.linked_profile_id}
                onChange={(e) => {
                  const id = e.target.value;
                  const existing = profiles.find((u) => u.id === id);
                  if (existing) {
                    setCollabForm((prev) => ({
                      ...prev,
                      linked_profile_id: id,
                      full_name: existing.full_name,
                      email: existing.email,
                    }));
                  } else {
                    setCollabForm((prev) => ({ ...prev, linked_profile_id: '' }));
                  }
                }}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                <option value="">Novo pré-cadastro (usuário fará cadastro com o e-mail abaixo)</option>
                {profiles.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.full_name} ({u.email})
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Nome completo *</label>
              <input
                type="text"
                required
                value={collabForm.full_name}
                onChange={(e) => setCollabForm({ ...collabForm, full_name: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">E-mail de acesso *</label>
              <input
                type="email"
                required
                value={collabForm.email}
                onChange={(e) => setCollabForm({ ...collabForm, email: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Telefone / WhatsApp</label>
              <input
                type="text"
                value={collabForm.phone}
                onChange={(e) => setCollabForm({ ...collabForm, phone: e.target.value })}
                placeholder="(11) 99999-9999"
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Data de entrada</label>
              <input
                type="date"
                value={collabForm.entry_date}
                onChange={(e) => setCollabForm({ ...collabForm, entry_date: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>

            {/* Job Title + Custom Role Creation */}
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-slate-300">Cargo / Função</label>
              <select
                value={collabForm.job_title}
                onChange={(e) => setCollabForm({ ...collabForm, job_title: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {jobRoleOptions.map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={customRoleInput}
                  onChange={(e) => setCustomRoleInput(e.target.value)}
                  placeholder="Criar cargo personalizado..."
                  className="flex-1 px-2.5 py-1 text-[11px] bg-[#080D18] border border-[#1C2B45] rounded text-white"
                />
                <button
                  type="button"
                  onClick={() => void handleAddCustomRole()}
                  className="px-2.5 py-1 text-[11px] bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded text-slate-200 inline-flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" /> Salvar
                </button>
              </div>
            </div>

            {/* Department + Custom Department Creation */}
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-slate-300">Área / Departamento</label>
              <select
                value={collabForm.department}
                onChange={(e) => setCollabForm({ ...collabForm, department: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                <option value="">Sem área definida</option>
                {departmentOptions.map((d) => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={customDeptInput}
                  onChange={(e) => setCustomDeptInput(e.target.value)}
                  placeholder="Criar área personalizada..."
                  className="flex-1 px-2.5 py-1 text-[11px] bg-[#080D18] border border-[#1C2B45] rounded text-white"
                />
                <button
                  type="button"
                  onClick={() => void handleAddCustomDepartment()}
                  className="px-2.5 py-1 text-[11px] bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded text-slate-200 inline-flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" /> Salvar
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Nível de acesso no sistema</label>
              <select
                value={collabForm.role}
                disabled={editingProfileTarget?.id === currentUser.id}
                onChange={(e) => {
                  const r = e.target.value as UserRole;
                  setCollabForm((prev) => ({
                    ...prev,
                    role: r,
                    permissions: { ...DEFAULT_PERMISSIONS_BY_ROLE[r] },
                  }));
                }}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white disabled:opacity-60"
              >
                {currentUser.role === 'proprietario' && (
                  <option value="proprietario">Proprietário (Acesso total)</option>
                )}
                <option value="administrador">Administrador</option>
                <option value="gerente">Gerente</option>
                <option value="colaborador">Colaborador</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Status</label>
              <select
                value={collabForm.status}
                disabled={editingProfileTarget?.id === currentUser.id}
                onChange={(e) => setCollabForm({ ...collabForm, status: e.target.value as 'ativo' | 'inativo' })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white disabled:opacity-60"
              >
                <option value="ativo">Ativo</option>
                <option value="inativo">Inativo (preserva histórico)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Responsabilidades / Descrição da função</label>
            <textarea
              rows={2}
              value={collabForm.responsibilities}
              onChange={(e) => setCollabForm({ ...collabForm, responsibilities: e.target.value })}
              placeholder="Principais entregas, metas ou carteira atendida..."
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>

          <div>
            <p className="text-xs font-medium text-slate-300 mb-2">Permissões iniciais (independentes do cargo)</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {(Object.keys(PERMISSION_LABELS) as (keyof ModulePermissions)[]).map((permKey) => {
                const checked = collabForm.role === 'proprietario' ? true : Boolean(collabForm.permissions[permKey]);
                return (
                  <label
                    key={permKey}
                    className="flex items-center gap-2 p-2 rounded-md bg-[#080D18] border border-[#1C2B45] text-[11px] text-slate-200 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      disabled={collabForm.role === 'proprietario'}
                      onChange={(e) =>
                        setCollabForm((prev) => ({
                          ...prev,
                          permissions: { ...prev.permissions, [permKey]: e.target.checked },
                        }))
                      }
                      className="rounded border-[#2C4166] bg-[#0D1424]"
                    />
                    <span>{PERMISSION_LABELS[permKey]}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
            <button
              type="button"
              onClick={() => setCollabModalOpen(false)}
              className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={savingCollab}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              {savingCollab ? 'Salvando...' : editingProfileTarget ? 'Salvar colaborador' : 'Salvar pré-cadastro'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Access Control & Granular Permissions Modal */}
      <Modal
        open={Boolean(editingAccessMember)}
        onClose={() => setEditingAccessMember(null)}
        title="Gerenciar Acesso e Permissões"
        subtitle={editingAccessMember ? `${editingAccessMember.full_name} (${editingAccessMember.email})` : ''}
        maxWidthClass="max-w-2xl"
      >
        {editingAccessMember && (
          <form onSubmit={handleSaveAccess} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Nível de acesso</label>
                <select
                  value={accessRole}
                  disabled={editingAccessMember.id === currentUser.id}
                  onChange={(e) => {
                    const r = e.target.value as UserRole;
                    setAccessRole(r);
                    setAccessPermissions({ ...DEFAULT_PERMISSIONS_BY_ROLE[r] });
                  }}
                  className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white disabled:opacity-60"
                >
                  {currentUser.role === 'proprietario' && (
                    <option value="proprietario">Proprietário (Acesso completo)</option>
                  )}
                  <option value="administrador">Administrador</option>
                  <option value="gerente">Gerente</option>
                  <option value="colaborador">Colaborador</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Status</label>
                <select
                  value={accessStatus}
                  disabled={editingAccessMember.id === currentUser.id}
                  onChange={(e) => setAccessStatus(e.target.value as 'ativo' | 'inativo')}
                  className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white disabled:opacity-60"
                >
                  <option value="ativo">Ativo</option>
                  <option value="inativo">Inativo</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Cargo / Função</label>
                <input
                  type="text"
                  value={accessJobTitle}
                  onChange={(e) => setAccessJobTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Área / Departamento</label>
                <select
                  value={accessDepartment}
                  onChange={(e) => setAccessDepartment(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
                >
                  <option value="">Sem área</option>
                  {departmentOptions.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <p className="text-xs font-medium text-slate-300 mb-2">Módulos e ações autorizadas</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(Object.keys(PERMISSION_LABELS) as (keyof ModulePermissions)[]).map((permKey) => {
                  const checked = accessRole === 'proprietario' ? true : Boolean(accessPermissions[permKey]);
                  return (
                    <label
                      key={permKey}
                      className="flex items-center gap-2.5 p-2.5 rounded-md bg-[#080D18] border border-[#1C2B45] text-xs text-slate-200 cursor-pointer hover:border-[#2C4166]"
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        disabled={accessRole === 'proprietario'}
                        onChange={(e) =>
                          setAccessPermissions({ ...accessPermissions, [permKey]: e.target.checked })
                        }
                        className="rounded border-[#2C4166] bg-[#0D1424] text-[#2563EB]"
                      />
                      <span>{PERMISSION_LABELS[permKey]}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
              <button
                type="button"
                onClick={() => setEditingAccessMember(null)}
                className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={savingAccess}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
              >
                <UserCheck className="w-3.5 h-3.5" />
                {savingAccess ? 'Salvando...' : 'Salvar permissões'}
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}

function StatBox({
  label,
  value,
  sub,
  tone = 'text-white',
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: string;
}) {
  return (
    <div className="p-3 rounded-md bg-[#0D1424] border border-[#1C2B45]">
      <p className="text-[11px] text-[#8FA3C4] truncate">{label}</p>
      <p className={`text-base font-mono font-bold tabular-nums mt-1 truncate ${tone}`}>{value}</p>
      {sub && <p className="text-[11px] text-[#7D92B5] font-mono tabular-nums mt-0.5 truncate">{sub}</p>}
    </div>
  );
}
