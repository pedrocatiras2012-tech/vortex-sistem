import { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Download } from 'lucide-react';
import { SERVICE_TYPE_OPTIONS } from '../lib/constants';
import { exportToCSV, formatCurrency, formatDate, formatPercent } from '../lib/formatters';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import type { Commission, Company, Expense, Payment, Prospect, UserProfile } from '../types';

interface ReportsPageProps {
  prospects: Prospect[];
  companies: Company[];
  commissions: Commission[];
  payments: Payment[];
  expenses: Expense[];
  profiles: UserProfile[];
}

export function ReportsPage({
  prospects,
  companies,
  commissions,
  payments,
  expenses,
  profiles,
}: ReportsPageProps) {
  const { hasPermission } = useAuth();
  const { showSuccess } = useToast();

  const [month, setMonth] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [collaboratorId, setCollaboratorId] = useState('todos');
  const [companyId, setCompanyId] = useState('todos');
  const [serviceFilter, setServiceFilter] = useState('todos');

  const canFinance = hasPermission('financeiro');
  const canCommissions = hasPermission('comissoes');
  const canProspects = hasPermission('prospeccao');
  const canCompanies = hasPermission('empresas');

  const matchDate = (dateStr: string | null | undefined) => {
    if (!dateStr) return false;
    const d = dateStr.slice(0, 10);
    if (month && !d.startsWith(month)) return false;
    if (startDate && d < startDate) return false;
    if (endDate && d > endDate) return false;
    return true;
  };

  const filteredData = useMemo(() => {
    const fProspects = prospects.filter((p) => {
      if (!matchDate(p.created_at)) return false;
      if (collaboratorId !== 'todos' && p.responsible_id !== collaboratorId) return false;
      return true;
    });

    const fCompanies = companies.filter((c) => {
      if (!matchDate(c.entry_date || c.created_at)) return false;
      if (collaboratorId !== 'todos' && c.responsible_id !== collaboratorId) return false;
      if (companyId !== 'todos' && c.id !== companyId) return false;
      if (serviceFilter !== 'todos' && c.contracted_service !== serviceFilter) return false;
      return true;
    });

    const fPayments = payments.filter((p) => {
      if (p.status !== 'recebido') return false;
      if (!matchDate(p.payment_date || p.created_at)) return false;
      if (companyId !== 'todos' && p.company_id !== companyId) return false;
      return true;
    });

    const fCommissions = commissions.filter((c) => {
      const refDate = c.status === 'paga' && c.paid_at ? c.paid_at : c.created_at;
      if (!matchDate(refDate)) return false;
      if (collaboratorId !== 'todos' && c.collaborator_id !== collaboratorId) return false;
      if (companyId !== 'todos' && c.company_id !== companyId) return false;
      return true;
    });

    const fExpenses = expenses.filter((e) => {
      if (!matchDate(e.expense_date || e.created_at)) return false;
      if (collaboratorId !== 'todos' && e.responsible_id !== collaboratorId) return false;
      return true;
    });

    const conversions = fProspects.filter((p) => p.status === 'convertido').length;
    const conversionRate = fProspects.length > 0 ? (conversions / fProspects.length) * 100 : 0;
    const salesTotal = fCompanies.reduce((a, c) => a + c.contract_value, 0);
    const revenueTotal = fPayments.reduce((a, p) => a + p.amount, 0);
    const commissionsPaid = fCommissions
      .filter((c) => c.status === 'paga')
      .reduce((a, c) => a + c.commission_value, 0);
    const commissionsPending = fCommissions
      .filter((c) => c.status === 'pendente' || c.status === 'aprovada')
      .reduce((a, c) => a + c.commission_value, 0);
    const expensesTotal = fExpenses.reduce((a, e) => a + e.amount, 0);

    return {
      fProspects,
      fCompanies,
      fPayments,
      fCommissions,
      fExpenses,
      conversions,
      conversionRate,
      salesTotal,
      revenueTotal,
      commissionsPaid,
      commissionsPending,
      expensesTotal,
    };
  }, [prospects, companies, payments, commissions, expenses, month, startDate, endDate, collaboratorId, companyId, serviceFilter]);

  const commercialEvolution = useMemo(() => {
    const map = new Map<string, { month: string; novosProspects: number; conversoes: number; contratos: number }>();
    filteredData.fProspects.forEach((p) => {
      const m = p.created_at.slice(0, 7);
      if (!map.has(m)) map.set(m, { month: m, novosProspects: 0, conversoes: 0, contratos: 0 });
      const b = map.get(m)!;
      b.novosProspects += 1;
      if (p.status === 'convertido') b.conversoes += 1;
    });
    filteredData.fCompanies.forEach((c) => {
      const m = (c.entry_date || c.created_at).slice(0, 7);
      if (!map.has(m)) map.set(m, { month: m, novosProspects: 0, conversoes: 0, contratos: 0 });
      map.get(m)!.contratos += 1;
    });
    return Array.from(map.values()).sort((a, b) => a.month.localeCompare(b.month));
  }, [filteredData]);

  const handleExportSummary = () => {
    const headers = ['Indicador', 'Valor'];
    const rows: (string | number)[][] = [];
    if (canProspects) {
      rows.push(['Novos Prospects', filteredData.fProspects.length]);
      rows.push(['Conversões', filteredData.conversions]);
      rows.push(['Taxa de Conversão', formatPercent(filteredData.conversionRate)]);
    }
    if (canCompanies) {
      rows.push(['Empresas / Vendas Registradas', filteredData.fCompanies.length]);
      rows.push(['Valor em Contratos', formatCurrency(filteredData.salesTotal)]);
    }
    if (canCommissions) {
      rows.push(['Comissões Pagas', formatCurrency(filteredData.commissionsPaid)]);
      rows.push(['Comissões Pendentes/Aprovadas', formatCurrency(filteredData.commissionsPending)]);
    }
    if (canFinance) {
      rows.push(['Receitas Recebidas', formatCurrency(filteredData.revenueTotal)]);
      rows.push(['Despesas Registradas', formatCurrency(filteredData.expensesTotal)]);
    }
    exportToCSV('vortex-relatorio-resumo', headers, rows);
    showSuccess('CSV exportado', 'Resumo gerencial exportado com dados autorizados.');
  };

  const handleExportProspects = () => {
    exportToCSV(
      'vortex-prospects',
      ['Empresa', 'Responsável', 'Telefone', 'WhatsApp', 'Cidade', 'Segmento', 'Origem', 'Responsável Comercial', 'Status', 'Criado em'],
      filteredData.fProspects.map((p) => [
        p.company_name,
        p.contact_name,
        p.phone,
        p.whatsapp,
        p.city,
        p.segment,
        p.origin,
        p.responsible_name,
        p.status,
        formatDate(p.created_at),
      ])
    );
    showSuccess('CSV exportado', 'Lista de prospects exportada.');
  };

  const handleExportCommissions = () => {
    exportToCSV(
      'vortex-comissoes',
      ['Colaborador', 'Empresa', 'Descrição', 'Valor Venda', '%', 'Valor Comissão', 'Status', 'Criação', 'Pagamento Efetivo'],
      filteredData.fCommissions.map((c) => [
        c.collaborator_name,
        c.company_name,
        c.description,
        c.sale_value.toFixed(2),
        c.commission_percentage.toFixed(1),
        c.commission_value.toFixed(2),
        c.status,
        formatDate(c.created_at),
        c.paid_at ? formatDate(c.paid_at) : 'Não paga',
      ])
    );
    showSuccess('CSV exportado', 'Relatório de comissões exportado.');
  };

  const handleExportFinance = () => {
    const rows: (string | number)[][] = [
      ...filteredData.fPayments.map((p) => ['Receita', p.description, p.company_name, p.category, formatDate(p.payment_date), p.amount.toFixed(2)]),
      ...filteredData.fExpenses.map((e) => ['Despesa', e.description, e.responsible_name, e.category, formatDate(e.expense_date), (-e.amount).toFixed(2)]),
    ];
    exportToCSV('vortex-financeiro', ['Tipo', 'Descrição', 'Empresa / Responsável', 'Categoria', 'Data', 'Valor'], rows);
    showSuccess('CSV exportado', 'Movimentações financeiras exportadas.');
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">Relatórios Gerenciais</h2>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Análises consolidadas com filtros combinados e exportação CSV respeitando permissões
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportSummary}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            Exportar Resumo CSV
          </button>
          {canProspects && (
            <button
              type="button"
              onClick={handleExportProspects}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-200 bg-[#111C30] hover:bg-[#192844] border border-[#1C2B45] rounded-md whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Prospects CSV
            </button>
          )}
          {canCommissions && (
            <button
              type="button"
              onClick={handleExportCommissions}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-200 bg-[#111C30] hover:bg-[#192844] border border-[#1C2B45] rounded-md whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Comissões CSV
            </button>
          )}
          {canFinance && (
            <button
              type="button"
              onClick={handleExportFinance}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-200 bg-[#111C30] hover:bg-[#192844] border border-[#1C2B45] rounded-md whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Financeiro CSV
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5">
        <div>
          <label className="block text-[11px] text-[#8FA3C4] mb-1">Mês</label>
          <input
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
          />
        </div>
        <div>
          <label className="block text-[11px] text-[#8FA3C4] mb-1">De</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
          />
        </div>
        <div>
          <label className="block text-[11px] text-[#8FA3C4] mb-1">Até</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
          />
        </div>
        <div>
          <label className="block text-[11px] text-[#8FA3C4] mb-1">Colaborador</label>
          <select
            value={collaboratorId}
            onChange={(e) => setCollaboratorId(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
          >
            <option value="todos">Todos</option>
            {profiles.map((u) => (
              <option key={u.id} value={u.id}>{u.full_name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-[11px] text-[#8FA3C4] mb-1">Empresa</label>
          <select
            value={companyId}
            onChange={(e) => setCompanyId(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
          >
            <option value="todos">Todas</option>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-[11px] text-[#8FA3C4] mb-1">Serviço</label>
          <select
            value={serviceFilter}
            onChange={(e) => setServiceFilter(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
          >
            <option value="todos">Todos</option>
            {SERVICE_TYPE_OPTIONS.map((s) => (
              <option key={s.value} value={s.value}>{s.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Report Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-4">
        <ReportStat label="Novos prospects" value={String(filteredData.fProspects.length)} />
        <ReportStat label="Conversões" value={String(filteredData.conversions)} />
        <ReportStat label="Taxa de conversão" value={formatPercent(filteredData.conversionRate)} />
        <ReportStat label="Vendas (contratos)" value={formatCurrency(filteredData.salesTotal)} />
        {canCommissions && (
          <ReportStat
            label="Comissões pagas"
            value={formatCurrency(filteredData.commissionsPaid)}
            sub={`Pend.: ${formatCurrency(filteredData.commissionsPending)}`}
          />
        )}
        {canFinance && (
          <ReportStat
            label="Despesas"
            value={formatCurrency(filteredData.expensesTotal)}
            sub={`Receitas: ${formatCurrency(filteredData.revenueTotal)}`}
          />
        )}
      </div>

      {/* Commercial Evolution Chart */}
      <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5">
        <div className="mb-4">
          <h3 className="font-display text-sm font-semibold text-white">Evolução Comercial</h3>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Novos prospects captados, conversões e novos contratos por competência
          </p>
        </div>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={commercialEvolution}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1C2B45" vertical={false} />
              <XAxis dataKey="month" stroke="#7D92B5" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#7D92B5" fontSize={11} allowDecimals={false} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0D1424',
                  borderColor: '#1C2B45',
                  borderRadius: '6px',
                  fontSize: '12px',
                }}
              />
              <Bar dataKey="novosProspects" name="Novos prospects" fill="#3B82F6" radius={[3, 3, 0, 0]} />
              <Bar dataKey="conversoes" name="Conversões" fill="#10B981" radius={[3, 3, 0, 0]} />
              <Bar dataKey="contratos" name="Novas empresas" fill="#818CF8" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function ReportStat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
      <p className="text-[11px] text-[#8FA3C4] truncate">{label}</p>
      <p className="text-lg font-mono font-bold tabular-nums text-white mt-1 truncate">{value}</p>
      {sub && <p className="text-[11px] text-[#7D92B5] font-mono tabular-nums mt-0.5 truncate">{sub}</p>}
    </div>
  );
}
