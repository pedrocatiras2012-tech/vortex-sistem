import React, { useMemo, useState } from 'react';
import { Edit3, Percent, Plus, Search, Trash2 } from 'lucide-react';
import { COMMISSION_STATUS_OPTIONS, SALE_PARTICIPATION_ROLE_OPTIONS } from '../lib/constants';
import { formatCurrency, formatDate, formatPercent, toDateInputValue, todayISO } from '../lib/formatters';
import * as db from '../services/database';
import type {
  Commission,
  CommissionStatus,
  Company,
  Prospect,
  SaleParticipationRole,
  UserProfile,
} from '../types';
import { useToast } from '../contexts/ToastContext';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { EmptyState, TableSkeleton } from '../components/ui/EmptyState';
import { Modal } from '../components/ui/Modal';
import { Pagination } from '../components/ui/Pagination';
import { StatusTag } from '../components/ui/StatusTag';

interface CommissionsPageProps {
  commissions: Commission[];
  profiles: UserProfile[];
  companies: Company[];
  prospects: Prospect[];
  defaultCommissionPct: number;
  canViewTeamCommissions?: boolean;
  loading: boolean;
  onRefresh: () => Promise<void>;
}

export function CommissionsPage({
  commissions,
  profiles,
  companies,
  prospects,
  defaultCommissionPct,
  canViewTeamCommissions = true,
  loading,
  onRefresh,
}: CommissionsPageProps) {
  const { showSuccess, showError } = useToast();

  const [search, setSearch] = useState('');
  const [collaboratorFilter, setCollaboratorFilter] = useState('todos');
  const [companyFilter, setCompanyFilter] = useState('todos');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Commission | null>(null);
  const [form, setForm] = useState({
    collaborator_id: '',
    company_id: '',
    prospect_id: '',
    participation_role: 'fechamento' as SaleParticipationRole | '',
    description: '',
    sale_value: '',
    commission_percentage: String(defaultCommissionPct || 10),
    status: 'pendente' as CommissionStatus,
    paid_at: '',
  });
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<Commission | null>(null);
  const [deleting, setDeleting] = useState(false);

  const calculatedPreview = useMemo(() => {
    const sale = Number(form.sale_value) || 0;
    const pct = Number(form.commission_percentage) || 0;
    return Number(((sale * pct) / 100).toFixed(2));
  }, [form.sale_value, form.commission_percentage]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return commissions.filter((c) => {
      if (collaboratorFilter !== 'todos' && c.collaborator_id !== collaboratorFilter) return false;
      if (companyFilter !== 'todos' && c.company_id !== companyFilter) return false;
      if (statusFilter !== 'todos' && c.status !== statusFilter) return false;

      const refDate = c.created_at.slice(0, 10);
      if (startDate && refDate < startDate) return false;
      if (endDate && refDate > endDate) return false;

      if (!q) return true;
      return (
        c.description.toLowerCase().includes(q) ||
        c.collaborator_name.toLowerCase().includes(q) ||
        c.company_name.toLowerCase().includes(q)
      );
    });
  }, [commissions, search, collaboratorFilter, companyFilter, statusFilter, startDate, endDate]);

  const totals = useMemo(() => {
    const prevista = filtered.filter((c) => c.status === 'prevista').reduce((a, c) => a + c.commission_value, 0);
    const pendente = filtered.filter((c) => c.status === 'pendente').reduce((a, c) => a + c.commission_value, 0);
    const aprovada = filtered.filter((c) => c.status === 'aprovada').reduce((a, c) => a + c.commission_value, 0);
    const paga = filtered.filter((c) => c.status === 'paga').reduce((a, c) => a + c.commission_value, 0);
    return { prevista, pendente, aprovada, paga };
  }, [filtered]);

  const paginated = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page]);

  const openCreate = () => {
    setEditing(null);
    setForm({
      collaborator_id: profiles[0]?.id || '',
      company_id: '',
      prospect_id: '',
      participation_role: 'fechamento',
      description: '',
      sale_value: '',
      commission_percentage: String(defaultCommissionPct || 10),
      status: 'pendente',
      paid_at: '',
    });
    setFormOpen(true);
  };

  const openEdit = (c: Commission) => {
    setEditing(c);
    setForm({
      collaborator_id: c.collaborator_id || '',
      company_id: c.company_id || '',
      prospect_id: c.prospect_id || '',
      participation_role: c.participation_role || '',
      description: c.description,
      sale_value: String(c.sale_value),
      commission_percentage: String(c.commission_percentage),
      status: c.status,
      paid_at: c.paid_at ? toDateInputValue(c.paid_at) : '',
    });
    setFormOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.collaborator_id) {
      showError('Colaborador obrigatório', 'Selecione o colaborador beneficiado pela comissão.');
      return;
    }
    if (!form.description.trim()) {
      showError('Descrição obrigatória', 'Descreva o contrato ou venda referente à comissão.');
      return;
    }
    if (form.status === 'paga' && !form.paid_at) {
      showError('Data de pagamento obrigatória', 'Informe a data efetiva em que a comissão foi paga.');
      return;
    }

    const collab = profiles.find((u) => u.id === form.collaborator_id);
    const comp = companies.find((co) => co.id === form.company_id);

    setSaving(true);
    try {
      const payload = {
        collaborator_id: form.collaborator_id,
        collaborator_name: collab?.full_name || 'Colaborador',
        company_id: form.company_id || null,
        company_name: comp?.name || '',
        prospect_id: form.prospect_id || null,
        participation_role: form.participation_role,
        description: form.description,
        sale_value: Number(form.sale_value) || 0,
        commission_percentage: Number(form.commission_percentage) || 0,
        status: form.status,
        paid_at: form.status === 'paga' ? form.paid_at : null,
      };

      if (editing) {
        await db.updateCommission(editing.id, payload);
        showSuccess('Comissão atualizada', 'Registro salvo com cálculo atualizado.');
      } else {
        await db.createCommission(payload);
        showSuccess('Comissão registrada', `Valor calculado: ${formatCurrency(calculatedPreview)}.`);
      }
      setFormOpen(false);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar comissão', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await db.deleteCommission(deleteTarget.id);
      showSuccess('Comissão excluída', 'O lançamento foi removido.');
      setDeleteTarget(null);
      await onRefresh();
    } catch (err) {
      showError('Erro ao excluir', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">Controle de Comissões</h2>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Cálculo automático sobre vendas e controle rigoroso da data efetiva de pagamento
          </p>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Nova comissão
        </button>
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Previstas (vendas em curso)</p>
          <p className="text-xl font-mono font-bold tabular-nums text-cyan-400 mt-1">
            {formatCurrency(totals.prevista)}
          </p>
        </div>
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Pendentes (aguardando aprovação)</p>
          <p className="text-xl font-mono font-bold tabular-nums text-amber-400 mt-1">
            {formatCurrency(totals.pendente)}
          </p>
        </div>
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Aprovadas (a pagar)</p>
          <p className="text-xl font-mono font-bold tabular-nums text-[#3B82F6] mt-1">
            {formatCurrency(totals.aprovada)}
          </p>
        </div>
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Pagas (efetivadas)</p>
          <p className="text-xl font-mono font-bold tabular-nums text-emerald-400 mt-1">
            {formatCurrency(totals.paga)}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5">
        <div className="relative lg:col-span-2">
          <Search className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Buscar descrição, colaborador ou empresa..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E]"
          />
        </div>

        {canViewTeamCommissions && (
          <select
            value={collaboratorFilter}
            onChange={(e) => {
              setCollaboratorFilter(e.target.value);
              setPage(1);
            }}
            className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
          >
            <option value="todos">Todos colaboradores</option>
            {profiles.map((u) => (
              <option key={u.id} value={u.id}>{u.full_name}</option>
            ))}
          </select>
        )}

        <select
          value={companyFilter}
          onChange={(e) => {
            setCompanyFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
        >
          <option value="todos">Todas empresas</option>
          {companies.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>

        <select
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
        >
          <option value="todos">Todos os status</option>
          {COMMISSION_STATUS_OPTIONS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>

        <div className="flex items-center gap-1.5">
          <input
            type="date"
            aria-label="Data inicial"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-1/2 px-2 py-2 text-[11px] bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
          />
          <input
            type="date"
            aria-label="Data final"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-1/2 px-2 py-2 text-[11px] bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
          />
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <TableSkeleton rows={6} cols={7} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Percent className="w-5 h-5" />}
          title="Nenhuma comissão registrada"
          description="Registre comissões vinculadas a vendas e acompanhe aprovação e pagamento efetivo."
          actionLabel="Registrar comissão"
          onAction={openCreate}
        />
      ) : (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                  <th className="py-3 px-4">Colaborador / Descrição</th>
                  <th className="py-3 px-4">Empresa</th>
                  <th className="py-3 px-4 text-right">Venda</th>
                  <th className="py-3 px-4 text-right">%</th>
                  <th className="py-3 px-4 text-right">Comissão</th>
                  <th className="py-3 px-4">Criação</th>
                  <th className="py-3 px-4">Pgto. Efetivo</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1C2B45] text-xs">
                {paginated.map((c) => {
                  const st = COMMISSION_STATUS_OPTIONS.find((s) => s.value === c.status);
                  return (
                    <tr key={c.id} className="hover:bg-[#15223B]/60 transition-colors">
                      <td className="py-3 px-4">
                        <p className="font-medium text-white">
                          {c.collaborator_name || '—'}
                          {c.participation_role && (
                            <span className="ml-1.5 text-[11px] font-normal text-[#3B82F6]">
                              ({c.participation_role})
                            </span>
                          )}
                        </p>
                        <p className="text-[#8FA3C4] truncate max-w-[220px]">{c.description}</p>
                      </td>
                      <td className="py-3 px-4 text-slate-300">{c.company_name || '—'}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-300">
                        {formatCurrency(c.sale_value)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-300">
                        {formatPercent(c.commission_percentage)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-white font-semibold">
                        {formatCurrency(c.commission_value)}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-[#8FA3C4]">
                        {formatDate(c.created_at)}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-200">
                        {c.paid_at ? formatDate(c.paid_at) : 'Não paga'}
                      </td>
                      <td className="py-3 px-4">
                        <StatusTag
                          label={st?.label || c.status}
                          colorClass={st?.colorClass || 'text-slate-300 border-slate-600'}
                        />
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openEdit(c)}
                            title="Editar comissão"
                            className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E]"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(c)}
                            title="Excluir comissão"
                            className="p-1.5 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination
            currentPage={page}
            totalItems={filtered.length}
            pageSize={pageSize}
            onPageChange={setPage}
          />
        </div>
      )}

      {/* Commission Form Modal */}
      <Modal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        title={editing ? 'Editar Comissão' : 'Nova Comissão'}
        subtitle="O valor da comissão é calculado automaticamente a partir do valor da venda e percentual"
        maxWidthClass="max-w-2xl"
      >
        <form onSubmit={handleSave} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Colaborador *</label>
            <select
              required
              value={form.collaborator_id}
              onChange={(e) => setForm({ ...form, collaborator_id: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              <option value="">Selecionar colaborador...</option>
              {profiles.map((u) => (
                <option key={u.id} value={u.id}>{u.full_name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Empresa relacionada</label>
            <select
              value={form.company_id}
              onChange={(e) => {
                const compId = e.target.value;
                const comp = companies.find((c) => c.id === compId);
                setForm({
                  ...form,
                  company_id: compId,
                  sale_value: !form.sale_value && comp?.contract_value ? String(comp.contract_value) : form.sale_value,
                });
              }}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              <option value="">Sem empresa vinculada</option>
              {companies.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Prospect relacionado (opcional)</label>
            <select
              value={form.prospect_id}
              onChange={(e) => setForm({ ...form, prospect_id: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              <option value="">Nenhum prospect</option>
              {prospects.map((p) => (
                <option key={p.id} value={p.id}>{p.company_name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Papel na venda (opcional)</label>
            <select
              value={form.participation_role}
              onChange={(e) => setForm({ ...form, participation_role: e.target.value as SaleParticipationRole | '' })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              <option value="">Não especificado</option>
              {SALE_PARTICIPATION_ROLE_OPTIONS.map((r) => (
                <option key={r.value} value={r.value}>{r.label}</option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-300 mb-1">Descrição *</label>
            <input
              type="text"
              required
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Ex: Fechamento plano Presença Digital"
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Valor da venda (R$) *</label>
            <input
              type="number"
              step="0.01"
              min="0"
              required
              value={form.sale_value}
              onChange={(e) => setForm({ ...form, sale_value: e.target.value })}
              placeholder="1000.00"
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white font-mono tabular-nums"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Percentual (%) *</label>
            <input
              type="number"
              step="0.1"
              min="0"
              max="100"
              required
              value={form.commission_percentage}
              onChange={(e) => setForm({ ...form, commission_percentage: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white font-mono tabular-nums"
            />
          </div>

          <div className="sm:col-span-2 p-3.5 rounded-md bg-[#0D1424] border border-[#1C2B45] flex items-center justify-between">
            <span className="text-xs text-[#8FA3C4]">Valor calculado da comissão</span>
            <span className="text-lg font-mono font-bold tabular-nums text-emerald-400">
              {formatCurrency(calculatedPreview)}
            </span>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Status</label>
            <select
              value={form.status}
              onChange={(e) => {
                const st = e.target.value as CommissionStatus;
                setForm({
                  ...form,
                  status: st,
                  paid_at: st === 'paga' ? (form.paid_at || todayISO()) : '',
                });
              }}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              {COMMISSION_STATUS_OPTIONS.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Data efetiva do pagamento {form.status === 'paga' ? '*' : '(apenas quando paga)'}
            </label>
            <input
              type="date"
              disabled={form.status !== 'paga'}
              required={form.status === 'paga'}
              value={form.paid_at}
              onChange={(e) => setForm({ ...form, paid_at: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white disabled:opacity-40"
            />
          </div>

          <div className="sm:col-span-2 flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
            <button
              type="button"
              onClick={() => setFormOpen(false)}
              className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
            >
              {saving ? 'Salvando...' : editing ? 'Salvar comissão' : 'Registrar comissão'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Excluir comissão"
        description={`Confirmar exclusão da comissão "${deleteTarget?.description}"?`}
        confirmLabel="Excluir"
      />
    </div>
  );
}
