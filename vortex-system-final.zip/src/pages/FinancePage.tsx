import React, { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowDownCircle, ArrowUpCircle, Edit3, Plus, Search, Trash2, Wallet } from 'lucide-react';
import { EXPENSE_CATEGORIES, PAYMENT_CATEGORIES } from '../lib/constants';
import { formatCurrency, formatDate, toDateInputValue, todayISO } from '../lib/formatters';
import * as db from '../services/database';
import type { Commission, Company, Expense, Payment, UserProfile } from '../types';
import { useToast } from '../contexts/ToastContext';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { EmptyState, TableSkeleton } from '../components/ui/EmptyState';
import { Modal } from '../components/ui/Modal';
import { Pagination } from '../components/ui/Pagination';
import { StatusTag } from '../components/ui/StatusTag';

interface FinancePageProps {
  payments: Payment[];
  expenses: Expense[];
  commissions: Commission[];
  companies: Company[];
  profiles: UserProfile[];
  currentUser: UserProfile;
  loading: boolean;
  onRefresh: () => Promise<void>;
}

type FinanceTab = 'receitas' | 'despesas' | 'mensal';

export function FinancePage({
  payments,
  expenses,
  commissions,
  companies,
  profiles,
  currentUser,
  loading,
  onRefresh,
}: FinancePageProps) {
  const { showSuccess, showError } = useToast();

  const [tab, setTab] = useState<FinanceTab>('receitas');
  const [search, setSearch] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('todos');
  const [page, setPage] = useState(1);
  const pageSize = 10;

  // Payment Modal
  const [payModalOpen, setPayModalOpen] = useState(false);
  const [editingPay, setEditingPay] = useState<Payment | null>(null);
  const [payForm, setPayForm] = useState({
    description: '',
    company_id: '',
    amount: '',
    payment_date: todayISO(),
    category: PAYMENT_CATEGORIES[0],
    status: 'recebido' as Payment['status'],
    notes: '',
  });
  const [savingPay, setSavingPay] = useState(false);

  // Expense Modal
  const [expModalOpen, setExpModalOpen] = useState(false);
  const [editingExp, setEditingExp] = useState<Expense | null>(null);
  const [expForm, setExpForm] = useState({
    description: '',
    category: EXPENSE_CATEGORIES[0],
    amount: '',
    expense_date: todayISO(),
    responsible_id: currentUser.id,
    notes: '',
  });
  const [savingExp, setSavingExp] = useState(false);

  // Delete confirm
  const [deleteInfo, setDeleteInfo] = useState<{ type: 'payment' | 'expense'; id: string; label: string } | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Totals (strictly separating received payments vs pending commissions)
  const summary = useMemo(() => {
    const receivedPayments = payments.filter((p) => {
      if (p.status !== 'recebido') return false;
      if (monthFilter && !(p.payment_date || '').startsWith(monthFilter)) return false;
      return true;
    });
    const pendingPayments = payments.filter((p) => {
      if (p.status !== 'pendente') return false;
      if (monthFilter && !(p.payment_date || '').startsWith(monthFilter)) return false;
      return true;
    });
    const filteredExpenses = expenses.filter((e) => {
      if (monthFilter && !(e.expense_date || '').startsWith(monthFilter)) return false;
      return true;
    });

    const totalRecebido = receivedPayments.reduce((a, p) => a + p.amount, 0);
    const totalAReceber = pendingPayments.reduce((a, p) => a + p.amount, 0);
    const totalDespesas = filteredExpenses.reduce((a, e) => a + e.amount, 0);
    const saldo = totalRecebido - totalDespesas;

    // Commissions shown separately so pending commissions are never mixed with realized cashflow
    const comissoesPagas = commissions
      .filter((c) => c.status === 'paga' && (!monthFilter || (c.paid_at || '').startsWith(monthFilter)))
      .reduce((a, c) => a + c.commission_value, 0);
    const comissoesPendentes = commissions
      .filter((c) => c.status === 'pendente' || c.status === 'aprovada')
      .reduce((a, c) => a + c.commission_value, 0);

    return { totalRecebido, totalAReceber, totalDespesas, saldo, comissoesPagas, comissoesPendentes };
  }, [payments, expenses, commissions, monthFilter]);

  const filteredPayments = useMemo(() => {
    const q = search.trim().toLowerCase();
    return payments.filter((p) => {
      if (monthFilter && !(p.payment_date || '').startsWith(monthFilter)) return false;
      if (categoryFilter !== 'todos' && p.category !== categoryFilter) return false;
      if (!q) return true;
      return p.description.toLowerCase().includes(q) || p.company_name.toLowerCase().includes(q);
    });
  }, [payments, search, monthFilter, categoryFilter]);

  const filteredExpenses = useMemo(() => {
    const q = search.trim().toLowerCase();
    return expenses.filter((e) => {
      if (monthFilter && !(e.expense_date || '').startsWith(monthFilter)) return false;
      if (categoryFilter !== 'todos' && e.category !== categoryFilter) return false;
      if (!q) return true;
      return (
        e.description.toLowerCase().includes(q) ||
        e.category.toLowerCase().includes(q) ||
        e.responsible_name.toLowerCase().includes(q)
      );
    });
  }, [expenses, search, monthFilter, categoryFilter]);

  const monthlyReport = useMemo(() => {
    const map = new Map<string, { month: string; label: string; receitas: number; despesas: number; saldo: number }>();

    payments.forEach((p) => {
      if (p.status !== 'recebido') return;
      const m = (p.payment_date || p.created_at).slice(0, 7);
      if (!m) return;
      if (!map.has(m)) {
        map.set(m, { month: m, label: m, receitas: 0, despesas: 0, saldo: 0 });
      }
      map.get(m)!.receitas += p.amount;
    });

    expenses.forEach((e) => {
      const m = (e.expense_date || e.created_at).slice(0, 7);
      if (!m) return;
      if (!map.has(m)) {
        map.set(m, { month: m, label: m, receitas: 0, despesas: 0, saldo: 0 });
      }
      map.get(m)!.despesas += e.amount;
    });

    const rows = Array.from(map.values()).sort((a, b) => a.month.localeCompare(b.month));
    rows.forEach((r) => {
      r.saldo = r.receitas - r.despesas;
    });
    return rows;
  }, [payments, expenses]);

  const openCreatePayment = () => {
    setEditingPay(null);
    setPayForm({
      description: '',
      company_id: '',
      amount: '',
      payment_date: todayISO(),
      category: PAYMENT_CATEGORIES[0],
      status: 'recebido',
      notes: '',
    });
    setPayModalOpen(true);
  };

  const openEditPayment = (p: Payment) => {
    setEditingPay(p);
    setPayForm({
      description: p.description,
      company_id: p.company_id || '',
      amount: String(p.amount),
      payment_date: toDateInputValue(p.payment_date) || todayISO(),
      category: p.category || PAYMENT_CATEGORIES[0],
      status: p.status,
      notes: p.notes || '',
    });
    setPayModalOpen(true);
  };

  const handleSavePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payForm.description.trim() || Number(payForm.amount) <= 0) {
      showError('Dados inválidos', 'Informe descrição e valor maior que zero.');
      return;
    }
    const comp = companies.find((c) => c.id === payForm.company_id);
    setSavingPay(true);
    try {
      const payload = {
        description: payForm.description,
        company_id: payForm.company_id || null,
        company_name: comp?.name || '',
        amount: Number(payForm.amount),
        payment_date: payForm.payment_date,
        category: payForm.category,
        status: payForm.status,
        notes: payForm.notes,
      };
      if (editingPay) {
        await db.updatePayment(editingPay.id, payload);
        showSuccess('Receita atualizada', 'Lançamento financeiro salvo.');
      } else {
        await db.createPayment(payload);
        showSuccess('Receita registrada', 'Entrada adicionada ao financeiro.');
      }
      setPayModalOpen(false);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar receita', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSavingPay(false);
    }
  };

  const openCreateExpense = () => {
    setEditingExp(null);
    setExpForm({
      description: '',
      category: EXPENSE_CATEGORIES[0],
      amount: '',
      expense_date: todayISO(),
      responsible_id: currentUser.id,
      notes: '',
    });
    setExpModalOpen(true);
  };

  const openEditExpense = (e: Expense) => {
    setEditingExp(e);
    setExpForm({
      description: e.description,
      category: e.category || EXPENSE_CATEGORIES[0],
      amount: String(e.amount),
      expense_date: toDateInputValue(e.expense_date) || todayISO(),
      responsible_id: e.responsible_id || currentUser.id,
      notes: e.notes,
    });
    setExpModalOpen(true);
  };

  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!expForm.description.trim() || Number(expForm.amount) <= 0) {
      showError('Dados inválidos', 'Informe descrição e valor maior que zero.');
      return;
    }
    const resp = profiles.find((u) => u.id === expForm.responsible_id);
    setSavingExp(true);
    try {
      const payload = {
        description: expForm.description,
        category: expForm.category,
        amount: Number(expForm.amount),
        expense_date: expForm.expense_date,
        responsible_id: expForm.responsible_id || null,
        responsible_name: resp?.full_name || currentUser.full_name,
        notes: expForm.notes,
      };
      if (editingExp) {
        await db.updateExpense(editingExp.id, payload);
        showSuccess('Despesa atualizada', 'Lançamento atualizado.');
      } else {
        await db.createExpense(payload);
        showSuccess('Despesa registrada', 'Saída registrada no financeiro.');
      }
      setExpModalOpen(false);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar despesa', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSavingExp(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteInfo) return;
    setDeleting(true);
    try {
      if (deleteInfo.type === 'payment') {
        await db.deletePayment(deleteInfo.id);
      } else {
        await db.deleteExpense(deleteInfo.id);
      }
      showSuccess('Registro excluído', `${deleteInfo.label} foi removido.`);
      setDeleteInfo(null);
      await onRefresh();
    } catch (err) {
      showError('Erro ao excluir', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setDeleting(false);
    }
  };

  const activeList = tab === 'receitas' ? filteredPayments : filteredExpenses;
  const paginatedPayments = filteredPayments.slice((page - 1) * pageSize, page * pageSize);
  const paginatedExpenses = filteredExpenses.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="space-y-5">
      {/* Header & Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">Controle Financeiro</h2>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Receitas realizadas, despesas operacionais, saldo líquido e separação de comissões
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={openCreatePayment}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            Nova receita
          </button>
          <button
            type="button"
            onClick={openCreateExpense}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-200 bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            Nova despesa
          </button>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-[#8FA3C4]">
            <span>Receitas recebidas</span>
            <ArrowUpCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-xl font-mono font-bold tabular-nums text-emerald-400 mt-1.5">
            {formatCurrency(summary.totalRecebido)}
          </p>
          <p className="text-[11px] text-[#7D92B5] mt-1 font-mono tabular-nums">
            A receber: {formatCurrency(summary.totalAReceber)}
          </p>
        </div>

        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-[#8FA3C4]">
            <span>Despesas registradas</span>
            <ArrowDownCircle className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-xl font-mono font-bold tabular-nums text-rose-400 mt-1.5">
            {formatCurrency(summary.totalDespesas)}
          </p>
          <p className="text-[11px] text-[#7D92B5] mt-1">Saídas lançadas no período</p>
        </div>

        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-[#8FA3C4]">
            <span>Saldo calculado</span>
            <Wallet className="w-4 h-4 text-[#3B82F6]" />
          </div>
          <p
            className={`text-xl font-mono font-bold tabular-nums mt-1.5 ${
              summary.saldo >= 0 ? 'text-white' : 'text-rose-400'
            }`}
          >
            {formatCurrency(summary.saldo)}
          </p>
          <p className="text-[11px] text-[#7D92B5] mt-1">Receitas recebidas − Despesas</p>
        </div>

        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-4">
          <p className="text-xs text-[#8FA3C4]">Comissões (controle separado)</p>
          <p className="text-sm font-mono tabular-nums text-emerald-400 mt-1.5">
            Pagas: {formatCurrency(summary.comissoesPagas)}
          </p>
          <p className="text-xs font-mono tabular-nums text-amber-400 mt-0.5">
            Pendentes: {formatCurrency(summary.comissoesPendentes)}
          </p>
        </div>
      </div>

      {/* Tabs + Filters */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5">
        <div className="inline-flex items-center p-1 bg-[#080D18] border border-[#1C2B45] rounded-md self-start">
          <button
            type="button"
            onClick={() => {
              setTab('receitas');
              setCategoryFilter('todos');
              setPage(1);
            }}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              tab === 'receitas' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
            }`}
          >
            Receitas ({filteredPayments.length})
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('despesas');
              setCategoryFilter('todos');
              setPage(1);
            }}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              tab === 'despesas' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
            }`}
          >
            Despesas ({filteredExpenses.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('mensal')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              tab === 'mensal' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
            }`}
          >
            Relatório Mensal
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {tab !== 'mensal' && (
            <>
              <div className="relative">
                <Search className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value);
                    setPage(1);
                  }}
                  placeholder="Buscar lançamento..."
                  className="pl-9 pr-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E]"
                />
              </div>

              <select
                value={categoryFilter}
                onChange={(e) => {
                  setCategoryFilter(e.target.value);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
              >
                <option value="todos">Todas categorias</option>
                {(tab === 'receitas' ? PAYMENT_CATEGORIES : EXPENSE_CATEGORIES).map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </>
          )}

          <input
            type="month"
            aria-label="Filtrar por mês"
            value={monthFilter}
            onChange={(e) => {
              setMonthFilter(e.target.value);
              setPage(1);
            }}
            className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
          />
          {monthFilter && (
            <button
              type="button"
              onClick={() => setMonthFilter('')}
              className="text-xs text-[#3B82F6] hover:text-blue-400"
            >
              Limpar mês
            </button>
          )}
        </div>
      </div>

      {/* Tab Content */}
      {loading ? (
        <TableSkeleton rows={6} cols={5} />
      ) : tab === 'mensal' ? (
        <div className="space-y-4">
          <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5">
            <h3 className="font-display text-sm font-semibold text-white mb-4">
              Comparativo Mensal (Receitas Recebidas vs. Despesas)
            </h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyReport}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1C2B45" vertical={false} />
                  <XAxis dataKey="label" stroke="#7D92B5" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="#7D92B5" fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0D1424',
                      borderColor: '#1C2B45',
                      borderRadius: '6px',
                      fontSize: '12px',
                    }}
                    formatter={(val) => formatCurrency(Number(val))}
                  />
                  <Bar dataKey="receitas" name="Receitas" fill="#10B981" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="despesas" name="Despesas" fill="#F43F5E" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                  <th className="py-3 px-4">Competência</th>
                  <th className="py-3 px-4 text-right">Receitas Recebidas</th>
                  <th className="py-3 px-4 text-right">Despesas</th>
                  <th className="py-3 px-4 text-right">Saldo do Mês</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1C2B45] text-xs">
                {monthlyReport.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-[#8FA3C4]">
                      Sem lançamentos financeiros registrados.
                    </td>
                  </tr>
                ) : (
                  monthlyReport.map((r) => (
                    <tr key={r.month}>
                      <td className="py-3 px-4 font-mono text-white">{r.month}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400">
                        {formatCurrency(r.receitas)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-rose-400">
                        {formatCurrency(r.despesas)}
                      </td>
                      <td
                        className={`py-3 px-4 text-right font-mono tabular-nums font-semibold ${
                          r.saldo >= 0 ? 'text-white' : 'text-rose-400'
                        }`}
                      >
                        {formatCurrency(r.saldo)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : activeList.length === 0 ? (
        <EmptyState
          icon={<Wallet className="w-5 h-5" />}
          title={tab === 'receitas' ? 'Nenhuma receita registrada' : 'Nenhuma despesa registrada'}
          description="Adicione lançamentos reais para acompanhar o saldo e os relatórios mensais."
          actionLabel={tab === 'receitas' ? 'Registrar receita' : 'Registrar despesa'}
          onAction={tab === 'receitas' ? openCreatePayment : openCreateExpense}
        />
      ) : tab === 'receitas' ? (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                  <th className="py-3 px-4">Descrição</th>
                  <th className="py-3 px-4">Empresa</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4">Data</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Valor</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1C2B45] text-xs">
                {paginatedPayments.map((p) => (
                  <tr key={p.id} className="hover:bg-[#15223B]/60">
                    <td className="py-3 px-4 font-medium text-white">{p.description}</td>
                    <td className="py-3 px-4 text-slate-300">{p.company_name || '—'}</td>
                    <td className="py-3 px-4 text-[#8FA3C4]">{p.category}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-300">
                      {formatDate(p.payment_date)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusTag
                        label={p.status === 'recebido' ? 'Recebido' : p.status === 'pendente' ? 'Pendente' : 'Cancelado'}
                        colorClass={
                          p.status === 'recebido'
                            ? 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10'
                            : p.status === 'pendente'
                            ? 'text-amber-300 border-amber-500/30 bg-amber-500/10'
                            : 'text-rose-300 border-rose-500/30 bg-rose-500/10'
                        }
                      />
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400 font-semibold">
                      {formatCurrency(p.amount)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEditPayment(p)}
                          className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E]"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteInfo({ type: 'payment', id: p.id, label: p.description })}
                          className="p-1.5 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination
            currentPage={page}
            totalItems={filteredPayments.length}
            pageSize={pageSize}
            onPageChange={setPage}
          />
        </div>
      ) : (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                  <th className="py-3 px-4">Descrição</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4">Responsável</th>
                  <th className="py-3 px-4">Data</th>
                  <th className="py-3 px-4 text-right">Valor</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1C2B45] text-xs">
                {paginatedExpenses.map((e) => (
                  <tr key={e.id} className="hover:bg-[#15223B]/60">
                    <td className="py-3 px-4">
                      <p className="font-medium text-white">{e.description}</p>
                      {e.notes && <p className="text-[11px] text-[#7D92B5] truncate max-w-xs">{e.notes}</p>}
                    </td>
                    <td className="py-3 px-4 text-[#8FA3C4]">{e.category}</td>
                    <td className="py-3 px-4 text-slate-300">{e.responsible_name || '—'}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-300">
                      {formatDate(e.expense_date)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-rose-400 font-semibold">
                      {formatCurrency(e.amount)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEditExpense(e)}
                          className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E]"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteInfo({ type: 'expense', id: e.id, label: e.description })}
                          className="p-1.5 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination
            currentPage={page}
            totalItems={filteredExpenses.length}
            pageSize={pageSize}
            onPageChange={setPage}
          />
        </div>
      )}

      {/* Payment Modal */}
      <Modal
        open={payModalOpen}
        onClose={() => setPayModalOpen(false)}
        title={editingPay ? 'Editar Receita' : 'Registrar Receita'}
        maxWidthClass="max-w-lg"
      >
        <form onSubmit={handleSavePayment} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Descrição *</label>
            <input
              type="text"
              required
              value={payForm.description}
              onChange={(e) => setPayForm({ ...payForm, description: e.target.value })}
              placeholder="Ex: Mensalidade Gestão de Redes"
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Empresa</label>
              <select
                value={payForm.company_id}
                onChange={(e) => setPayForm({ ...payForm, company_id: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                <option value="">Sem vínculo</option>
                {companies.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Categoria</label>
              <select
                value={payForm.category}
                onChange={(e) => setPayForm({ ...payForm, category: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {PAYMENT_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Valor (R$) *</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                value={payForm.amount}
                onChange={(e) => setPayForm({ ...payForm, amount: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white font-mono tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Data *</label>
              <input
                type="date"
                required
                value={payForm.payment_date}
                onChange={(e) => setPayForm({ ...payForm, payment_date: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Status</label>
            <select
              value={payForm.status}
              onChange={(e) => setPayForm({ ...payForm, status: e.target.value as Payment['status'] })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              <option value="recebido">Recebido</option>
              <option value="pendente">Pendente</option>
              <option value="cancelado">Cancelado</option>
            </select>
          </div>
          <div className="flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
            <button type="button" onClick={() => setPayModalOpen(false)} className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md">
              Cancelar
            </button>
            <button type="submit" disabled={savingPay} className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50">
              {savingPay ? 'Salvando...' : 'Salvar receita'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Expense Modal */}
      <Modal
        open={expModalOpen}
        onClose={() => setExpModalOpen(false)}
        title={editingExp ? 'Editar Despesa' : 'Registrar Despesa'}
        maxWidthClass="max-w-lg"
      >
        <form onSubmit={handleSaveExpense} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Descrição *</label>
            <input
              type="text"
              required
              value={expForm.description}
              onChange={(e) => setExpForm({ ...expForm, description: e.target.value })}
              placeholder="Ex: Assinatura ferramentas cloud"
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Categoria</label>
              <select
                value={expForm.category}
                onChange={(e) => setExpForm({ ...expForm, category: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {EXPENSE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Responsável</label>
              <select
                value={expForm.responsible_id}
                onChange={(e) => setExpForm({ ...expForm, responsible_id: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {profiles.map((u) => (
                  <option key={u.id} value={u.id}>{u.full_name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Valor (R$) *</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                value={expForm.amount}
                onChange={(e) => setExpForm({ ...expForm, amount: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white font-mono tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Data *</label>
              <input
                type="date"
                required
                value={expForm.expense_date}
                onChange={(e) => setExpForm({ ...expForm, expense_date: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Observações</label>
            <textarea
              rows={2}
              value={expForm.notes}
              onChange={(e) => setExpForm({ ...expForm, notes: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>
          <div className="flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
            <button type="button" onClick={() => setExpModalOpen(false)} className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md">
              Cancelar
            </button>
            <button type="submit" disabled={savingExp} className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50">
              {savingExp ? 'Salvando...' : 'Salvar despesa'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteInfo)}
        onClose={() => setDeleteInfo(null)}
        onConfirm={handleConfirmDelete}
        loading={deleting}
        title="Confirmar exclusão"
        description={`Tem certeza que deseja excluir o lançamento "${deleteInfo?.label}"?`}
        confirmLabel="Excluir"
      />
    </div>
  );
}
