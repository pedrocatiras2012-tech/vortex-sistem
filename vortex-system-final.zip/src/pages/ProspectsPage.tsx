import React, { useMemo, useState } from 'react';
import {
  ArrowRightLeft,
  Bot,
  CalendarClock,
  Database,
  Edit3,
  Eye,
  Kanban,
  MessageCircle,
  Phone,
  Plus,
  Search,
  SlidersHorizontal,
  Table2,
  Target,
  Trash2,
} from 'lucide-react';
import {
  PROSPECT_ORIGIN_OPTIONS,
  PROSPECT_STATUS_OPTIONS,
  COMPANY_STATUS_OPTIONS,
  SALE_PARTICIPATION_ROLE_OPTIONS,
  SALE_STATUS_OPTIONS,
  SERVICE_TYPE_OPTIONS,
} from '../lib/constants';
import {
  formatCNPJ,
  formatCurrency,
  formatDate,
  isValidEmail,
  toDateInputValue,
  todayISO,
} from '../lib/formatters';
import * as db from '../services/database';
import type {
  CommercialProposal,
  Company,
  CompanyStatus,
  LeadAssignmentHistory,
  ParticipatingCollaborator,
  Prospect,
  ProspectActivity,
  ProspectInteraction,
  ProspectStatus,
  SaleParticipationRole,
  ServiceType,
  UserProfile,
} from '../types';
import { useToast } from '../contexts/ToastContext';
import { CommercialActivitiesView } from '../components/prospects/CommercialActivitiesView';
import { ProspectDetailModal } from '../components/prospects/ProspectDetailModal';
import { ProspectingBotPanel } from '../components/prospects/ProspectingBotPanel';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { EmptyState, TableSkeleton } from '../components/ui/EmptyState';
import { Modal } from '../components/ui/Modal';
import { Pagination } from '../components/ui/Pagination';
import { StatusTag } from '../components/ui/StatusTag';

interface ProspectsPageProps {
  prospects: Prospect[];
  allProspectsForDedup?: Prospect[];
  companies?: Company[];
  interactions: ProspectInteraction[];
  activities: ProspectActivity[];
  proposals: CommercialProposal[];
  assignmentsHistory: LeadAssignmentHistory[];
  profiles: UserProfile[];
  currentUser: UserProfile;
  canDistributeLeads: boolean;
  defaultCommissionPct: number;
  tableMissing: boolean;
  activitiesTableMissing: boolean;
  proposalsTableMissing: boolean;
  loading: boolean;
  onRefresh: () => Promise<void>;
  onOpenSettingsSchema: () => void;
}

const EMPTY_PROSPECT_FORM = {
  company_name: '',
  contact_name: '',
  phone: '',
  whatsapp: '',
  email: '',
  city: '',
  state: '',
  segment: '',
  instagram: '',
  website: '',
  origin: 'Prospecção Ativa',
  responsible_id: '',
  responsible_name: '',
  estimated_value: '',
  notes: '',
  first_contact_date: todayISO(),
  next_contact_date: '',
  status: 'novo' as ProspectStatus,
};

interface CommissionSplitDraft {
  collaborator_id: string;
  collaborator_name: string;
  participation_role: SaleParticipationRole;
  commission_percentage: string;
  status: 'prevista' | 'pendente' | 'aprovada';
}

export function ProspectsPage({
  prospects,
  allProspectsForDedup,
  companies = [],
  interactions,
  activities,
  proposals,
  assignmentsHistory,
  profiles,
  currentUser,
  canDistributeLeads,
  defaultCommissionPct,
  tableMissing,
  activitiesTableMissing,
  proposalsTableMissing,
  loading,
  onRefresh,
  onOpenSettingsSchema,
}: ProspectsPageProps) {
  const { showSuccess, showError } = useToast();
  const today = todayISO();

  const [viewMode, setViewMode] = useState<'table' | 'kanban' | 'atividades' | 'bot'>('table');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [responsibleFilter, setResponsibleFilter] = useState<string>('todos');
  const [sortBy, setSortBy] = useState<'recent' | 'next_contact' | 'first_contact' | 'name' | 'value_desc' | 'score_desc'>('recent');

  // Expanded Filters
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [segmentFilter, setSegmentFilter] = useState('todos');
  const [stateFilter, setStateFilter] = useState('todos');
  const [cityFilter, setCityFilter] = useState('todos');
  const [scoreFilter, setScoreFilter] = useState<'todos' | 'alto' | 'medio' | 'baixo'>('todos');
  const [lastContactFilter, setLastContactFilter] = useState<'todos' | '7d' | '30d' | 'sem_contato'>('todos');
  const [nextActivityFilter, setNextActivityFilter] = useState<'todos' | 'atrasadas' | 'hoje' | 'futuras'>('todos');
  const [saleStatusFilter, setSaleStatusFilter] = useState('todos');
  const [minEstimatedValue, setMinEstimatedValue] = useState('');
  const [maxEstimatedValue, setMaxEstimatedValue] = useState('');

  const [page, setPage] = useState(1);
  const pageSize = 10;

  // Kanban drag-and-drop state
  const [draggedProspectId, setDraggedProspectId] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<ProspectStatus | null>(null);

  // Create / Edit Prospect Modal
  const [formOpen, setFormOpen] = useState(false);
  const [editingProspect, setEditingProspect] = useState<Prospect | null>(null);
  const [formData, setFormData] = useState(EMPTY_PROSPECT_FORM);
  const [saving, setSaving] = useState(false);

  // Detail Modal
  const [detailProspect, setDetailProspect] = useState<Prospect | null>(null);

  // Deal Closing / Conversion Modal
  const [convertProspect, setConvertProspect] = useState<Prospect | null>(null);
  const [convertForm, setConvertForm] = useState({
    name: '',
    contact_name: '',
    phone: '',
    whatsapp: '',
    email: '',
    cnpj: '',
    city: '',
    segment: '',
    entry_date: todayISO(),
    contracted_service: 'presenca_digital' as ServiceType,
    contract_value: '',
    responsible_id: '',
    status: 'ativo' as CompanyStatus,
    notes: '',
  });
  const [closingParticipants, setClosingParticipants] = useState<ParticipatingCollaborator[]>([]);
  const [generateCommission, setGenerateCommission] = useState(true);
  const [commissionSplits, setCommissionSplits] = useState<CommissionSplitDraft[]>([]);
  const [newCloseCollabId, setNewCloseCollabId] = useState('');
  const [newCloseRole, setNewCloseRole] = useState<SaleParticipationRole>('prospeccao');
  const [converting, setConverting] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<Prospect | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Derived option sets from real prospects
  const filterOptions = useMemo(() => {
    const segments = new Set<string>();
    const states = new Set<string>();
    const cities = new Set<string>();
    prospects.forEach((p) => {
      if (p.segment) segments.add(p.segment);
      if (p.state) states.add(p.state);
      if (p.city) cities.add(p.city);
    });
    return {
      segments: Array.from(segments).sort((a, b) => a.localeCompare(b, 'pt-BR')),
      states: Array.from(states).sort(),
      cities: Array.from(cities).sort((a, b) => a.localeCompare(b, 'pt-BR')),
    };
  }, [prospects]);

  // Index of latest interaction & next pending activity per prospect
  const interactionMetaByLead = useMemo(() => {
    const latestMap = new Map<string, string>();
    interactions.forEach((inter) => {
      const existing = latestMap.get(inter.prospect_id);
      if (!existing || inter.contact_at > existing) {
        latestMap.set(inter.prospect_id, inter.contact_at);
      }
    });
    return latestMap;
  }, [interactions]);

  const nextActivityByLead = useMemo(() => {
    const map = new Map<string, ProspectActivity>();
    activities
      .filter((a) => a.status === 'pendente')
      .forEach((act) => {
        const existing = map.get(act.prospect_id);
        if (!existing || act.due_date < existing.due_date) {
          map.set(act.prospect_id, act);
        }
      });
    return map;
  }, [activities]);

  const overdueActivitiesCount = useMemo(
    () => activities.filter((a) => a.status === 'pendente' && a.due_date < today).length,
    [activities, today]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const minVal = minEstimatedValue ? Number(minEstimatedValue) : null;
    const maxVal = maxEstimatedValue ? Number(maxEstimatedValue) : null;

    const nowMs = Date.now();
    const sevenDaysMs = 7 * 86400000;
    const thirtyDaysMs = 30 * 86400000;

    const list = prospects.filter((p) => {
      if (statusFilter !== 'todos' && p.status !== statusFilter) return false;
      if (responsibleFilter === '__unassigned__' && p.responsible_id) return false;
      if (
        responsibleFilter !== 'todos' &&
        responsibleFilter !== '__unassigned__' &&
        p.responsible_id !== responsibleFilter
      ) {
        return false;
      }
      if (segmentFilter !== 'todos' && p.segment !== segmentFilter) return false;
      if (stateFilter !== 'todos' && p.state !== stateFilter) return false;
      if (cityFilter !== 'todos' && p.city !== cityFilter) return false;

      if (scoreFilter !== 'todos') {
        const sc = p.lead_score;
        if (scoreFilter === 'alto' && (sc == null || sc < 80)) return false;
        if (scoreFilter === 'medio' && (sc == null || sc < 60 || sc >= 80)) return false;
        if (scoreFilter === 'baixo' && (sc == null || sc >= 60)) return false;
      }

      if (saleStatusFilter !== 'todos') {
        const effectiveSaleStatus = p.sale_status || (p.status === 'convertido' ? 'ganha' : p.status === 'perdido' ? 'perdida' : 'aberta');
        if (effectiveSaleStatus !== saleStatusFilter) return false;
      }

      const estVal = p.deal_value ?? p.estimated_value ?? 0;
      if (minVal !== null && estVal < minVal) return false;
      if (maxVal !== null && estVal > maxVal) return false;

      const lastInt = p.last_interaction_at || interactionMetaByLead.get(p.id) || null;
      if (lastContactFilter === 'sem_contato' && lastInt) return false;
      if (lastContactFilter === '7d') {
        if (!lastInt || nowMs - new Date(lastInt).getTime() > sevenDaysMs) return false;
      }
      if (lastContactFilter === '30d') {
        if (!lastInt || nowMs - new Date(lastInt).getTime() > thirtyDaysMs) return false;
      }

      const nextAct = nextActivityByLead.get(p.id);
      const nextDate = nextAct?.due_date || p.next_contact_date || '';
      if (nextActivityFilter === 'atrasadas' && (!nextDate || nextDate >= today)) return false;
      if (nextActivityFilter === 'hoje' && nextDate !== today) return false;
      if (nextActivityFilter === 'futuras' && (!nextDate || nextDate <= today)) return false;

      if (!q) return true;
      return (
        p.company_name.toLowerCase().includes(q) ||
        p.contact_name.toLowerCase().includes(q) ||
        p.city.toLowerCase().includes(q) ||
        p.segment.toLowerCase().includes(q) ||
        p.whatsapp.toLowerCase().includes(q) ||
        p.phone.toLowerCase().includes(q) ||
        (p.responsible_name || '').toLowerCase().includes(q)
      );
    });

    list.sort((a, b) => {
      if (sortBy === 'name') return a.company_name.localeCompare(b.company_name, 'pt-BR');
      if (sortBy === 'next_contact') {
        return (a.next_contact_date || '9999-12-31').localeCompare(b.next_contact_date || '9999-12-31');
      }
      if (sortBy === 'first_contact') {
        return (b.first_contact_date || '').localeCompare(a.first_contact_date || '');
      }
      if (sortBy === 'value_desc') {
        return (b.deal_value ?? b.estimated_value ?? 0) - (a.deal_value ?? a.estimated_value ?? 0);
      }
      if (sortBy === 'score_desc') {
        return (b.lead_score ?? -1) - (a.lead_score ?? -1);
      }
      return b.created_at.localeCompare(a.created_at);
    });

    return list;
  }, [
    prospects,
    search,
    statusFilter,
    responsibleFilter,
    segmentFilter,
    stateFilter,
    cityFilter,
    scoreFilter,
    saleStatusFilter,
    minEstimatedValue,
    maxEstimatedValue,
    lastContactFilter,
    nextActivityFilter,
    sortBy,
    interactionMetaByLead,
    nextActivityByLead,
    today,
  ]);

  const paginated = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page]);

  const clearFilters = () => {
    setSearch('');
    setStatusFilter('todos');
    setResponsibleFilter('todos');
    setSegmentFilter('todos');
    setStateFilter('todos');
    setCityFilter('todos');
    setScoreFilter('todos');
    setLastContactFilter('todos');
    setNextActivityFilter('todos');
    setSaleStatusFilter('todos');
    setMinEstimatedValue('');
    setMaxEstimatedValue('');
    setPage(1);
  };

  const openCreateModal = () => {
    setEditingProspect(null);
    setFormData({
      ...EMPTY_PROSPECT_FORM,
      responsible_id: currentUser.id,
      responsible_name: currentUser.full_name,
    });
    setFormOpen(true);
  };

  const openEditModal = (p: Prospect) => {
    setEditingProspect(p);
    setFormData({
      company_name: p.company_name,
      contact_name: p.contact_name,
      phone: p.phone,
      whatsapp: p.whatsapp,
      email: p.email || '',
      city: p.city,
      state: p.state || '',
      segment: p.segment,
      instagram: p.instagram,
      website: p.website,
      origin: p.origin || 'Prospecção Ativa',
      responsible_id: p.responsible_id === null ? '__unassigned__' : p.responsible_id || currentUser.id,
      responsible_name: p.responsible_name || '',
      estimated_value: p.estimated_value != null ? String(p.estimated_value) : '',
      notes: p.notes,
      first_contact_date: toDateInputValue(p.first_contact_date),
      next_contact_date: toDateInputValue(p.next_contact_date),
      status: p.status,
    });
    setFormOpen(true);
  };

  const handleSaveProspect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.company_name.trim() || !formData.contact_name.trim()) {
      showError('Campos obrigatórios', 'Informe o nome da empresa e do responsável.');
      return;
    }
    if (formData.email && !isValidEmail(formData.email)) {
      showError('E-mail inválido', 'Verifique o e-mail informado.');
      return;
    }

    const effectiveResponsibleId =
      formData.responsible_id === '__unassigned__'
        ? null
        : formData.responsible_id || currentUser.id;
    const respProfile = effectiveResponsibleId
      ? profiles.find((u) => u.id === effectiveResponsibleId) || currentUser
      : null;
    const responsibleName = respProfile ? respProfile.full_name : 'Sem responsável definido';
    const estimatedVal = formData.estimated_value ? Number(formData.estimated_value) : null;

    setSaving(true);
    try {
      if (editingProspect) {
        const updated = await db.updateProspect(editingProspect.id, {
          company_name: formData.company_name,
          contact_name: formData.contact_name,
          phone: formData.phone,
          whatsapp: formData.whatsapp,
          email: formData.email,
          city: formData.city,
          state: formData.state,
          segment: formData.segment,
          instagram: formData.instagram,
          website: formData.website,
          origin: formData.origin,
          responsible_id: effectiveResponsibleId,
          responsible_name: responsibleName,
          estimated_value: estimatedVal,
          notes: formData.notes,
          first_contact_date: formData.first_contact_date,
          next_contact_date: formData.next_contact_date,
          status: formData.status,
        });
        if (detailProspect?.id === updated.id) setDetailProspect(updated);
        showSuccess('Prospect atualizado', `${updated.company_name} foi atualizado.`);
      } else {
        await db.createProspect({
          company_name: formData.company_name,
          contact_name: formData.contact_name,
          phone: formData.phone,
          whatsapp: formData.whatsapp,
          email: formData.email,
          city: formData.city,
          state: formData.state,
          segment: formData.segment,
          instagram: formData.instagram,
          website: formData.website,
          origin: formData.origin,
          responsible_id: effectiveResponsibleId,
          responsible_name: responsibleName,
          estimated_value: estimatedVal,
          notes: formData.notes,
          first_contact_date: formData.first_contact_date,
          next_contact_date: formData.next_contact_date,
          status: formData.status,
        });
        showSuccess('Prospect cadastrado', `${formData.company_name} foi adicionado ao funil.`);
      }
      setFormOpen(false);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar prospect', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const handleQuickStatusChange = async (p: Prospect, newStatus: ProspectStatus) => {
    if (newStatus === 'convertido' && p.status !== 'convertido') {
      openConvertModal(p);
      return;
    }
    try {
      const updated = await db.updateProspect(p.id, {
        status: newStatus,
        sale_status: newStatus === 'perdido' || newStatus === 'sem_interesse' ? 'perdida' : 'aberta',
      });
      if (detailProspect?.id === updated.id) setDetailProspect(updated);
      showSuccess(
        'Etapa atualizada',
        `${p.company_name} movido para ${PROSPECT_STATUS_OPTIONS.find((s) => s.value === newStatus)?.label}.`
      );
      await onRefresh();
    } catch (err) {
      showError('Erro ao atualizar etapa', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  const openConvertModal = (p: Prospect) => {
    setConvertProspect(p);
    const defaultSellerId = p.responsible_id || currentUser.id;
    const defaultSeller = profiles.find((u) => u.id === defaultSellerId) || currentUser;

    setConvertForm({
      name: p.company_name,
      contact_name: p.contact_name,
      phone: p.phone,
      whatsapp: p.whatsapp,
      email: p.email || '',
      cnpj: '',
      city: p.city,
      segment: p.segment,
      entry_date: todayISO(),
      contracted_service: (p.contracted_service as ServiceType) || 'presenca_digital',
      contract_value: p.deal_value != null ? String(p.deal_value) : p.estimated_value != null ? String(p.estimated_value) : '',
      responsible_id: defaultSellerId,
      status: 'ativo',
      notes: p.notes,
    });
    setClosingParticipants(p.participating_collaborators || []);
    setGenerateCommission(true);
    setCommissionSplits([
      {
        collaborator_id: defaultSeller.id,
        collaborator_name: defaultSeller.full_name,
        participation_role: 'fechamento',
        commission_percentage: String(defaultCommissionPct || 10),
        status: 'prevista',
      },
    ]);
  };

  const handleAddClosingParticipant = () => {
    if (!newCloseCollabId) return;
    const collab = profiles.find((u) => u.id === newCloseCollabId);
    if (!collab) return;
    setClosingParticipants((prev) => {
      if (prev.some((x) => x.id === collab.id && x.participation_role === newCloseRole)) return prev;
      return [...prev, { id: collab.id, name: collab.full_name, participation_role: newCloseRole }];
    });
    setCommissionSplits((prev) => {
      if (prev.some((x) => x.collaborator_id === collab.id && x.participation_role === newCloseRole)) return prev;
      return [
        ...prev,
        {
          collaborator_id: collab.id,
          collaborator_name: collab.full_name,
          participation_role: newCloseRole,
          commission_percentage: '0',
          status: 'prevista',
        },
      ];
    });
    setNewCloseCollabId('');
  };

  const handleConfirmConversion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!convertProspect) return;
    if (!convertForm.name.trim() || !convertForm.contact_name.trim()) {
      showError('Dados obrigatórios', 'Informe nome da empresa e responsável.');
      return;
    }
    if (convertForm.email && !isValidEmail(convertForm.email)) {
      showError('E-mail inválido', 'Verifique o e-mail informado.');
      return;
    }
    const resp = profiles.find((u) => u.id === convertForm.responsible_id);

    const commissionEntries = generateCommission
      ? commissionSplits
          .filter((s) => s.collaborator_id && Number(s.commission_percentage) > 0)
          .map((s) => ({
            collaborator_id: s.collaborator_id,
            collaborator_name: s.collaborator_name,
            participation_role: s.participation_role,
            commission_percentage: Number(s.commission_percentage),
            status: s.status,
          }))
      : [];

    setConverting(true);
    try {
      const res = await db.convertProspectToCompany(convertProspect, {
        ...convertForm,
        contract_value: Number(convertForm.contract_value) || 0,
        responsible_id: convertForm.responsible_id || null,
        responsible_name: resp?.full_name || convertProspect.responsible_name || currentUser.full_name,
        participating_collaborators: closingParticipants,
        commission_entries: commissionEntries,
      });
      showSuccess(
        'Venda fechada e convertida',
        `${res.company.name} foi criada em Empresas preservando todo o histórico.`
      );
      setConvertProspect(null);
      if (detailProspect?.id === res.prospect.id) setDetailProspect(res.prospect);
      await onRefresh();
    } catch (err) {
      showError('Falha no fechamento', err instanceof Error ? err.message : 'Verifique duplicações.');
    } finally {
      setConverting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await db.deleteProspect(deleteTarget.id);
      showSuccess('Prospect excluído', `${deleteTarget.company_name} foi removido.`);
      if (detailProspect?.id === deleteTarget.id) setDetailProspect(null);
      setDeleteTarget(null);
      await onRefresh();
    } catch (err) {
      showError('Erro ao excluir', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setDeleting(false);
    }
  };

  if (tableMissing) {
    return (
      <div className="bg-[#111C30] border border-amber-500/30 rounded-lg p-6">
        <div className="flex items-start gap-3">
          <Database className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <h2 className="font-display text-base font-semibold text-white">
              Tabela de prospects não encontrada no Supabase
            </h2>
            <p className="text-xs text-[#8FA3C4] mt-1 leading-relaxed max-w-2xl">
              O sistema detectou que a tabela <code className="font-mono text-slate-200">prospects</code> ainda não existe neste projeto Supabase. Nenhuma alteração destrutiva foi executada automaticamente. Execute a migração SQL complementar não destrutiva para habilitar o CRM de Prospecção.
            </p>
            <button
              type="button"
              onClick={onOpenSettingsSchema}
              className="mt-4 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors"
            >
              Visualizar SQL de Migração em Configurações
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">CRM de Prospecção</h2>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Gestão comercial completa: funil em 11 etapas, histórico detalhado, atividades, propostas e fechamento
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="inline-flex flex-wrap items-center p-1 bg-[#0D1424] border border-[#1C2B45] rounded-md">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                viewMode === 'table' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
              }`}
            >
              <Table2 className="w-3.5 h-3.5" />
              Tabela
            </button>
            <button
              type="button"
              onClick={() => setViewMode('kanban')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                viewMode === 'kanban' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
              }`}
            >
              <Kanban className="w-3.5 h-3.5" />
              Kanban
            </button>
            <button
              type="button"
              onClick={() => setViewMode('atividades')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                viewMode === 'atividades' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
              }`}
            >
              <CalendarClock className="w-3.5 h-3.5" />
              Atividades Comerciais
              {overdueActivitiesCount > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 text-[10px] font-mono bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded">
                  {overdueActivitiesCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setViewMode('bot')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                viewMode === 'bot' ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
              }`}
            >
              <Bot className="w-3.5 h-3.5" />
              Bot de Prospecção
            </button>
          </div>

          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            Novo prospect
          </button>
        </div>
      </div>

      {(activitiesTableMissing || proposalsTableMissing) && viewMode !== 'bot' && (
        <div className="bg-[#111C30] border border-amber-500/30 rounded-lg px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-amber-200">
            Migração complementar <code className="font-mono">004_commercial_team_evolution.sql</code> pendente para atividades/propostas comerciais.
          </span>
          <button
            type="button"
            onClick={onOpenSettingsSchema}
            className="text-xs font-medium text-[#3B82F6] hover:underline"
          >
            Verificar Estrutura Supabase
          </button>
        </div>
      )}

      {viewMode === 'bot' ? (
        <ProspectingBotPanel
          prospects={allProspectsForDedup || prospects}
          companies={companies}
          profiles={profiles}
          currentUser={currentUser}
          canDistributeLeads={canDistributeLeads}
          onRefresh={onRefresh}
        />
      ) : viewMode === 'atividades' ? (
        <CommercialActivitiesView
          activities={activities}
          prospects={prospects}
          profiles={profiles}
          tableMissing={activitiesTableMissing}
          onOpenLead={(lead) => setDetailProspect(lead)}
          onOpenSettingsSchema={onOpenSettingsSchema}
          onRefresh={onRefresh}
        />
      ) : (
        <>
          {/* Filters Bar */}
          <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <div className="relative">
                <Search className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value);
                    setPage(1);
                  }}
                  placeholder="Buscar empresa, telefone, responsável..."
                  className="w-full pl-9 pr-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
                />
              </div>

              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="todos">Todas as etapas</option>
                {PROSPECT_STATUS_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>

              <select
                value={responsibleFilter}
                onChange={(e) => {
                  setResponsibleFilter(e.target.value);
                  setPage(1);
                }}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="todos">Todos os responsáveis</option>
                <option value="__unassigned__">Sem responsável definido</option>
                {profiles.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.full_name}
                  </option>
                ))}
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200 focus:outline-none focus:border-[#3B82F6]"
              >
                <option value="recent">Ordenar: Mais recentes</option>
                <option value="next_contact">Ordenar: Próxima atividade</option>
                <option value="value_desc">Ordenar: Maior valor estimado</option>
                <option value="score_desc">Ordenar: Maior Lead Score</option>
                <option value="first_contact">Ordenar: Primeiro contato</option>
                <option value="name">Ordenar: Empresa (A–Z)</option>
              </select>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAdvancedFilters((v) => !v)}
                  className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium rounded-md border transition-colors ${
                    showAdvancedFilters
                      ? 'bg-[#2563EB]/20 border-[#3B82F6] text-white'
                      : 'bg-[#080D18] border-[#1C2B45] text-slate-300 hover:text-white'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  Filtros avançados
                </button>
                <button
                  type="button"
                  onClick={clearFilters}
                  className="px-3 py-2 text-xs text-[#8FA3C4] hover:text-white bg-[#080D18] border border-[#1C2B45] rounded-md"
                >
                  Limpar
                </button>
              </div>
            </div>

            {showAdvancedFilters && (
              <div className="pt-3 border-t border-[#1C2B45] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
                <select
                  value={segmentFilter}
                  onChange={(e) => {
                    setSegmentFilter(e.target.value);
                    setPage(1);
                  }}
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
                >
                  <option value="todos">Segmento: Todos</option>
                  {filterOptions.segments.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>

                <select
                  value={stateFilter}
                  onChange={(e) => {
                    setStateFilter(e.target.value);
                    setPage(1);
                  }}
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
                >
                  <option value="todos">Estado (UF): Todos</option>
                  {filterOptions.states.map((st) => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>

                <select
                  value={cityFilter}
                  onChange={(e) => {
                    setCityFilter(e.target.value);
                    setPage(1);
                  }}
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
                >
                  <option value="todos">Cidade: Todas</option>
                  {filterOptions.cities.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>

                <select
                  value={scoreFilter}
                  onChange={(e) => {
                    setScoreFilter(e.target.value as typeof scoreFilter);
                    setPage(1);
                  }}
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
                >
                  <option value="todos">Lead Score: Todos</option>
                  <option value="alto">Alto potencial (80–100)</option>
                  <option value="medio">Médio potencial (60–79)</option>
                  <option value="baixo">Baixo potencial (&lt; 60)</option>
                </select>

                <select
                  value={lastContactFilter}
                  onChange={(e) => {
                    setLastContactFilter(e.target.value as typeof lastContactFilter);
                    setPage(1);
                  }}
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
                >
                  <option value="todos">Último contato: Todos</option>
                  <option value="7d">Últimos 7 dias</option>
                  <option value="30d">Últimos 30 dias</option>
                  <option value="sem_contato">Sem interação registrada</option>
                </select>

                <select
                  value={nextActivityFilter}
                  onChange={(e) => {
                    setNextActivityFilter(e.target.value as typeof nextActivityFilter);
                    setPage(1);
                  }}
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
                >
                  <option value="todos">Próxima atividade: Todas</option>
                  <option value="atrasadas">Atrasadas</option>
                  <option value="hoje">Para hoje</option>
                  <option value="futuras">Agendadas (futuras)</option>
                </select>

                <select
                  value={saleStatusFilter}
                  onChange={(e) => {
                    setSaleStatusFilter(e.target.value);
                    setPage(1);
                  }}
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
                >
                  <option value="todos">Status da venda: Todos</option>
                  {SALE_STATUS_OPTIONS.map((s) => (
                    <option key={s.value} value={s.value}>{s.label}</option>
                  ))}
                </select>

                <input
                  type="number"
                  min="0"
                  step="100"
                  value={minEstimatedValue}
                  onChange={(e) => {
                    setMinEstimatedValue(e.target.value);
                    setPage(1);
                  }}
                  placeholder="Valor mín. (R$)"
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white font-mono"
                />

                <input
                  type="number"
                  min="0"
                  step="100"
                  value={maxEstimatedValue}
                  onChange={(e) => {
                    setMaxEstimatedValue(e.target.value);
                    setPage(1);
                  }}
                  placeholder="Valor máx. (R$)"
                  className="px-2.5 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white font-mono"
                />
              </div>
            )}
          </div>

          {/* Content */}
          {loading ? (
            <TableSkeleton rows={6} cols={7} />
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={<Target className="w-5 h-5" />}
              title="Nenhum prospect encontrado"
              description="Cadastre seu primeiro prospect comercial ou ajuste os filtros aplicados."
              actionLabel="Cadastrar prospect"
              onAction={openCreateModal}
            />
          ) : viewMode === 'table' ? (
            <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                      <th className="py-3 px-4">Empresa / Contato</th>
                      <th className="py-3 px-4">Segmento / Cidade</th>
                      <th className="py-3 px-4">Responsável</th>
                      <th className="py-3 px-4 text-right">Valor est.</th>
                      <th className="py-3 px-4">Próxima atividade</th>
                      <th className="py-3 px-4">Etapa</th>
                      <th className="py-3 px-4 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1C2B45] text-xs">
                    {paginated.map((p) => {
                      const st = PROSPECT_STATUS_OPTIONS.find((s) => s.value === p.status);
                      const nextAct = nextActivityByLead.get(p.id);
                      const nextDate = nextAct?.due_date || p.next_contact_date;
                      const isOverdue = Boolean(nextDate && nextDate < today && p.status !== 'convertido' && p.status !== 'perdido');
                      const displayValue = p.deal_value ?? p.estimated_value;

                      return (
                        <tr key={p.id} className="hover:bg-[#15223B]/60 transition-colors">
                          <td className="py-3 px-4">
                            <button
                              type="button"
                              onClick={() => setDetailProspect(p)}
                              className="text-left group"
                            >
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="font-medium text-white group-hover:text-[#3B82F6] transition-colors">
                                  {p.company_name}
                                </p>
                                {typeof p.lead_score === 'number' && (
                                  <span
                                    className={`px-1.5 py-0.5 text-[10px] font-mono font-semibold rounded border ${
                                      p.lead_classification === 'alto'
                                        ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                                        : p.lead_classification === 'medio'
                                          ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                                          : 'bg-slate-500/10 text-slate-300 border-slate-500/30'
                                    }`}
                                  >
                                    {p.lead_score} pts
                                  </span>
                                )}
                              </div>
                              <p className="text-[#8FA3C4] mt-0.5">
                                {p.contact_name} · {p.whatsapp || p.phone || 'Sem telefone'}
                              </p>
                            </button>
                          </td>
                          <td className="py-3 px-4 text-slate-300">
                            <p>{p.segment || '—'}</p>
                            <p className="text-[#7D92B5]">{p.city ? `${p.city}${p.state ? ` / ${p.state}` : ''}` : '—'}</p>
                          </td>
                          <td className="py-3 px-4 text-slate-300">
                            {p.responsible_name ||
                              (p.responsible_id
                                ? profiles.find((u) => u.id === p.responsible_id)?.full_name
                                : null) ||
                              'Sem responsável'}
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400">
                            {displayValue != null && displayValue > 0 ? formatCurrency(displayValue) : '—'}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`font-mono tabular-nums ${
                                isOverdue ? 'text-rose-300 font-semibold' : 'text-slate-300'
                              }`}
                            >
                              {nextDate ? formatDate(nextDate) : 'Não agendada'}
                            </span>
                            {(nextAct?.title || p.next_activity_title) && (
                              <p className="text-[11px] text-[#7D92B5] truncate max-w-[160px]">
                                {nextAct?.title || p.next_activity_title}
                              </p>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <StatusTag
                              label={st?.label || p.status}
                              colorClass={st?.colorClass || 'text-slate-300 border-slate-600'}
                            />
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="inline-flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => setDetailProspect(p)}
                                title="Detalhes, histórico, atividades e propostas"
                                className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E] transition-colors"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              {p.status !== 'convertido' && (
                                <button
                                  type="button"
                                  onClick={() => openConvertModal(p)}
                                  title="Fechar venda / converter em empresa"
                                  className="p-1.5 rounded text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 transition-colors"
                                >
                                  <ArrowRightLeft className="w-4 h-4" />
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => openEditModal(p)}
                                title="Editar prospect"
                                className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E] transition-colors"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTarget(p)}
                                title="Excluir prospect"
                                className="p-1.5 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <Pagination
                currentPage={page}
                totalItems={filtered.length}
                pageSize={pageSize}
                onPageChange={setPage}
              />
            </div>
          ) : (
            /* 11-Stage Drag & Drop Kanban Board */
            <div className="flex gap-3 overflow-x-auto pb-4">
              {PROSPECT_STATUS_OPTIONS.map((col) => {
                const colItems = filtered.filter((p) => p.status === col.value);
                const colValueSum = colItems.reduce(
                  (acc, p) => acc + (p.deal_value ?? p.estimated_value ?? 0),
                  0
                );
                const isDragOver = dragOverColumn === col.value;

                return (
                  <div
                    key={col.value}
                    onDragOver={(e) => {
                      e.preventDefault();
                      setDragOverColumn(col.value);
                    }}
                    onDragLeave={() => setDragOverColumn(null)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setDragOverColumn(null);
                      const pid = draggedProspectId || e.dataTransfer.getData('text/plain');
                      setDraggedProspectId(null);
                      const moved = prospects.find((item) => item.id === pid);
                      if (moved && moved.status !== col.value) {
                        void handleQuickStatusChange(moved, col.value);
                      }
                    }}
                    className={`w-76 shrink-0 bg-[#0D1424] rounded-lg flex flex-col max-h-[720px] border transition-colors ${
                      isDragOver ? 'border-[#3B82F6] bg-[#101B32]' : 'border-[#1C2B45]'
                    }`}
                  >
                    <div className="px-3.5 py-3 border-b border-[#1C2B45] space-y-0.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-white truncate">{col.label}</span>
                        <span className="text-xs font-mono tabular-nums text-[#8FA3C4]">
                          {colItems.length}
                        </span>
                      </div>
                      {colValueSum > 0 && (
                        <p className="text-[11px] font-mono tabular-nums text-emerald-400">
                          {formatCurrency(colValueSum)}
                        </p>
                      )}
                    </div>

                    <div className="p-2.5 space-y-2.5 overflow-y-auto flex-1">
                      {colItems.length === 0 ? (
                        <p className="text-[11px] text-[#647B9E] text-center py-6">
                          Arraste leads para esta etapa
                        </p>
                      ) : (
                        colItems.map((p) => {
                          const lastInt = p.last_interaction_at || interactionMetaByLead.get(p.id);
                          const nextAct = nextActivityByLead.get(p.id);
                          const nextDate = nextAct?.due_date || p.next_contact_date;
                          const isOverdue = Boolean(nextDate && nextDate < today && p.status !== 'convertido' && p.status !== 'perdido');
                          const displayValue = p.deal_value ?? p.estimated_value;
                          const waDigits = (p.whatsapp || p.phone || '').replace(/\D/g, '');
                          const waHref =
                            waDigits.length >= 10
                              ? `https://wa.me/${waDigits.startsWith('55') ? waDigits : `55${waDigits}`}`
                              : '';

                          return (
                            <div
                              key={p.id}
                              draggable
                              onDragStart={(e) => {
                                setDraggedProspectId(p.id);
                                e.dataTransfer.setData('text/plain', p.id);
                              }}
                              onDragEnd={() => {
                                setDraggedProspectId(null);
                                setDragOverColumn(null);
                              }}
                              className="bg-[#111C30] border border-[#1C2B45] hover:border-[#2E4670] rounded-md p-3 transition-colors cursor-grab active:cursor-grabbing space-y-2"
                            >
                              <button
                                type="button"
                                onClick={() => setDetailProspect(p)}
                                className="text-left w-full space-y-1"
                              >
                                <div className="flex items-start justify-between gap-2">
                                  <p className="text-xs font-semibold text-white line-clamp-2">
                                    {p.company_name}
                                  </p>
                                  {typeof p.lead_score === 'number' && (
                                    <span
                                      className={`px-1.5 py-0.5 text-[10px] font-mono font-semibold rounded border shrink-0 ${
                                        p.lead_classification === 'alto'
                                          ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                                          : p.lead_classification === 'medio'
                                            ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                                            : 'bg-slate-500/10 text-slate-300 border-slate-500/30'
                                      }`}
                                    >
                                      {p.lead_score}
                                    </span>
                                  )}
                                </div>
                                <p className="text-[11px] text-[#8FA3C4] truncate">
                                  {p.contact_name} · {p.segment || 'Sem segmento'}
                                </p>
                                <p className="text-[11px] text-[#7D92B5] truncate">
                                  {p.city ? `${p.city}${p.state ? ` - ${p.state}` : ''}` : 'Cidade não informada'}
                                </p>
                              </button>

                              <div className="flex items-center justify-between gap-2 text-[11px] text-slate-300">
                                <span className="inline-flex items-center gap-1 truncate font-mono tabular-nums">
                                  <Phone className="w-3 h-3 text-[#3B82F6] shrink-0" />
                                  {p.whatsapp || p.phone || 'Sem telefone'}
                                </span>
                                {waHref && (
                                  <a
                                    href={waHref}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    title="Abrir WhatsApp"
                                    className="text-emerald-300 hover:text-emerald-200 shrink-0"
                                  >
                                    <MessageCircle className="w-3.5 h-3.5" />
                                  </a>
                                )}
                              </div>

                              <div className="pt-2 border-t border-[#1C2B45] space-y-1 text-[11px]">
                                <div className="flex items-center justify-between gap-2 text-[#8FA3C4]">
                                  <span className="truncate">
                                    Resp.: {p.responsible_name || 'Sem responsável'}
                                  </span>
                                  {displayValue != null && displayValue > 0 && (
                                    <span className="font-mono tabular-nums text-emerald-400 shrink-0">
                                      {formatCurrency(displayValue)}
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center justify-between gap-2 text-[#7D92B5]">
                                  <span>Últ. contato: {lastInt ? formatDate(lastInt) : '—'}</span>
                                  <span className={isOverdue ? 'text-rose-300 font-semibold font-mono' : 'font-mono'}>
                                    Próx.: {nextDate ? formatDate(nextDate) : '—'}
                                  </span>
                                </div>
                              </div>

                              <div className="pt-1 flex items-center justify-between gap-2">
                                <select
                                  aria-label={`Alterar etapa de ${p.company_name}`}
                                  value={p.status}
                                  onChange={(e) => void handleQuickStatusChange(p, e.target.value as ProspectStatus)}
                                  className="flex-1 px-2 py-1 text-[11px] bg-[#080D18] border border-[#1C2B45] rounded text-slate-200 focus:outline-none focus:border-[#3B82F6]"
                                >
                                  {PROSPECT_STATUS_OPTIONS.map((opt) => (
                                    <option key={opt.value} value={opt.value}>
                                      {opt.label}
                                    </option>
                                  ))}
                                </select>

                                <button
                                  type="button"
                                  onClick={() => setDetailProspect(p)}
                                  title="Abrir ficha completa do lead"
                                  className="p-1.5 rounded bg-[#080D18] border border-[#1C2B45] text-[#3B82F6] hover:text-white"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Create / Edit Prospect Modal */}
      <Modal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        title={editingProspect ? 'Editar Prospect' : 'Novo Prospect'}
        subtitle="Preencha os dados comerciais, valor estimado e agende o acompanhamento"
        maxWidthClass="max-w-3xl"
      >
        <form id="prospect-form" onSubmit={handleSaveProspect} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormInput
            label="Nome da empresa *"
            value={formData.company_name}
            onChange={(v) => setFormData({ ...formData, company_name: v })}
            required
          />
          <FormInput
            label="Nome do contato *"
            value={formData.contact_name}
            onChange={(v) => setFormData({ ...formData, contact_name: v })}
            required
          />
          <FormInput
            label="Telefone"
            value={formData.phone}
            onChange={(v) => setFormData({ ...formData, phone: v })}
            placeholder="(11) 3333-4444"
          />
          <FormInput
            label="WhatsApp"
            value={formData.whatsapp}
            onChange={(v) => setFormData({ ...formData, whatsapp: v })}
            placeholder="(11) 99999-9999"
          />
          <FormInput
            label="E-mail"
            type="email"
            value={formData.email}
            onChange={(v) => setFormData({ ...formData, email: v })}
          />
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <FormInput
                label="Cidade"
                value={formData.city}
                onChange={(v) => setFormData({ ...formData, city: v })}
              />
            </div>
            <FormInput
              label="UF"
              value={formData.state}
              onChange={(v) => setFormData({ ...formData, state: v.toUpperCase().slice(0, 2) })}
              placeholder="SP"
            />
          </div>
          <FormInput
            label="Segmento"
            value={formData.segment}
            onChange={(v) => setFormData({ ...formData, segment: v })}
            placeholder="Ex: Odontologia, Varejo, Indústria"
          />
          <FormInput
            label="Instagram"
            value={formData.instagram}
            onChange={(v) => setFormData({ ...formData, instagram: v })}
            placeholder="@empresa"
          />
          <FormInput
            label="Site"
            value={formData.website}
            onChange={(v) => setFormData({ ...formData, website: v })}
            placeholder="https://..."
          />
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Origem do contato</label>
            <select
              value={formData.origin}
              onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white focus:outline-none focus:border-[#3B82F6]"
            >
              {PROSPECT_ORIGIN_OPTIONS.map((o) => (
                <option key={o} value={o}>{o}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Responsável pela prospecção</label>
            <select
              value={formData.responsible_id}
              onChange={(e) => setFormData({ ...formData, responsible_id: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white focus:outline-none focus:border-[#3B82F6]"
            >
              {canDistributeLeads && <option value="__unassigned__">Sem responsável definido</option>}
              {profiles.filter((u) => u.status === 'ativo').map((u) => (
                <option key={u.id} value={u.id}>{u.full_name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Etapa do funil</label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as ProspectStatus })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white focus:outline-none focus:border-[#3B82F6]"
            >
              {PROSPECT_STATUS_OPTIONS.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>
          <FormInput
            label="Valor estimado da oportunidade (R$)"
            type="number"
            step="0.01"
            min="0"
            value={formData.estimated_value}
            onChange={(v) => setFormData({ ...formData, estimated_value: v })}
            placeholder="0.00"
          />
          <FormInput
            label="Data do primeiro contato"
            type="date"
            value={formData.first_contact_date}
            onChange={(v) => setFormData({ ...formData, first_contact_date: v })}
          />
          <FormInput
            label="Próxima data de contato"
            type="date"
            value={formData.next_contact_date}
            onChange={(v) => setFormData({ ...formData, next_contact_date: v })}
          />

          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-300 mb-1">Observações</label>
            <textarea
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
              placeholder="Detalhes da abordagem, dores identificadas ou observações relevantes..."
            />
          </div>

          <div className="sm:col-span-2 flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
            <button
              type="button"
              onClick={() => setFormOpen(false)}
              className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
            >
              {saving ? 'Salvando...' : editingProspect ? 'Salvar alterações' : 'Cadastrar prospect'}
            </button>
          </div>
        </form>
      </Modal>

      {/* 5-Tab Lead Detail Modal */}
      <ProspectDetailModal
        prospect={detailProspect}
        onClose={() => setDetailProspect(null)}
        profiles={profiles}
        currentUser={currentUser}
        canDistributeLeads={canDistributeLeads}
        interactions={interactions}
        activities={activities}
        proposals={proposals}
        assignmentsHistory={assignmentsHistory}
        onQuickStatusChange={handleQuickStatusChange}
        onOpenEditModal={openEditModal}
        onOpenConvertModal={openConvertModal}
        onUpdateProspectLocal={(updated) => setDetailProspect(updated)}
        onRefresh={onRefresh}
      />

      {/* Closing & Conversion Modal: Prospect -> Company + Participants + Configurable Commissions */}
      <Modal
        open={Boolean(convertProspect)}
        onClose={() => setConvertProspect(null)}
        title="Fechar Venda e Converter em Empresa"
        subtitle="Revise os dados do contrato, colaboradores participantes e comissões configuráveis."
        maxWidthClass="max-w-3xl"
      >
        <form onSubmit={handleConfirmConversion} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <FormInput
              label="Razão social / Nome da empresa *"
              value={convertForm.name}
              onChange={(v) => setConvertForm({ ...convertForm, name: v })}
              required
            />
            <FormInput
              label="Responsável na empresa *"
              value={convertForm.contact_name}
              onChange={(v) => setConvertForm({ ...convertForm, contact_name: v })}
              required
            />
            <FormInput
              label="CNPJ (opcional)"
              value={convertForm.cnpj}
              onChange={(v) => setConvertForm({ ...convertForm, cnpj: formatCNPJ(v) })}
              placeholder="00.000.000/0000-00"
            />
            <FormInput
              label="E-mail"
              type="email"
              value={convertForm.email}
              onChange={(v) => setConvertForm({ ...convertForm, email: v })}
            />
            <FormInput
              label="Telefone"
              value={convertForm.phone}
              onChange={(v) => setConvertForm({ ...convertForm, phone: v })}
            />
            <FormInput
              label="WhatsApp"
              value={convertForm.whatsapp}
              onChange={(v) => setConvertForm({ ...convertForm, whatsapp: v })}
            />
            <FormInput
              label="Data de fechamento / entrada *"
              type="date"
              value={convertForm.entry_date}
              onChange={(v) => setConvertForm({ ...convertForm, entry_date: v })}
              required
            />
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Serviço contratado</label>
              <select
                value={convertForm.contracted_service}
                onChange={(e) => setConvertForm({ ...convertForm, contracted_service: e.target.value as ServiceType })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {SERVICE_TYPE_OPTIONS.map((s) => (
                  <option key={s.value} value={s.value}>{s.label}</option>
                ))}
              </select>
            </div>
            <FormInput
              label="Valor fechado / negociado (R$)"
              type="number"
              step="0.01"
              min="0"
              value={convertForm.contract_value}
              onChange={(v) => setConvertForm({ ...convertForm, contract_value: v })}
              placeholder="0.00"
            />
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Vendedor principal</label>
              <select
                value={convertForm.responsible_id}
                onChange={(e) => setConvertForm({ ...convertForm, responsible_id: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {profiles.map((u) => (
                  <option key={u.id} value={u.id}>{u.full_name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Status inicial do cliente</label>
              <select
                value={convertForm.status}
                onChange={(e) => setConvertForm({ ...convertForm, status: e.target.value as CompanyStatus })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {COMPANY_STATUS_OPTIONS.map((s) => (
                  <option key={s.value} value={s.value}>{s.label}</option>
                ))}
              </select>
            </div>
            <FormInput
              label="Cidade"
              value={convertForm.city}
              onChange={(v) => setConvertForm({ ...convertForm, city: v })}
            />
          </div>

          {/* Participating collaborators & optional configurable commissions */}
          <div className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-3.5 space-y-3 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-semibold text-white">Participação na venda & Comissões configuráveis</p>
              <label className="inline-flex items-center gap-2 text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={generateCommission}
                  onChange={(e) => setGenerateCommission(e.target.checked)}
                  className="rounded border-[#2C4166] bg-[#080D18]"
                />
                <span>Gerar lançamentos no módulo Comissões</span>
              </label>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={newCloseCollabId}
                onChange={(e) => setNewCloseCollabId(e.target.value)}
                className="flex-1 min-w-[160px] px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
              >
                <option value="">Adicionar colaborador participante...</option>
                {profiles.filter((u) => u.status === 'ativo').map((u) => (
                  <option key={u.id} value={u.id}>{u.full_name}</option>
                ))}
              </select>
              <select
                value={newCloseRole}
                onChange={(e) => setNewCloseRole(e.target.value as SaleParticipationRole)}
                className="px-2.5 py-1.5 text-xs bg-[#080D18] border border-[#1C2B45] rounded text-white"
              >
                {SALE_PARTICIPATION_ROLE_OPTIONS.map((r) => (
                  <option key={r.value} value={r.value}>{r.label}</option>
                ))}
              </select>
              <button
                type="button"
                onClick={handleAddClosingParticipant}
                className="px-3 py-1.5 text-xs font-medium text-white bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded"
              >
                Incluir
              </button>
            </div>

            {generateCommission && commissionSplits.length > 0 && (
              <div className="space-y-2 pt-1">
                {commissionSplits.map((split, idx) => {
                  const pct = Number(split.commission_percentage) || 0;
                  const saleVal = Number(convertForm.contract_value) || 0;
                  const valCalc = (saleVal * pct) / 100;
                  return (
                    <div
                      key={`${split.collaborator_id}-${split.participation_role}-${idx}`}
                      className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center bg-[#080D18] border border-[#1C2B45] rounded p-2"
                    >
                      <span className="sm:col-span-4 text-white truncate">
                        {split.collaborator_name}{' '}
                        <span className="text-[#7D92B5]">({split.participation_role})</span>
                      </span>
                      <div className="sm:col-span-3 flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          max="100"
                          step="0.5"
                          value={split.commission_percentage}
                          onChange={(e) =>
                            setCommissionSplits((prev) =>
                              prev.map((item, i) =>
                                i === idx ? { ...item, commission_percentage: e.target.value } : item
                              )
                            )
                          }
                          className="w-full px-2 py-1 text-xs bg-[#111C30] border border-[#1C2B45] rounded text-white font-mono"
                        />
                        <span className="text-[#8FA3C4]">%</span>
                      </div>
                      <select
                        value={split.status}
                        onChange={(e) =>
                          setCommissionSplits((prev) =>
                            prev.map((item, i) =>
                              i === idx
                                ? { ...item, status: e.target.value as CommissionSplitDraft['status'] }
                                : item
                            )
                          )
                        }
                        className="sm:col-span-2 px-2 py-1 text-xs bg-[#111C30] border border-[#1C2B45] rounded text-white"
                      >
                        <option value="prevista">Prevista</option>
                        <option value="pendente">Pendente</option>
                        <option value="aprovada">Aprovada</option>
                      </select>
                      <span className="sm:col-span-2 text-right font-mono tabular-nums text-emerald-400">
                        {formatCurrency(valCalc)}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setCommissionSplits((prev) => prev.filter((_, i) => i !== idx))
                        }
                        className="sm:col-span-1 text-right text-rose-400 hover:text-rose-300"
                      >
                        ×
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Observações do contrato</label>
            <textarea
              rows={2}
              value={convertForm.notes}
              onChange={(e) => setConvertForm({ ...convertForm, notes: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
            <button
              type="button"
              onClick={() => setConvertProspect(null)}
              className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={converting}
              className="px-4 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded-md disabled:opacity-50"
            >
              {converting ? 'Confirmando...' : 'Confirmar fechamento e conversão'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Excluir prospect"
        description={`Tem certeza que deseja excluir "${deleteTarget?.company_name}"? Esta ação removerá o prospect e seu vínculo permanente.`}
        confirmLabel="Excluir prospect"
      />
    </div>
  );
}

function FormInput({
  label,
  value,
  onChange,
  type = 'text',
  required = false,
  placeholder,
  step,
  min,
}: {
  label: string;
  value: string;
  onChange: (val: string) => void;
  type?: string;
  required?: boolean;
  placeholder?: string;
  step?: string;
  min?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-300 mb-1">{label}</label>
      <input
        type={type}
        required={required}
        value={value}
        step={step}
        min={min}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E] focus:outline-none focus:border-[#3B82F6]"
      />
    </div>
  );
}
