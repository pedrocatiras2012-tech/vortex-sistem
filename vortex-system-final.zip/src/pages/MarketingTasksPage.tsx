import React, { useMemo, useState } from 'react';
import { Check, CheckSquare, Edit3, Plus, Search, Trash2 } from 'lucide-react';
import {
  TASK_CATEGORY_OPTIONS,
  TASK_PRIORITY_OPTIONS,
  TASK_STATUS_OPTIONS,
} from '../lib/constants';
import { formatDate, toDateInputValue, todayISO } from '../lib/formatters';
import * as db from '../services/database';
import type { MarketingTask, TaskCategory, TaskPriority, TaskStatus, UserProfile } from '../types';
import { useToast } from '../contexts/ToastContext';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { EmptyState, TableSkeleton } from '../components/ui/EmptyState';
import { Modal } from '../components/ui/Modal';
import { Pagination } from '../components/ui/Pagination';
import { StatusTag } from '../components/ui/StatusTag';

interface MarketingTasksPageProps {
  tasks: MarketingTask[];
  profiles: UserProfile[];
  currentUser: UserProfile;
  loading: boolean;
  onRefresh: () => Promise<void>;
}

export function MarketingTasksPage({
  tasks,
  profiles,
  currentUser,
  loading,
  onRefresh,
}: MarketingTasksPageProps) {
  const { showSuccess, showError } = useToast();

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('todos');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [priorityFilter, setPriorityFilter] = useState('todos');
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<MarketingTask | null>(null);
  const [form, setForm] = useState({
    title: '',
    description: '',
    category: 'marketing' as TaskCategory,
    responsible_id: currentUser.id,
    due_date: todayISO(),
    priority: 'media' as TaskPriority,
    status: 'pendente' as TaskStatus,
  });
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<MarketingTask | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return tasks.filter((t) => {
      if (categoryFilter !== 'todos' && t.category !== categoryFilter) return false;
      if (statusFilter !== 'todos' && t.status !== statusFilter) return false;
      if (priorityFilter !== 'todos' && t.priority !== priorityFilter) return false;
      if (!q) return true;
      return (
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.responsible_name.toLowerCase().includes(q)
      );
    });
  }, [tasks, search, categoryFilter, statusFilter, priorityFilter]);

  const paginated = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page]);

  const openCreate = () => {
    setEditing(null);
    setForm({
      title: '',
      description: '',
      category: 'marketing',
      responsible_id: currentUser.id,
      due_date: todayISO(),
      priority: 'media',
      status: 'pendente',
    });
    setFormOpen(true);
  };

  const openEdit = (t: MarketingTask) => {
    setEditing(t);
    setForm({
      title: t.title,
      description: t.description,
      category: t.category,
      responsible_id: t.responsible_id || currentUser.id,
      due_date: toDateInputValue(t.due_date),
      priority: t.priority,
      status: t.status,
    });
    setFormOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      showError('Título obrigatório', 'Informe um título para a tarefa.');
      return;
    }

    const resp = profiles.find((u) => u.id === form.responsible_id);
    const payload = {
      title: form.title,
      description: form.description,
      category: form.category,
      responsible_id: form.responsible_id || null,
      responsible_name: resp?.full_name || currentUser.full_name,
      due_date: form.due_date,
      priority: form.priority,
      status: form.status,
    };

    setSaving(true);
    try {
      if (editing) {
        await db.updateMarketingTask(editing.id, payload);
        showSuccess('Tarefa atualizada', 'Alterações salvas.');
      } else {
        await db.createMarketingTask(payload);
        showSuccess('Tarefa criada', `${form.title} foi adicionada.`);
      }
      setFormOpen(false);
      await onRefresh();
    } catch (err) {
      showError('Erro ao salvar tarefa', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const handleComplete = async (t: MarketingTask) => {
    const nextStatus: TaskStatus = t.status === 'concluida' ? 'pendente' : 'concluida';
    try {
      await db.updateMarketingTask(t.id, { status: nextStatus });
      showSuccess(
        nextStatus === 'concluida' ? 'Tarefa concluída' : 'Tarefa reaberta',
        t.title
      );
      await onRefresh();
    } catch (err) {
      showError('Erro ao atualizar tarefa', err instanceof Error ? err.message : 'Tente novamente.');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await db.deleteMarketingTask(deleteTarget.id);
      showSuccess('Tarefa excluída', `${deleteTarget.title} foi removida.`);
      setDeleteTarget(null);
      await onRefresh();
    } catch (err) {
      showError('Erro ao excluir tarefa', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">Marketing e Tarefas</h2>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Organização operacional para campanhas de marketing, produção de conteúdo, atendimento e comercial
          </p>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Nova tarefa
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-[#111C30] border border-[#1C2B45] rounded-lg p-3.5">
        <div className="relative">
          <Search className="w-4 h-4 text-[#647B9E] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Buscar tarefa ou responsável..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white placeholder:text-[#566C8E]"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => {
            setCategoryFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
        >
          <option value="todos">Todas categorias</option>
          {TASK_CATEGORY_OPTIONS.map((c) => (
            <option key={c.value} value={c.value}>{c.label}</option>
          ))}
        </select>

        <select
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
        >
          <option value="todos">Todos os status</option>
          {TASK_STATUS_OPTIONS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>

        <select
          value={priorityFilter}
          onChange={(e) => {
            setPriorityFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-slate-200"
        >
          <option value="todos">Todas prioridades</option>
          {TASK_PRIORITY_OPTIONS.map((p) => (
            <option key={p.value} value={p.value}>{p.label}</option>
          ))}
        </select>
      </div>

      {/* Table */}
      {loading ? (
        <TableSkeleton rows={6} cols={6} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<CheckSquare className="w-5 h-5" />}
          title="Nenhuma tarefa encontrada"
          description="Crie atividades de marketing, conteúdo, atendimento ou comercial para sua equipe."
          actionLabel="Criar primeira tarefa"
          onAction={openCreate}
        />
      ) : (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] font-medium text-[#8FA3C4]">
                  <th className="py-3 px-4">Tarefa</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4">Responsável</th>
                  <th className="py-3 px-4">Prazo</th>
                  <th className="py-3 px-4">Prioridade</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1C2B45] text-xs">
                {paginated.map((t) => {
                  const cat = TASK_CATEGORY_OPTIONS.find((c) => c.value === t.category);
                  const pri = TASK_PRIORITY_OPTIONS.find((p) => p.value === t.priority);
                  const st = TASK_STATUS_OPTIONS.find((s) => s.value === t.status);
                  return (
                    <tr key={t.id} className="hover:bg-[#15223B]/60">
                      <td className="py-3 px-4">
                        <p className={`font-medium ${t.status === 'concluida' ? 'line-through text-[#7D92B5]' : 'text-white'}`}>
                          {t.title}
                        </p>
                        {t.description && (
                          <p className="text-[#8FA3C4] truncate max-w-xs mt-0.5">{t.description}</p>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-300">{cat?.label || t.category}</td>
                      <td className="py-3 px-4 text-slate-300">{t.responsible_name || '—'}</td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-300">
                        {t.due_date ? formatDate(t.due_date) : '—'}
                      </td>
                      <td className="py-3 px-4">
                        <StatusTag
                          label={pri?.label || t.priority}
                          colorClass={pri?.colorClass || 'text-slate-300 border-slate-600'}
                        />
                      </td>
                      <td className="py-3 px-4">
                        <StatusTag
                          label={st?.label || t.status}
                          colorClass={st?.colorClass || 'text-slate-300 border-slate-600'}
                        />
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => void handleComplete(t)}
                            title={t.status === 'concluida' ? 'Reabrir tarefa' : 'Concluir tarefa'}
                            className={`p-1.5 rounded transition-colors ${
                              t.status === 'concluida'
                                ? 'text-emerald-400 bg-emerald-500/10'
                                : 'text-slate-300 hover:text-emerald-400 hover:bg-emerald-500/10'
                            }`}
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openEdit(t)}
                            title="Editar tarefa"
                            className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#1D2E4E]"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(t)}
                            title="Excluir tarefa"
                            className="p-1.5 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination
            currentPage={page}
            totalItems={filtered.length}
            pageSize={pageSize}
            onPageChange={setPage}
          />
        </div>
      )}

      {/* Task Modal */}
      <Modal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        title={editing ? 'Editar Tarefa' : 'Nova Tarefa'}
        maxWidthClass="max-w-lg"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Título *</label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Ex: Publicar estudo de caso semanal"
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Categoria</label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value as TaskCategory })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {TASK_CATEGORY_OPTIONS.map((c) => (
                  <option key={c.value} value={c.value}>{c.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Responsável</label>
              <select
                value={form.responsible_id}
                onChange={(e) => setForm({ ...form, responsible_id: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {profiles.map((u) => (
                  <option key={u.id} value={u.id}>{u.full_name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Prazo</label>
              <input
                type="date"
                value={form.due_date}
                onChange={(e) => setForm({ ...form, due_date: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Prioridade</label>
              <select
                value={form.priority}
                onChange={(e) => setForm({ ...form, priority: e.target.value as TaskPriority })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                {TASK_PRIORITY_OPTIONS.map((p) => (
                  <option key={p.value} value={p.value}>{p.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Status</label>
            <select
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value as TaskStatus })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            >
              {TASK_STATUS_OPTIONS.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Descrição</label>
            <textarea
              rows={3}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2 border-t border-[#1C2B45]">
            <button type="button" onClick={() => setFormOpen(false)} className="px-4 py-2 text-xs font-medium text-slate-300 bg-[#15223B] hover:bg-[#1C2D4D] rounded-md">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50">
              {saving ? 'Salvando...' : editing ? 'Salvar tarefa' : 'Criar tarefa'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Excluir tarefa"
        description={`Tem certeza que deseja excluir "${deleteTarget?.title}"?`}
        confirmLabel="Excluir"
      />
    </div>
  );
}
