import { useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  AlertTriangle,
  ArrowUpRight,
  Building2,
  CalendarClock,
  CheckCircle2,
  DollarSign,
  Percent,
  Target,
  TrendingDown,
  TrendingUp,
  Users,
} from 'lucide-react';
import { PROSPECT_STATUS_OPTIONS, TASK_STATUS_OPTIONS } from '../lib/constants';
import { formatCurrency, formatDate, formatDateTime, formatPercent, todayISO } from '../lib/formatters';
import type {
  AppPage,
  CommercialProposal,
  Commission,
  Company,
  Expense,
  MarketingTask,
  Payment,
  Prospect,
  ProspectActivity,
  ProspectInteraction,
  UserProfile,
} from '../types';
import { StatusTag } from '../components/ui/StatusTag';

interface DashboardPageProps {
  companies: Company[];
  prospects: Prospect[];
  commissions: Commission[];
  payments: Payment[];
  expenses: Expense[];
  tasks: MarketingTask[];
  interactions: ProspectInteraction[];
  activities?: ProspectActivity[];
  proposals?: CommercialProposal[];
  profiles?: UserProfile[];
  currentUser?: UserProfile;
  canViewTeamOverview?: boolean;
  canViewFinance?: boolean;
  loading: boolean;
  onNavigate: (page: AppPage) => void;
}

type PeriodFilter = '30d' | '90d' | 'mes_atual' | '12m' | 'todos';

function getPeriodStart(filter: PeriodFilter): Date | null {
  const now = new Date();
  if (filter === 'todos') return null;
  if (filter === 'mes_atual') {
    return new Date(now.getFullYear(), now.getMonth(), 1);
  }
  const days = filter === '30d' ? 30 : filter === '90d' ? 90 : 365;
  const d = new Date(now);
  d.setDate(d.getDate() - days);
  return d;
}

function inPeriod(dateStr: string | null | undefined, start: Date | null): boolean {
  if (!start) return true;
  if (!dateStr) return false;
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return false;
  return d >= start;
}

export function DashboardPage({
  companies,
  prospects,
  commissions,
  payments,
  expenses,
  tasks,
  interactions,
  activities = [],
  proposals = [],
  profiles = [],
  canViewTeamOverview = true,
  canViewFinance = true,
  loading,
  onNavigate,
}: DashboardPageProps) {
  const [period, setPeriod] = useState<PeriodFilter>('mes_atual');
  const today = todayISO();

  const periodStart = useMemo(() => getPeriodStart(period), [period]);

  const metrics = useMemo(() => {
    const filteredProspects = prospects.filter((p) => inPeriod(p.created_at, periodStart));
    const filteredCompanies = companies.filter((c) => inPeriod(c.entry_date || c.created_at, periodStart));
    const filteredPayments = payments.filter(
      (p) => p.status === 'recebido' && inPeriod(p.payment_date || p.created_at, periodStart)
    );
    const filteredExpenses = expenses.filter((e) => inPeriod(e.expense_date || e.created_at, periodStart));

    const negotiatingCount = prospects.filter(
      (p) => p.status === 'em_negociacao' || p.status === 'proposta_enviada'
    ).length;

    const convertedCount = filteredProspects.filter((p) => p.status === 'convertido').length;
    const conversionRate =
      filteredProspects.length > 0 ? (convertedCount / filteredProspects.length) * 100 : 0;

    // Pending commissions: prevista + pendente + aprovada (NOT confused with paid)
    const pendingCommissions = commissions
      .filter((c) => c.status === 'prevista' || c.status === 'pendente' || c.status === 'aprovada')
      .reduce((acc, c) => acc + c.commission_value, 0);

    // Paid commissions in period strictly using paid_at
    const paidCommissions = commissions
      .filter((c) => c.status === 'paga' && c.paid_at && inPeriod(c.paid_at, periodStart))
      .reduce((acc, c) => acc + c.commission_value, 0);

    const totalRevenue = filteredPayments.reduce((acc, p) => acc + p.amount, 0);
    const totalExpenses = filteredExpenses.reduce((acc, e) => acc + e.amount, 0);
    const financialResult = totalRevenue - totalExpenses;

    // Commercial Overview metrics
    const newLeads = prospects.filter((p) => p.status === 'novo' || p.status === 'contato_pendente').length;
    const inProgressLeads = prospects.filter(
      (p) =>
        p.status === 'primeiro_contato' ||
        p.status === 'interessado' ||
        p.status === 'reuniao_agendada' ||
        p.status === 'em_negociacao'
    ).length;
    const awaitingReplyLeads = prospects.filter((p) => p.status === 'aguardando_resposta').length;
    const proposalsSentCount =
      proposals.length > 0
        ? proposals.filter((pr) => pr.status === 'enviada' || pr.status === 'visualizada' || pr.status === 'em_negociacao').length
        : prospects.filter((p) => p.status === 'proposta_enviada').length;
    const closedWonPeriod = prospects.filter(
      (p) => p.status === 'convertido' && inPeriod(p.closed_at || p.converted_at || p.created_at, periodStart)
    ).length;
    const closedLostPeriod = prospects.filter(
      (p) => (p.status === 'perdido' || p.status === 'sem_interesse') && inPeriod(p.closed_at || p.updated_at || p.created_at, periodStart)
    ).length;
    const openPipelineValue = prospects
      .filter((p) => p.status !== 'convertido' && p.status !== 'perdido' && p.status !== 'sem_interesse')
      .reduce((acc, p) => acc + (p.estimated_value ?? 0), 0);

    const overdueActivities = activities.filter((a) => a.status === 'pendente' && a.due_date < today);
    const upcomingActivities = activities
      .filter((a) => a.status === 'pendente' && a.due_date >= today)
      .slice(0, 5);

    return {
      totalCompanies: companies.length,
      totalProspects: prospects.length,
      negotiatingCount,
      wonClientsPeriod: filteredCompanies.length,
      pendingCommissions,
      paidCommissions,
      totalRevenue,
      totalExpenses,
      financialResult,
      conversionRate,
      filteredProspectsCount: filteredProspects.length,
      convertedCount,
      newLeads,
      inProgressLeads,
      awaitingReplyLeads,
      proposalsSentCount,
      closedWonPeriod,
      closedLostPeriod,
      openPipelineValue,
      overdueActivities,
      upcomingActivities,
    };
  }, [companies, prospects, commissions, payments, expenses, proposals, activities, periodStart, today]);

  // Team Overview metrics (permission-gated)
  const teamOverview = useMemo(() => {
    if (!canViewTeamOverview || profiles.length === 0) return null;
    const activeMembers = profiles.filter((u) => u.status === 'ativo');
    const distributedLeads = prospects.filter((p) => Boolean(p.responsible_id)).length;
    const unassignedLeads = prospects.length - distributedLeads;
    const completedActivitiesPeriod = activities.filter(
      (a) => a.status === 'concluida' && inPeriod(a.completed_at || a.due_date, periodStart)
    ).length;

    const byCollaborator = activeMembers.map((u) => {
      const leads = prospects.filter((p) => p.responsible_id === u.id).length;
      const won = prospects.filter(
        (p) => p.responsible_id === u.id && p.status === 'convertido' && inPeriod(p.closed_at || p.converted_at || p.created_at, periodStart)
      );
      const soldValue = won.reduce((acc, p) => acc + (p.deal_value ?? p.estimated_value ?? 0), 0);
      const doneActs = activities.filter(
        (a) => a.responsible_id === u.id && a.status === 'concluida' && inPeriod(a.completed_at || a.due_date, periodStart)
      ).length;
      return {
        id: u.id,
        name: u.full_name,
        department: u.department || 'Geral',
        leads,
        wonCount: won.length,
        soldValue,
        doneActs,
      };
    });

    const deptMap = new Map<string, { department: string; members: number; leads: number; won: number; sold: number }>();
    byCollaborator.forEach((m) => {
      const prev = deptMap.get(m.department) || {
        department: m.department,
        members: 0,
        leads: 0,
        won: 0,
        sold: 0,
      };
      prev.members += 1;
      prev.leads += m.leads;
      prev.won += m.wonCount;
      prev.sold += m.soldValue;
      deptMap.set(m.department, prev);
    });

    return {
      activeMembersCount: activeMembers.length,
      distributedLeads,
      unassignedLeads,
      completedActivitiesPeriod,
      byCollaborator: byCollaborator.sort((a, b) => b.soldValue - a.soldValue || b.leads - a.leads).slice(0, 6),
      byDepartment: Array.from(deptMap.values()).sort((a, b) => b.sold - a.sold),
    };
  }, [canViewTeamOverview, profiles, prospects, activities, periodStart]);

  // Monthly evolution chart (last 6 months from real data)
  const monthlySeries = useMemo(() => {
    const now = new Date();
    const months: {
      key: string;
      label: string;
      receitas: number;
      despesas: number;
      resultado: number;
      comissoesPagas: number;
      comissoesPendentes: number;
    }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = new Intl.DateTimeFormat('pt-BR', { month: 'short', year: '2-digit' }).format(d);
      months.push({ key, label, receitas: 0, despesas: 0, resultado: 0, comissoesPagas: 0, comissoesPendentes: 0 });
    }

    payments.forEach((p) => {
      if (p.status !== 'recebido') return;
      const mKey = (p.payment_date || p.created_at).slice(0, 7);
      const bucket = months.find((m) => m.key === mKey);
      if (bucket) bucket.receitas += p.amount;
    });

    expenses.forEach((e) => {
      const mKey = (e.expense_date || e.created_at).slice(0, 7);
      const bucket = months.find((m) => m.key === mKey);
      if (bucket) bucket.despesas += e.amount;
    });

    commissions.forEach((c) => {
      if (c.status === 'paga' && c.paid_at) {
        const mKey = c.paid_at.slice(0, 7);
        const bucket = months.find((m) => m.key === mKey);
        if (bucket) bucket.comissoesPagas += c.commission_value;
      } else if (c.status === 'prevista' || c.status === 'pendente' || c.status === 'aprovada') {
        const mKey = c.created_at.slice(0, 7);
        const bucket = months.find((m) => m.key === mKey);
        if (bucket) bucket.comissoesPendentes += c.commission_value;
      }
    });

    months.forEach((m) => {
      m.resultado = m.receitas - m.despesas;
    });

    return months;
  }, [payments, expenses, commissions]);

  // 11-Stage Prospecting funnel chart
  const funnelData = useMemo(() => {
    const colors: Record<string, string> = {
      novo: '#38BDF8',
      contato_pendente: '#94A3B8',
      primeiro_contato: '#3B82F6',
      aguardando_resposta: '#F59E0B',
      interessado: '#818CF8',
      reuniao_agendada: '#C084FC',
      proposta_enviada: '#A78BFA',
      em_negociacao: '#06B6D4',
      convertido: '#10B981',
      perdido: '#F43F5E',
      sem_interesse: '#71717A',
    };
    return PROSPECT_STATUS_OPTIONS.map((opt) => ({
      name: opt.label,
      quantidade: prospects.filter((p) => p.status === opt.value).length,
      fill: colors[opt.value] || '#3B82F6',
    }));
  }, [prospects]);

  const recentClients = useMemo(() => companies.slice(0, 5), [companies]);
  const upcomingTasks = useMemo(
    () =>
      tasks
        .filter((t) => t.status !== 'concluida' && t.status !== 'cancelada')
        .slice(0, 5),
    [tasks]
  );
  const recentInteractions = useMemo(() => interactions.slice(0, 5), [interactions]);

  const periodOptions: { id: PeriodFilter; label: string }[] = [
    { id: 'mes_atual', label: 'Mês atual' },
    { id: '30d', label: '30 dias' },
    { id: '90d', label: '90 dias' },
    { id: '12m', label: '12 meses' },
    { id: 'todos', label: 'Todo período' },
  ];

  return (
    <div className="space-y-6">
      {/* Header & Period Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">Visão Executiva</h2>
          <p className="text-xs text-[#8FA3C4] mt-0.5">
            Indicadores comerciais, operacionais, da equipe e financeiros em tempo real
          </p>
        </div>

        <div className="inline-flex items-center p-1 bg-[#0D1424] border border-[#1C2B45] rounded-md overflow-x-auto max-w-full">
          {periodOptions.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setPeriod(opt.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                period === opt.id
                  ? 'bg-[#2563EB] text-white'
                  : 'text-[#8FA3C4] hover:text-white'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <KpiCard
          label="Empresas cadastradas"
          value={loading ? '...' : String(metrics.totalCompanies)}
          subtext={`${metrics.wonClientsPeriod} conquistadas no período`}
          icon={<Building2 className="w-4 h-4 text-[#3B82F6]" />}
          onClick={() => onNavigate('empresas')}
        />
        <KpiCard
          label="Total de prospects"
          value={loading ? '...' : String(metrics.totalProspects)}
          subtext={`${metrics.negotiatingCount} em negociação / proposta`}
          icon={<Target className="w-4 h-4 text-[#3B82F6]" />}
          onClick={() => onNavigate('prospeccao')}
        />
        <KpiCard
          label="Taxa de conversão"
          value={loading ? '...' : formatPercent(metrics.conversionRate)}
          subtext={`${metrics.convertedCount} de ${metrics.filteredProspectsCount} prospects`}
          icon={<TrendingUp className="w-4 h-4 text-emerald-400" />}
          onClick={() => onNavigate('prospeccao')}
        />
        <KpiCard
          label="Comissões a pagar"
          value={loading ? '...' : formatCurrency(metrics.pendingCommissions)}
          subtext={`Pagas no período: ${formatCurrency(metrics.paidCommissions)}`}
          icon={<Percent className="w-4 h-4 text-amber-400" />}
          onClick={() => onNavigate('comissoes')}
        />
        {canViewFinance ? (
          <KpiCard
            label="Resultado financeiro"
            value={loading ? '...' : formatCurrency(metrics.financialResult)}
            subtext={`Despesas: ${formatCurrency(metrics.totalExpenses)}`}
            icon={
              metrics.financialResult >= 0 ? (
                <DollarSign className="w-4 h-4 text-emerald-400" />
              ) : (
                <TrendingDown className="w-4 h-4 text-rose-400" />
              )
            }
            valueTone={metrics.financialResult >= 0 ? 'text-emerald-400' : 'text-rose-400'}
            onClick={() => onNavigate('financeiro')}
          />
        ) : (
          <KpiCard
            label="Oportunidades abertas"
            value={loading ? '...' : formatCurrency(metrics.openPipelineValue)}
            subtext={`${metrics.proposalsSentCount} propostas ativas`}
            icon={<DollarSign className="w-4 h-4 text-emerald-400" />}
            valueTone="text-emerald-400"
            onClick={() => onNavigate('prospeccao')}
          />
        )}
      </div>

      {/* Visão Comercial */}
      <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="font-display text-sm font-semibold text-white">Visão Comercial do Pipeline</h3>
            <p className="text-xs text-[#8FA3C4] mt-0.5">
              Acompanhamento em tempo real de etapas, propostas, oportunidades e atividades comerciais
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('prospeccao')}
            className="text-xs text-[#3B82F6] hover:text-blue-400 inline-flex items-center gap-1"
          >
            Gerenciar CRM <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          <MiniStat label="Novos / pend." value={String(metrics.newLeads)} />
          <MiniStat label="Em andamento" value={String(metrics.inProgressLeads)} />
          <MiniStat label="Aguard. resposta" value={String(metrics.awaitingReplyLeads)} tone="text-amber-300" />
          <MiniStat label="Propostas env." value={String(metrics.proposalsSentCount)} tone="text-violet-300" />
          <MiniStat label="Vendas fechadas" value={String(metrics.closedWonPeriod)} tone="text-emerald-400" />
          <MiniStat label="Vendas perdidas" value={String(metrics.closedLostPeriod)} tone="text-rose-400" />
          <MiniStat label="Valor pipeline" value={formatCurrency(metrics.openPipelineValue)} tone="text-emerald-400" />
          <MiniStat
            label="Ativ. atrasadas"
            value={String(metrics.overdueActivities.length)}
            tone={metrics.overdueActivities.length > 0 ? 'text-rose-400' : 'text-slate-300'}
          />
        </div>

        {(metrics.overdueActivities.length > 0 || metrics.upcomingActivities.length > 0) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-[#1C2B45] text-xs">
            <div>
              <p className="font-medium text-rose-300 flex items-center gap-1.5 mb-2">
                <AlertTriangle className="w-3.5 h-3.5" />
                Atividades comerciais atrasadas ({metrics.overdueActivities.length})
              </p>
              {metrics.overdueActivities.length === 0 ? (
                <p className="text-[#7D92B5]">Nenhuma atividade atrasada.</p>
              ) : (
                <div className="space-y-1.5">
                  {metrics.overdueActivities.slice(0, 3).map((act) => (
                    <div key={act.id} className="flex items-center justify-between gap-2 bg-[#0D1424] border border-rose-500/25 rounded px-3 py-2">
                      <span className="text-slate-200 truncate">{act.title}</span>
                      <span className="font-mono tabular-nums text-rose-300 shrink-0">
                        {formatDate(act.due_date)} · {act.responsible_name}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div>
              <p className="font-medium text-sky-300 flex items-center gap-1.5 mb-2">
                <CalendarClock className="w-3.5 h-3.5" />
                Próximas atividades comerciais ({metrics.upcomingActivities.length})
              </p>
              {metrics.upcomingActivities.length === 0 ? (
                <p className="text-[#7D92B5]">Nenhuma atividade futura agendada.</p>
              ) : (
                <div className="space-y-1.5">
                  {metrics.upcomingActivities.slice(0, 3).map((act) => (
                    <div key={act.id} className="flex items-center justify-between gap-2 bg-[#0D1424] border border-[#1C2B45] rounded px-3 py-2">
                      <span className="text-slate-200 truncate">{act.title}</span>
                      <span className="font-mono tabular-nums text-[#8FA3C4] shrink-0">
                        {formatDate(act.due_date)} · {act.responsible_name}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Visão da Equipe (only if authorized) */}
      {canViewTeamOverview && teamOverview && (
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-[#3B82F6]" />
              <div>
                <h3 className="font-display text-sm font-semibold text-white">Visão da Equipe</h3>
                <p className="text-xs text-[#8FA3C4]">
                  {teamOverview.activeMembersCount} colaboradores ativos · {teamOverview.distributedLeads} leads distribuídos · {teamOverview.unassignedLeads} sem responsável · {teamOverview.completedActivitiesPeriod} atividades concluídas
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('equipe')}
              className="text-xs text-[#3B82F6] hover:text-blue-400 inline-flex items-center gap-1"
            >
              Painel da Equipe <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
            <div className="border border-[#1C2B45] rounded-md bg-[#0D1424] p-3.5">
              <p className="font-semibold text-white mb-2">Vendas e Leads por Colaborador</p>
              <div className="divide-y divide-[#1C2B45]">
                {teamOverview.byCollaborator.map((c) => (
                  <div key={c.id} className="py-2 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-slate-200 font-medium truncate">{c.name}</p>
                      <p className="text-[11px] text-[#7D92B5]">
                        {c.leads} leads · {c.doneActs} atividades concl. · {c.wonCount} vendas
                      </p>
                    </div>
                    <span className="font-mono tabular-nums text-emerald-400 shrink-0 font-semibold">
                      {formatCurrency(c.soldValue)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="border border-[#1C2B45] rounded-md bg-[#0D1424] p-3.5">
              <p className="font-semibold text-white mb-2">Desempenho por Área / Departamento</p>
              <div className="divide-y divide-[#1C2B45]">
                {teamOverview.byDepartment.map((d) => (
                  <div key={d.department} className="py-2 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-slate-200 font-medium truncate">{d.department}</p>
                      <p className="text-[11px] text-[#7D92B5]">
                        {d.members} membros · {d.leads} leads · {d.won} vendas
                      </p>
                    </div>
                    <span className="font-mono tabular-nums text-emerald-400 shrink-0 font-semibold">
                      {formatCurrency(d.sold)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Charts Row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {canViewFinance && (
          <div className="xl:col-span-2 bg-[#111C30] border border-[#1C2B45] rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-display text-sm font-semibold text-white">
                  Evolução Mensal (Receitas vs. Despesas)
                </h3>
                <p className="text-xs text-[#8FA3C4] mt-0.5">Últimos 6 meses consolidados</p>
              </div>
            </div>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlySeries} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="gradReceitas" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563EB" stopOpacity={0.35} />
                      <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradDespesas" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#F43F5E" stopOpacity={0.25} />
                      <stop offset="95%" stopColor="#F43F5E" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1C2B45" vertical={false} />
                  <XAxis dataKey="label" stroke="#7D92B5" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis
                    stroke="#7D92B5"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) => `R$${Number(v) >= 1000 ? `${(Number(v) / 1000).toFixed(0)}k` : v}`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0D1424',
                      borderColor: '#1C2B45',
                      borderRadius: '6px',
                      fontSize: '12px',
                      color: '#F8FAFC',
                    }}
                    formatter={(value) => formatCurrency(Number(value))}
                  />
                  <Area
                    type="monotone"
                    dataKey="receitas"
                    name="Receitas"
                    stroke="#3B82F6"
                    strokeWidth={2}
                    fill="url(#gradReceitas)"
                  />
                  <Area
                    type="monotone"
                    dataKey="despesas"
                    name="Despesas"
                    stroke="#F43F5E"
                    strokeWidth={2}
                    fill="url(#gradDespesas)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Commissions Chart */}
        <div className={`${canViewFinance ? '' : 'xl:col-span-3'} bg-[#111C30] border border-[#1C2B45] rounded-lg p-5`}>
          <div className="mb-4">
            <h3 className="font-display text-sm font-semibold text-white">Comissões por Mês</h3>
            <p className="text-xs text-[#8FA3C4] mt-0.5">Pagas (data efetiva) vs. Previstas/Pendentes</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlySeries} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1C2B45" vertical={false} />
                <XAxis dataKey="label" stroke="#7D92B5" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis
                  stroke="#7D92B5"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => `R$${Number(v) >= 1000 ? `${(Number(v) / 1000).toFixed(0)}k` : v}`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0D1424',
                    borderColor: '#1C2B45',
                    borderRadius: '6px',
                    fontSize: '12px',
                    color: '#F8FAFC',
                  }}
                  formatter={(value) => formatCurrency(Number(value))}
                />
                <Bar dataKey="comissoesPagas" name="Pagas" fill="#10B981" radius={[3, 3, 0, 0]} />
                <Bar dataKey="comissoesPendentes" name="Prev./Pend." fill="#F59E0B" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Prospecting Pipeline Chart + Operational Lists */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-sm font-semibold text-white">Funil de Prospecção (11 Etapas)</h3>
              <p className="text-xs text-[#8FA3C4] mt-0.5">Distribuição atual por etapa</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('prospeccao')}
              className="text-xs text-[#3B82F6] hover:text-blue-400 inline-flex items-center gap-1"
            >
              Abrir CRM <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={funnelData} layout="vertical" margin={{ top: 0, right: 16, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1C2B45" horizontal={false} />
                <XAxis type="number" stroke="#7D92B5" fontSize={11} allowDecimals={false} tickLine={false} axisLine={false} />
                <YAxis
                  type="category"
                  dataKey="name"
                  stroke="#9BB0D1"
                  fontSize={10}
                  width={136}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0D1424',
                    borderColor: '#1C2B45',
                    borderRadius: '6px',
                    fontSize: '12px',
                    color: '#F8FAFC',
                  }}
                />
                <Bar dataKey="quantidade" name="Prospects" radius={[0, 3, 3, 0]}>
                  {funnelData.map((entry, idx) => (
                    <Cell key={idx} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Clients */}
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display text-sm font-semibold text-white">Últimos Clientes Cadastrados</h3>
            <button
              type="button"
              onClick={() => onNavigate('empresas')}
              className="text-xs text-[#3B82F6] hover:text-blue-400 inline-flex items-center gap-1"
            >
              Ver todos <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          {recentClients.length === 0 ? (
            <p className="text-xs text-[#8FA3C4] py-8 text-center">Nenhum cliente cadastrado ainda.</p>
          ) : (
            <div className="divide-y divide-[#1C2B45] flex-1">
              {recentClients.map((client) => (
                <div key={client.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-white truncate">{client.name}</p>
                    <p className="text-xs text-[#8FA3C4] truncate">
                      {client.contact_name || 'Sem responsável'} · {formatDate(client.entry_date)}
                    </p>
                  </div>
                  <span className="text-xs font-mono tabular-nums text-emerald-400 shrink-0">
                    {formatCurrency(client.contract_value)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Activities & Tasks */}
        <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display text-sm font-semibold text-white">Próximas Tarefas & Contatos</h3>
            <button
              type="button"
              onClick={() => onNavigate('marketing')}
              className="text-xs text-[#3B82F6] hover:text-blue-400 inline-flex items-center gap-1"
            >
              Ver tarefas <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-4 flex-1">
            {upcomingTasks.length === 0 ? (
              <p className="text-xs text-[#8FA3C4] py-3">Nenhuma tarefa pendente.</p>
            ) : (
              <div className="divide-y divide-[#1C2B45]">
                {upcomingTasks.map((task) => {
                  const st = TASK_STATUS_OPTIONS.find((s) => s.value === task.status);
                  return (
                    <div key={task.id} className="py-2 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-white truncate">{task.title}</p>
                        <p className="text-[11px] text-[#8FA3C4] inline-flex items-center gap-1 mt-0.5">
                          <CalendarClock className="w-3 h-3" />
                          <span>{task.due_date ? formatDate(task.due_date) : 'Sem prazo'}</span>
                          <span>·</span>
                          <span className="truncate">{task.responsible_name || 'Equipe'}</span>
                        </p>
                      </div>
                      <StatusTag
                        label={st?.label || task.status}
                        colorClass={st?.colorClass || 'text-slate-300 border-slate-600'}
                      />
                    </div>
                  );
                })}
              </div>
            )}

            <div className="pt-3 border-t border-[#1C2B45]">
              <p className="text-xs font-medium text-slate-300 mb-2">Atividades recentes de prospecção</p>
              {recentInteractions.length === 0 ? (
                <p className="text-xs text-[#7D92B5]">Nenhuma interação registrada recentemente.</p>
              ) : (
                <div className="space-y-2">
                  {recentInteractions.slice(0, 3).map((item) => (
                    <div key={item.id} className="text-xs flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#3B82F6] shrink-0 mt-0.5" />
                      <div className="min-w-0">
                        <p className="text-slate-200 truncate">{item.summary}</p>
                        <p className="text-[11px] text-[#7D92B5]">
                          {item.responsible_name || 'Comercial'} · {formatDateTime(item.contact_at)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function KpiCard({
  label,
  value,
  subtext,
  icon,
  valueTone = 'text-white',
  onClick,
}: {
  label: string;
  value: string;
  subtext: string;
  icon: React.ReactNode;
  valueTone?: string;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="text-left bg-[#111C30] hover:bg-[#15223B] border border-[#1C2B45] hover:border-[#2C4166] rounded-lg p-4 transition-colors"
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium text-[#8FA3C4] truncate">{label}</span>
        {icon}
      </div>
      <p className={`text-xl font-bold font-mono tabular-nums mt-2 truncate ${valueTone}`}>{value}</p>
      <p className="text-[11px] text-[#7D92B5] mt-1 truncate">{subtext}</p>
    </button>
  );
}

function MiniStat({ label, value, tone = 'text-white' }: { label: string; value: string; tone?: string }) {
  return (
    <div className="bg-[#0D1424] border border-[#1C2B45] rounded-md p-3">
      <p className="text-[11px] text-[#8FA3C4] truncate">{label}</p>
      <p className={`text-base font-mono font-bold tabular-nums mt-0.5 truncate ${tone}`}>{value}</p>
    </div>
  );
}
