import React, { useEffect, useState } from 'react';
import { Building, CheckCircle2, Copy, Database, Key, RefreshCw, Shield, Sliders, User } from 'lucide-react';
import { ROLE_LABELS } from '../lib/constants';
import { formatCNPJ } from '../lib/formatters';
import { probeDatabaseSchema } from '../lib/supabase';
import * as db from '../services/database';
import type { AppPage, SchemaTableStatus, SystemSettings, UserProfile } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

interface SettingsPageProps {
  currentUser: UserProfile;
  settings: SystemSettings;
  onRefreshAll: () => Promise<void>;
  onNavigate: (page: AppPage) => void;
  initialTab?: SettingsTab;
}

type SettingsTab = 'perfil' | 'empresa' | 'preferencias' | 'banco';

const MIGRATION_HINT = `-- Migrações SQL incrementais não destrutivas disponíveis em:
-- 1) supabase/migrations/001_vortex_complement.sql
-- 2) supabase/migrations/002_prospects_complement.sql
-- 3) supabase/migrations/003_prospects_intelligence.sql
-- 4) supabase/migrations/004_commercial_team_evolution.sql
-- Execute manualmente no SQL Editor do Supabase sem apagar tabelas ou dados existentes.`;

export function SettingsPage({
  currentUser,
  settings,
  onRefreshAll,
  onNavigate,
  initialTab = 'perfil',
}: SettingsPageProps) {
  const { updatePassword, refreshProfile } = useAuth();
  const { showSuccess, showError } = useToast();

  const [tab, setTab] = useState<SettingsTab>(initialTab);
  const isOwnerOrAdmin = currentUser.role === 'proprietario' || currentUser.role === 'administrador';

  // Profile form
  const [fullName, setFullName] = useState(currentUser.full_name);
  const [jobTitle, setJobTitle] = useState(currentUser.job_title);
  const [savingProfile, setSavingProfile] = useState(false);

  // Password form
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);

  // Organization & preferences
  const [orgForm, setOrgForm] = useState<SystemSettings>(settings);
  const [savingOrg, setSavingOrg] = useState(false);

  // Database probe
  const [schemaList, setSchemaList] = useState<SchemaTableStatus[]>([]);
  const [probing, setProbing] = useState(false);

  useEffect(() => {
    setFullName(currentUser.full_name);
    setJobTitle(currentUser.job_title);
  }, [currentUser]);

  useEffect(() => {
    setOrgForm(settings);
  }, [settings]);

  const runProbe = async () => {
    setProbing(true);
    try {
      const res = await probeDatabaseSchema();
      setSchemaList(res);
    } finally {
      setProbing(false);
    }
  };

  useEffect(() => {
    if (tab === 'banco' && schemaList.length === 0) {
      void runProbe();
    }
  }, [tab, schemaList.length]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      showError('Nome obrigatório', 'Informe seu nome.');
      return;
    }
    setSavingProfile(true);
    try {
      await db.updateOwnProfile(currentUser.id, {
        full_name: fullName,
        job_title: jobTitle,
      });
      await refreshProfile();
      showSuccess('Perfil atualizado', 'Seus dados pessoais foram salvos.');
    } catch (err) {
      showError('Erro ao salvar perfil', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleSavePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      showError('Senha curta', 'A nova senha deve ter pelo menos 6 caracteres.');
      return;
    }
    if (newPassword !== confirmPassword) {
      showError('Senhas diferentes', 'A confirmação de senha não confere.');
      return;
    }
    setSavingPassword(true);
    try {
      await updatePassword(newPassword);
      setNewPassword('');
      setConfirmPassword('');
      showSuccess('Senha alterada', 'Sua senha de acesso foi atualizada.');
    } catch (err) {
      showError('Erro ao alterar senha', err instanceof Error ? err.message : 'Tente novamente.');
    } finally {
      setSavingPassword(false);
    }
  };

  const handleSaveOrgSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOwnerOrAdmin) return;
    setSavingOrg(true);
    try {
      await db.saveSystemSettings(orgForm);
      await onRefreshAll();
      showSuccess('Configurações salvas', 'Dados da empresa e preferências do sistema atualizados.');
    } catch (err) {
      showError(
        'Erro ao salvar configurações',
        err instanceof Error ? err.message : 'Verifique se a tabela system_settings foi criada.'
      );
    } finally {
      setSavingOrg(false);
    }
  };

  const copySqlHint = async () => {
    try {
      await navigator.clipboard.writeText(MIGRATION_HINT);
      showSuccess('Referência copiada', 'Abra supabase/migrations/001_vortex_complement.sql para copiar o SQL completo.');
    } catch {
      showError('Não foi possível copiar');
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-display text-xl font-semibold text-white">Configurações</h2>
        <p className="text-xs text-[#8FA3C4] mt-0.5">
          Perfil do usuário, dados da organização, preferências e diagnóstico do banco Supabase
        </p>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-[#0D1424] border border-[#1C2B45] rounded-md w-fit max-w-full">
        <TabButton active={tab === 'perfil'} onClick={() => setTab('perfil')} icon={<User className="w-3.5 h-3.5" />} label="Meu Perfil" />
        {isOwnerOrAdmin && (
          <TabButton active={tab === 'empresa'} onClick={() => setTab('empresa')} icon={<Building className="w-3.5 h-3.5" />} label="Dados da Empresa" />
        )}
        {isOwnerOrAdmin && (
          <TabButton active={tab === 'preferencias'} onClick={() => setTab('preferencias')} icon={<Sliders className="w-3.5 h-3.5" />} label="Preferências & Sistema" />
        )}
        <TabButton active={tab === 'banco'} onClick={() => setTab('banco')} icon={<Database className="w-3.5 h-3.5" />} label="Estrutura Supabase" />
      </div>

      {/* Tab: Perfil */}
      {tab === 'perfil' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <form onSubmit={handleSaveProfile} className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 space-y-4">
            <h3 className="font-display text-sm font-semibold text-white">Dados do Perfil</h3>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Nome completo</label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Cargo</label>
              <input
                type="text"
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded bg-[#080D18] border border-[#1C2B45]">
                <p className="text-[#8FA3C4]">E-mail</p>
                <p className="text-slate-200 mt-0.5 truncate">{currentUser.email}</p>
              </div>
              <div className="p-3 rounded bg-[#080D18] border border-[#1C2B45]">
                <p className="text-[#8FA3C4]">Nível de acesso</p>
                <p className="text-white font-medium mt-0.5">{ROLE_LABELS[currentUser.role]}</p>
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={savingProfile}
                className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
              >
                {savingProfile ? 'Salvando...' : 'Salvar perfil'}
              </button>
            </div>
          </form>

          <div className="space-y-5">
            <form onSubmit={handleSavePassword} className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-[#3B82F6]" />
                <h3 className="font-display text-sm font-semibold text-white">Alterar Senha</h3>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Nova senha</label>
                <input
                  type="password"
                  minLength={6}
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Confirmar nova senha</label>
                <input
                  type="password"
                  minLength={6}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repita a nova senha"
                  className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
                />
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={savingPassword}
                  className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
                >
                  {savingPassword ? 'Atualizando...' : 'Atualizar senha'}
                </button>
              </div>
            </form>

            {currentUser.role === 'proprietario' && (
              <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold text-white flex items-center gap-2">
                    <Shield className="w-4 h-4 text-[#3B82F6]" />
                    Usuários e Permissões
                  </p>
                  <p className="text-xs text-[#8FA3C4] mt-1">
                    Gerencie cargos, acessos por módulo e equipe no painel dedicado.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('equipe')}
                  className="px-3.5 py-2 text-xs font-medium text-white bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded-md whitespace-nowrap shrink-0"
                >
                  Abrir Equipe
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab: Dados da Empresa */}
      {tab === 'empresa' && isOwnerOrAdmin && (
        <form onSubmit={handleSaveOrgSettings} className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 max-w-2xl space-y-4">
          <h3 className="font-display text-sm font-semibold text-white">Dados da Organização</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Nome da empresa</label>
              <input
                type="text"
                value={orgForm.organization_name}
                onChange={(e) => setOrgForm({ ...orgForm, organization_name: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">CNPJ</label>
              <input
                type="text"
                value={orgForm.organization_cnpj}
                onChange={(e) => setOrgForm({ ...orgForm, organization_cnpj: formatCNPJ(e.target.value) })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">E-mail corporativo</label>
              <input
                type="email"
                value={orgForm.organization_email}
                onChange={(e) => setOrgForm({ ...orgForm, organization_email: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Telefone</label>
              <input
                type="text"
                value={orgForm.organization_phone}
                onChange={(e) => setOrgForm({ ...orgForm, organization_phone: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Cidade / UF</label>
              <input
                type="text"
                value={orgForm.organization_city}
                onChange={(e) => setOrgForm({ ...orgForm, organization_city: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={savingOrg}
              className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
            >
              {savingOrg ? 'Salvando...' : 'Salvar dados'}
            </button>
          </div>
        </form>
      )}

      {/* Tab: Preferências */}
      {tab === 'preferencias' && isOwnerOrAdmin && (
        <form onSubmit={handleSaveOrgSettings} className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 max-w-2xl space-y-4">
          <h3 className="font-display text-sm font-semibold text-white">Parâmetros do Sistema</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Percentual padrão de comissão (%)
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                max="100"
                value={orgForm.default_commission_pct}
                onChange={(e) =>
                  setOrgForm({ ...orgForm, default_commission_pct: Number(e.target.value) || 0 })
                }
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white font-mono tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Período padrão de análise (dias)
              </label>
              <select
                value={orgForm.preferences.defaultPeriodDays}
                onChange={(e) =>
                  setOrgForm({
                    ...orgForm,
                    preferences: {
                      ...orgForm.preferences,
                      defaultPeriodDays: Number(e.target.value),
                    },
                  })
                }
                className="w-full px-3 py-2 text-xs bg-[#080D18] border border-[#1C2B45] rounded-md text-white"
              >
                <option value={7}>7 dias</option>
                <option value={30}>30 dias</option>
                <option value={90}>90 dias</option>
              </select>
            </div>
          </div>

          <label className="flex items-center gap-2.5 text-xs text-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={orgForm.preferences.compactTables}
              onChange={(e) =>
                setOrgForm({
                  ...orgForm,
                  preferences: { ...orgForm.preferences, compactTables: e.target.checked },
                })
              }
              className="rounded border-[#2C4166] bg-[#080D18]"
            />
            <span>Usar visualização compacta em tabelas</span>
          </label>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={savingOrg}
              className="px-4 py-2 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50"
            >
              {savingOrg ? 'Salvando...' : 'Salvar preferências'}
            </button>
          </div>
        </form>
      )}

      {/* Tab: Estrutura Supabase */}
      {tab === 'banco' && (
        <div className="space-y-4">
          <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="font-display text-sm font-semibold text-white">
                  Diagnóstico das Tabelas Existentes (Leitura Segura)
                </h3>
                <p className="text-xs text-[#8FA3C4] mt-0.5">
                  Verifica quais tabelas respondem no seu projeto Supabase sem modificar nenhum dado ou política RLS.
                </p>
              </div>
              <button
                type="button"
                onClick={() => void runProbe()}
                disabled={probing}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#2563EB] hover:bg-[#3B82F6] rounded-md disabled:opacity-50 shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${probing ? 'animate-spin' : ''}`} />
                Verificar agora
              </button>
            </div>

            <div className="overflow-x-auto border border-[#1C2B45] rounded-md">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#0D1424] border-b border-[#1C2B45] text-[11px] text-[#8FA3C4]">
                    <th className="py-2.5 px-4">Tabela</th>
                    <th className="py-2.5 px-4">Estado</th>
                    <th className="py-2.5 px-4 text-right">Registros</th>
                    <th className="py-2.5 px-4">Observação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1C2B45]">
                  {schemaList.map((item) => (
                    <tr key={item.table}>
                      <td className="py-2.5 px-4 font-mono text-white">{item.table}</td>
                      <td className="py-2.5 px-4">
                        {item.accessible ? (
                          <span className="inline-flex items-center gap-1 text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Conectada
                          </span>
                        ) : item.exists ? (
                          <span className="text-amber-400">Restrita por RLS</span>
                        ) : (
                          <span className="text-rose-400">Ausente</span>
                        )}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-300">
                        {item.rowCount !== null ? item.rowCount : '—'}
                      </td>
                      <td className="py-2.5 px-4 text-[#8FA3C4]">{item.error || 'Pronta para uso'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-[#111C30] border border-[#1C2B45] rounded-lg p-5 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h4 className="font-display text-sm font-semibold text-white">
                  Migrações SQL Incrementais (Não Destrutivas)
                </h4>
                <p className="text-xs text-[#8FA3C4] mt-0.5">
                  Execute <code className="font-mono text-slate-200">supabase/migrations/004_commercial_team_evolution.sql</code> (e anteriores caso ausentes) manualmente no SQL Editor do Supabase para habilitar gestão comercial avançada, equipe, atividades e propostas.
                </p>
              </div>
              <button
                type="button"
                onClick={() => void copySqlHint()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#15223B] hover:bg-[#1C2D4D] border border-[#24375A] rounded-md shrink-0"
              >
                <Copy className="w-3.5 h-3.5" />
                Copiar referência
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
        active ? 'bg-[#2563EB] text-white' : 'text-[#8FA3C4] hover:text-white'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}
