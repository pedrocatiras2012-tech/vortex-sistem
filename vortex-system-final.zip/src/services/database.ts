import { DEFAULT_PERMISSIONS_BY_ROLE } from '../lib/constants';
import { getSupabaseClient } from '../lib/supabase';
import type {
  ActivityPriority,
  ActivityStatus,
  CommercialProposal,
  Commission,
  CommissionStatus,
  Company,
  CompanyStatus,
  ContactType,
  Expense,
  LeadAssignmentHistory,
  MarketingTask,
  ModulePermissions,
  ParticipatingCollaborator,
  Payment,
  ProposalStatus,
  Prospect,
  ProspectActivity,
  ProspectInteraction,
  ProspectStatus,
  SaleCollaborator,
  SaleParticipationRole,
  SaleStatus,
  ServiceType,
  SystemSettings,
  TaskCategory,
  TaskPriority,
  TaskStatus,
  TeamInvite,
  UserProfile,
  UserRole,
} from '../types';

type AnyRow = Record<string, unknown>;

function str(val: unknown, fallback = ''): string {
  return typeof val === 'string' ? val : val == null ? fallback : String(val);
}

function num(val: unknown, fallback = 0): number {
  const n = Number(val);
  return Number.isFinite(n) ? n : fallback;
}

function isMissingTableError(error: unknown): boolean {
  if (!error || typeof error !== 'object') return false;
  const e = error as { code?: string; message?: string };
  const code = e.code || '';
  const msg = (e.message || '').toLowerCase();
  return (
    code === '42P01' ||
    code === 'PGRST205' ||
    msg.includes('could not find the table') ||
    msg.includes('does not exist')
  );
}

function extractMissingColumn(error: unknown): string | null {
  if (!error || typeof error !== 'object') return null;
  const msg = String((error as { message?: string }).message || '');

  const pgrstMatch = msg.match(/Could not find the '([^']+)' column/i);
  if (pgrstMatch?.[1]) return pgrstMatch[1];

  const pgMatch1 = msg.match(/column "([^"]+)" of relation/i);
  if (pgMatch1?.[1]) return pgMatch1[1];

  const pgMatch2 = msg.match(/column [a-z0-9_]+\.([a-z0-9_]+) does not exist/i);
  if (pgMatch2?.[1]) return pgMatch2[1];

  return null;
}

async function adaptiveInsert(table: string, initialPayload: Record<string, unknown>): Promise<AnyRow> {
  const sb = getSupabaseClient();
  const payload = { ...initialPayload };
  const stripped = new Set<string>();

  for (let attempt = 0; attempt < 35; attempt++) {
    const { data, error } = await sb.from(table).insert(payload).select('*').single();
    if (!error) return data as AnyRow;

    const missingCol = extractMissingColumn(error);
    if (missingCol && missingCol in payload && !stripped.has(missingCol)) {
      stripped.add(missingCol);
      delete payload[missingCol];
      if (Object.keys(payload).length === 0) {
        throw new Error(error.message);
      }
      continue;
    }

    throw new Error(error.message);
  }

  throw new Error(`Não foi possível inserir registro em ${table}.`);
}

async function adaptiveUpdate(
  table: string,
  id: string,
  initialPayload: Record<string, unknown>
): Promise<AnyRow> {
  const sb = getSupabaseClient();
  const payload = { ...initialPayload };
  const stripped = new Set<string>();

  for (let attempt = 0; attempt < 35; attempt++) {
    if (Object.keys(payload).length === 0) {
      const { data, error } = await sb.from(table).select('*').eq('id', id).single();
      if (error) throw new Error(error.message);
      return data as AnyRow;
    }

    const { data, error } = await sb.from(table).update(payload).eq('id', id).select('*').single();
    if (!error) return data as AnyRow;

    const missingCol = extractMissingColumn(error);
    if (missingCol && missingCol in payload && !stripped.has(missingCol)) {
      stripped.add(missingCol);
      delete payload[missingCol];
      continue;
    }

    throw new Error(error.message);
  }

  throw new Error(`Não foi possível atualizar registro em ${table}.`);
}

async function getAuthenticatedUserId(): Promise<string> {
  const sb = getSupabaseClient();
  const { data: sessionData } = await sb.auth.getSession();
  const sessionUserId = sessionData.session?.user?.id;
  if (sessionUserId) return sessionUserId;

  const { data: userData, error } = await sb.auth.getUser();
  if (error || !userData.user?.id) {
    throw new Error('Usuário não autenticado. Faça login novamente para salvar registros.');
  }
  return userData.user.id;
}

export async function verifyBackendAccess(options: {
  requiredModule?: string;
  allowedRoles?: string[];
}): Promise<void> {
  const sb = getSupabaseClient();
  const { data } = await sb.auth.getSession();
  const token = data.session?.access_token;
  if (!token) {
    throw new Error('Sessão expirada. Faça login novamente.');
  }
  const resp = await fetch('/api/auth/verify-access', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(options),
  });
  if (!resp.ok) {
    const body = (await resp.json().catch(() => ({}))) as { error?: string };
    throw new Error(body.error || 'Acesso não autorizado para esta operação.');
  }
}

export function normalizeRole(rawRole: unknown): UserRole {
  const r = str(rawRole).toLowerCase().trim();
  if (r === 'owner' || r === 'proprietario' || r === 'proprietário') return 'proprietario';
  if (r === 'admin' || r === 'administrador') return 'administrador';
  if (r === 'manager' || r === 'gerente') return 'gerente';
  return 'colaborador';
}

export function normalizePermissions(raw: unknown, role: UserRole): ModulePermissions {
  const base = { ...DEFAULT_PERMISSIONS_BY_ROLE[role] };
  if (role === 'proprietario') {
    return { ...DEFAULT_PERMISSIONS_BY_ROLE.proprietario };
  }
  if (raw && typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;
    (Object.keys(base) as (keyof ModulePermissions)[]).forEach((key) => {
      if (typeof obj[key] === 'boolean') {
        base[key] = obj[key] as boolean;
      }
    });
  }
  return base;
}

function mapProfile(row: AnyRow): UserProfile {
  const role = normalizeRole(row.role);
  const rawStatus = str(row.status, 'ativo').toLowerCase();
  return {
    id: str(row.id),
    full_name: str(row.full_name || row.name || row.nome || 'Usuário'),
    email: str(row.email || row.linked_auth_email),
    phone: str(row.phone),
    role,
    job_title: str(row.job_title || row.cargo || (role === 'proprietario' ? 'Proprietário' : 'Colaborador')),
    department: str(row.department),
    responsibilities: str(row.responsibilities),
    entry_date: str(row.entry_date || str(row.created_at).slice(0, 10)),
    custom_role_label: str(row.custom_role_label),
    linked_auth_email: str(row.linked_auth_email || row.email),
    permissions: normalizePermissions(row.permissions, role),
    status: rawStatus === 'inactive' || rawStatus === 'inativo' ? 'inativo' : 'ativo',
    avatar_url: (row.avatar_url as string | null) ?? null,
    created_at: str(row.created_at, new Date().toISOString()),
    updated_at: str(row.updated_at),
  };
}

function mapTeamInvite(row: AnyRow): TeamInvite {
  const role = normalizeRole(row.role);
  const rawStatus = str(row.status, 'pendente').toLowerCase();
  return {
    id: str(row.id),
    full_name: str(row.full_name),
    email: str(row.email),
    phone: str(row.phone),
    role,
    job_title: str(row.job_title, 'Colaborador'),
    department: str(row.department),
    responsibilities: str(row.responsibilities),
    entry_date: str(row.entry_date || str(row.created_at).slice(0, 10)),
    avatar_url: (row.avatar_url as string | null) ?? null,
    permissions: normalizePermissions(row.permissions, role),
    status: rawStatus === 'vinculado' ? 'vinculado' : rawStatus === 'inativo' ? 'inativo' : 'pendente',
    linked_profile_id: (row.linked_profile_id as string | null) ?? null,
    created_by: (row.created_by as string | null) ?? null,
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

function mapProspect(row: AnyRow): Prospect {
  let participating: ParticipatingCollaborator[] = [];
  if (Array.isArray(row.participating_collaborators)) {
    participating = (row.participating_collaborators as AnyRow[])
      .filter((x) => x && typeof x === 'object')
      .map((x) => ({
        id: str(x.id),
        name: str(x.name),
        participation_role: (str(x.participation_role, 'atendimento') as SaleParticipationRole),
      }));
  }

  return {
    id: str(row.id),
    company_name: str(row.company_name || row.company || row.name),
    contact_name: str(row.contact_name || row.responsible || row.contact),
    phone: str(row.phone || row.telefone),
    whatsapp: str(row.whatsapp),
    email: str(row.email),
    city: str(row.city || row.cidade),
    segment: str(row.segment || row.segmento),
    instagram: str(row.instagram),
    website: str(row.website || row.site),
    origin: str(row.origin || row.source || row.origem),
    member_id: (row.member_id as string | null) ?? null,
    responsible_id:
      (row.responsible_id as string | null) ??
      (row.assigned_to as string | null) ??
      (row.member_id as string | null) ??
      null,
    responsible_name: str(row.responsible_name || row.responsible),
    notes: str(row.notes || row.observacoes),
    first_contact_date: str(row.first_contact_date || row.contact_date),
    next_contact_date: str(row.next_contact_date),
    status: (str(row.status, 'novo') as ProspectStatus),
    converted_company_id: (row.converted_company_id as string | null) ?? (row.company_id as string | null) ?? null,
    converted_at: (row.converted_at as string | null) ?? null,
    place_id: (row.place_id as string | null) ?? null,
    state: str(row.state),
    address: str(row.address),
    website_status: str(row.website_status),
    geo_confirmed: typeof row.geo_confirmed === 'boolean' ? row.geo_confirmed : null,
    lead_score: row.lead_score != null ? num(row.lead_score) : null,
    lead_classification: str(row.lead_classification),
    score_justification: str(row.score_justification),
    commercial_opportunities: Array.isArray(row.commercial_opportunities)
      ? (row.commercial_opportunities as string[])
      : str(row.commercial_opportunities),
    google_rating: row.google_rating != null ? num(row.google_rating) : null,
    google_reviews_count: row.google_reviews_count != null ? num(row.google_reviews_count) : null,
    search_date: (row.search_date as string | null) ?? null,
    estimated_value: row.estimated_value != null ? num(row.estimated_value) : null,
    deal_value: row.deal_value != null ? num(row.deal_value) : null,
    contracted_service: (str(row.contracted_service) as ServiceType | ''),
    closed_at: (row.closed_at as string | null) ?? null,
    sale_status: (str(row.sale_status, 'aberta') as SaleStatus),
    loss_reason: str(row.loss_reason),
    next_activity_title: str(row.next_activity_title),
    next_activity_time: str(row.next_activity_time),
    assigned_at: (row.assigned_at as string | null) ?? null,
    assigned_by: (row.assigned_by as string | null) ?? null,
    assigned_by_name: str(row.assigned_by_name),
    assignment_notes: str(row.assignment_notes),
    participating_collaborators: participating,
    last_interaction_at: (row.last_interaction_at as string | null) ?? null,
    created_at: str(row.created_at, new Date().toISOString()),
    updated_at: str(row.updated_at),
  };
}

function mapInteraction(row: AnyRow): ProspectInteraction {
  return {
    id: str(row.id),
    prospect_id: str(row.prospect_id),
    company_id: (row.company_id as string | null) ?? null,
    contact_at: str(row.contact_at || row.contact_date || row.interaction_date || row.created_at, new Date().toISOString()),
    contact_type: (str(row.contact_type || row.channel || row.type, 'whatsapp') as ContactType),
    summary: str(row.summary || row.message || row.notes || row.description),
    responsible_id: (row.responsible_id as string | null) ?? null,
    responsible_name: str(row.responsible_name),
    outcome: str(row.outcome || row.result || row.resultado),
    next_action: str(row.next_action || row.proxima_acao),
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

function mapActivity(row: AnyRow): ProspectActivity {
  return {
    id: str(row.id),
    prospect_id: str(row.prospect_id),
    title: str(row.title),
    description: str(row.description),
    due_date: str(row.due_date),
    due_time: str(row.due_time),
    responsible_id: (row.responsible_id as string | null) ?? null,
    responsible_name: str(row.responsible_name),
    priority: (str(row.priority, 'media') as ActivityPriority),
    status: (str(row.status, 'pendente') as ActivityStatus),
    completion_outcome: str(row.completion_outcome),
    completed_at: (row.completed_at as string | null) ?? null,
    created_by: (row.created_by as string | null) ?? null,
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

function mapProposal(row: AnyRow): CommercialProposal {
  return {
    id: str(row.id),
    prospect_id: str(row.prospect_id),
    company_id: (row.company_id as string | null) ?? null,
    title: str(row.title),
    service_type: (str(row.service_type, 'presenca_digital') as ServiceType),
    value: num(row.value, 0),
    sent_date: str(row.sent_date, str(row.created_at).slice(0, 10)),
    valid_until: (row.valid_until as string | null) ?? null,
    responsible_id: (row.responsible_id as string | null) ?? null,
    responsible_name: str(row.responsible_name),
    status: (str(row.status, 'em_preparacao') as ProposalStatus),
    viewed_confirmed_at: (row.viewed_confirmed_at as string | null) ?? null,
    notes: str(row.notes),
    created_at: str(row.created_at, new Date().toISOString()),
    updated_at: str(row.updated_at),
  };
}

function mapAssignmentHistory(row: AnyRow): LeadAssignmentHistory {
  return {
    id: str(row.id),
    prospect_id: str(row.prospect_id),
    previous_responsible_id: (row.previous_responsible_id as string | null) ?? null,
    previous_responsible_name: str(row.previous_responsible_name),
    new_responsible_id: (row.new_responsible_id as string | null) ?? null,
    new_responsible_name: str(row.new_responsible_name),
    assigned_by: (row.assigned_by as string | null) ?? null,
    assigned_by_name: str(row.assigned_by_name),
    notes: str(row.notes),
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

function mapSaleCollaborator(row: AnyRow): SaleCollaborator {
  return {
    id: str(row.id),
    prospect_id: (row.prospect_id as string | null) ?? null,
    company_id: (row.company_id as string | null) ?? null,
    collaborator_id: (row.collaborator_id as string | null) ?? null,
    collaborator_name: str(row.collaborator_name),
    participation_role: (str(row.participation_role, 'fechamento') as SaleParticipationRole),
    commission_id: (row.commission_id as string | null) ?? null,
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

function mapCompany(row: AnyRow): Company {
  return {
    id: str(row.id),
    name: str(row.name || row.company_name || row.nome),
    contact_name: str(row.contact_name || row.responsible_name || row.responsavel),
    phone: str(row.phone || row.telefone),
    whatsapp: str(row.whatsapp),
    email: str(row.email),
    cnpj: str(row.cnpj),
    city: str(row.city || row.cidade),
    segment: str(row.segment || row.segmento),
    entry_date: str(row.entry_date || row.start_date || str(row.created_at).slice(0, 10)),
    contracted_service: (str(row.contracted_service || row.service, 'outros') as ServiceType),
    contract_value: num(row.contract_value ?? row.value ?? row.monthly_value, 0),
    responsible_id: (row.responsible_id as string | null) ?? null,
    responsible_name: str(row.responsible_name),
    status: (str(row.status, 'ativo') as CompanyStatus),
    origin: str(row.origin || row.source),
    prospect_id: (row.prospect_id as string | null) ?? null,
    notes: str(row.notes || row.observacoes),
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

function mapCommission(row: AnyRow): Commission {
  const hasExplicitSale = row.sale_value !== undefined && row.sale_value !== null;
  const saleValue = hasExplicitSale ? num(row.sale_value) : num(row.commission_value ?? row.amount ?? 0);
  const pct = num(row.commission_percentage ?? row.percentage ?? 0);
  const commValue = num(
    row.commission_value ?? row.value ?? (hasExplicitSale ? (saleValue * pct) / 100 : row.amount ?? 0)
  );
  return {
    id: str(row.id),
    collaborator_id: (row.collaborator_id as string | null) ?? (row.user_id as string | null) ?? null,
    collaborator_name: str(row.collaborator_name),
    company_id: (row.company_id as string | null) ?? null,
    company_name: str(row.company_name),
    prospect_id: (row.prospect_id as string | null) ?? null,
    participation_role: (str(row.participation_role) as SaleParticipationRole | ''),
    description: str(row.description),
    sale_value: saleValue,
    commission_percentage: pct,
    commission_value: commValue,
    status: (str(row.status, 'pendente') as CommissionStatus),
    notes: str(row.notes),
    created_at: str(row.created_at, new Date().toISOString()),
    paid_at: (row.paid_at as string | null) ?? (row.payment_date as string | null) ?? null,
  };
}

function mapPayment(row: AnyRow): Payment {
  return {
    id: str(row.id),
    description: str(row.description || row.title || row.notes || 'Receita'),
    company_id: (row.company_id as string | null) ?? null,
    company_name: str(row.company_name),
    amount: num(row.amount ?? row.value),
    payment_date: str(row.payment_date || row.paid_at || row.date || str(row.created_at).slice(0, 10)),
    category: str(row.category, 'Mensalidade'),
    status: (str(row.status, 'recebido') as Payment['status']),
    notes: str(row.notes),
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

function mapExpense(row: AnyRow): Expense {
  return {
    id: str(row.id),
    description: str(row.description || row.title),
    category: str(row.category, 'Operacional / Escritório'),
    amount: num(row.amount ?? row.value),
    expense_date: str(row.expense_date || row.date || str(row.created_at).slice(0, 10)),
    responsible_id: (row.responsible_id as string | null) ?? null,
    responsible_name: str(row.responsible_name),
    notes: str(row.notes),
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

function mapTask(row: AnyRow): MarketingTask {
  return {
    id: str(row.id),
    title: str(row.title || row.name),
    description: str(row.description),
    category: (str(row.category, 'marketing') as TaskCategory),
    responsible_id: (row.responsible_id as string | null) ?? (row.assigned_to as string | null) ?? null,
    responsible_name: str(row.responsible_name),
    due_date: str(row.due_date),
    priority: (str(row.priority, 'media') as TaskPriority),
    status: (str(row.status, 'pendente') as TaskStatus),
    completed_at: (row.completed_at as string | null) ?? null,
    created_at: str(row.created_at, new Date().toISOString()),
  };
}

// ============================================================================
// PROFILES, TEAM & AVATARS
// ============================================================================

export async function fetchCurrentProfile(userId: string): Promise<UserProfile | null> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('profiles').select('*').eq('id', userId).maybeSingle();
  if (error) throw new Error(error.message);
  return data ? mapProfile(data as AnyRow) : null;
}

export async function ensureUserProfile(user: {
  id: string;
  email?: string;
  user_metadata?: Record<string, unknown>;
}): Promise<UserProfile> {
  const sb = getSupabaseClient();
  const existing = await fetchCurrentProfile(user.id);
  if (existing) {
    // Best-effort claim pending team invite if email matches (non-destructive)
    try {
      const { data: claimRes } = await sb.rpc('vortex_claim_team_invite');
      if (claimRes && (claimRes as { claimed?: boolean }).claimed) {
        const refreshed = await fetchCurrentProfile(user.id);
        if (refreshed) return refreshed;
      }
    } catch {
      // RPC may not exist before migration 004; ignore safely
    }
    return existing;
  }

  const fullName =
    str(user.user_metadata?.full_name) ||
    str(user.user_metadata?.name) ||
    (user.email ? user.email.split('@')[0] : 'Novo Usuário');

  const payload: Record<string, unknown> = {
    id: user.id,
    full_name: fullName,
    email: user.email || '',
    role: 'colaborador',
    job_title: 'Colaborador',
    permissions: DEFAULT_PERMISSIONS_BY_ROLE.colaborador,
    status: 'ativo',
  };

  for (let attempt = 0; attempt < 12; attempt++) {
    const { data, error } = await sb.from('profiles').upsert(payload).select('*').single();
    if (!error) {
      try {
        await sb.rpc('vortex_claim_team_invite');
        const claimed = await fetchCurrentProfile(user.id);
        if (claimed) return claimed;
      } catch {
        // Ignore before migration 004
      }
      return mapProfile(data as AnyRow);
    }

    const missingCol = extractMissingColumn(error);
    if (missingCol && missingCol in payload && missingCol !== 'id') {
      delete payload[missingCol];
      continue;
    }
    throw new Error(error.message);
  }

  throw new Error('Não foi possível inicializar o perfil do usuário.');
}

export async function fetchProfiles(): Promise<UserProfile[]> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('profiles').select('*').order('created_at', { ascending: true });
  if (error) throw new Error(error.message);
  return (data || []).map((r) => mapProfile(r as AnyRow));
}

export async function updateOwnProfile(
  userId: string,
  updates: {
    full_name: string;
    job_title: string;
    phone?: string;
    avatar_url?: string | null;
  }
): Promise<UserProfile> {
  // Never send role, status, or permissions from self-update to prevent privilege escalation
  const payload: Record<string, unknown> = {
    full_name: updates.full_name.trim(),
    job_title: updates.job_title.trim(),
    updated_at: new Date().toISOString(),
  };
  if (updates.phone !== undefined) payload.phone = updates.phone.trim();
  if (updates.avatar_url !== undefined) payload.avatar_url = updates.avatar_url;

  const row = await adaptiveUpdate('profiles', userId, payload);
  return mapProfile(row);
}

export async function updateCollaboratorProfile(
  actorProfile: UserProfile,
  targetUserId: string,
  updates: {
    full_name: string;
    email: string;
    phone?: string;
    job_title: string;
    department?: string;
    responsibilities?: string;
    entry_date?: string;
    avatar_url?: string | null;
    role: UserRole;
    permissions: ModulePermissions;
    status: 'ativo' | 'inativo';
  }
): Promise<UserProfile> {
  const canManageTeam =
    actorProfile.role === 'proprietario' ||
    actorProfile.role === 'administrador' ||
    Boolean(actorProfile.permissions?.equipe);

  if (!canManageTeam) {
    throw new Error('Você não tem permissão para gerenciar colaboradores.');
  }

  await verifyBackendAccess({
    allowedRoles: ['proprietario', 'administrador'],
  });

  if (targetUserId === actorProfile.id && updates.role !== actorProfile.role) {
    throw new Error('Não é possível alterar seu próprio nível de acesso.');
  }

  const row = await adaptiveUpdate('profiles', targetUserId, {
    full_name: updates.full_name.trim(),
    email: updates.email.trim(),
    phone: updates.phone?.trim() || '',
    job_title: updates.job_title.trim(),
    department: updates.department?.trim() || '',
    responsibilities: updates.responsibilities?.trim() || '',
    entry_date: updates.entry_date || null,
    avatar_url: updates.avatar_url ?? null,
    role: updates.role,
    permissions:
      updates.role === 'proprietario' ? DEFAULT_PERMISSIONS_BY_ROLE.proprietario : updates.permissions,
    status: updates.status,
    updated_at: new Date().toISOString(),
  });
  return mapProfile(row);
}

export async function updateTeamMemberAccess(
  actorProfile: UserProfile,
  targetUserId: string,
  updates: {
    role: UserRole;
    permissions: ModulePermissions;
    status: 'ativo' | 'inativo';
    job_title: string;
    department?: string;
    responsibilities?: string;
  }
): Promise<UserProfile> {
  if (actorProfile.role !== 'proprietario' && actorProfile.role !== 'administrador') {
    throw new Error('Apenas proprietário ou administrador pode gerenciar cargos e permissões da equipe.');
  }

  await verifyBackendAccess({
    allowedRoles: ['proprietario', 'administrador'],
  });

  if (targetUserId === actorProfile.id && updates.role !== actorProfile.role) {
    throw new Error('Não é possível rebaixar seu próprio nível de acesso.');
  }

  const payload: Record<string, unknown> = {
    role: updates.role,
    permissions:
      updates.role === 'proprietario' ? DEFAULT_PERMISSIONS_BY_ROLE.proprietario : updates.permissions,
    status: updates.status,
    job_title: updates.job_title.trim(),
    updated_at: new Date().toISOString(),
  };
  if (updates.department !== undefined) payload.department = updates.department.trim();
  if (updates.responsibilities !== undefined) payload.responsibilities = updates.responsibilities.trim();

  const row = await adaptiveUpdate('profiles', targetUserId, payload);
  return mapProfile(row);
}

export async function uploadCollaboratorAvatar(file: File, targetId: string): Promise<string> {
  const sb = getSupabaseClient();
  const ext = (file.name.split('.').pop() || 'png').toLowerCase().replace(/[^a-z0-9]/g, '');
  const path = `${targetId}/${Date.now()}.${ext || 'png'}`;

  const { error: uploadError } = await sb.storage
    .from('avatars')
    .upload(path, file, { upsert: true, contentType: file.type || 'image/png' });

  if (uploadError) {
    throw new Error(
      `Não foi possível enviar para o Supabase Storage ("avatars"): ${uploadError.message}. Verifique se o bucket público "avatars" existe ou informe uma URL de imagem.`
    );
  }

  const { data: urlData } = sb.storage.from('avatars').getPublicUrl(path);
  return urlData.publicUrl;
}

export async function fetchTeamInvites(): Promise<{ items: TeamInvite[]; tableMissing: boolean }> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('team_invites').select('*').order('created_at', { ascending: false });
  if (error) {
    if (isMissingTableError(error)) {
      return { items: [], tableMissing: true };
    }
    return { items: [], tableMissing: false };
  }
  return { items: (data || []).map((r) => mapTeamInvite(r as AnyRow)), tableMissing: false };
}

export async function createTeamInvite(
  actorProfile: UserProfile,
  input: Omit<TeamInvite, 'id' | 'created_at' | 'created_by'>
): Promise<TeamInvite> {
  if (actorProfile.role !== 'proprietario' && actorProfile.role !== 'administrador') {
    throw new Error('Apenas proprietário ou administrador pode cadastrar novos colaboradores.');
  }
  await verifyBackendAccess({ allowedRoles: ['proprietario', 'administrador'] });

  const row = await adaptiveInsert('team_invites', {
    full_name: input.full_name.trim(),
    email: input.email.trim().toLowerCase(),
    phone: input.phone?.trim() || '',
    role: input.role,
    job_title: input.job_title.trim(),
    department: input.department?.trim() || '',
    responsibilities: input.responsibilities?.trim() || '',
    entry_date: input.entry_date || null,
    avatar_url: input.avatar_url ?? null,
    permissions:
      input.role === 'proprietario' ? DEFAULT_PERMISSIONS_BY_ROLE.proprietario : input.permissions,
    status: input.linked_profile_id ? 'vinculado' : input.status || 'pendente',
    linked_profile_id: input.linked_profile_id || null,
    created_by: actorProfile.id,
  });

  if (input.linked_profile_id) {
    await updateCollaboratorProfile(actorProfile, input.linked_profile_id, {
      full_name: input.full_name,
      email: input.email,
      phone: input.phone,
      job_title: input.job_title,
      department: input.department,
      responsibilities: input.responsibilities,
      entry_date: input.entry_date,
      avatar_url: input.avatar_url,
      role: input.role,
      permissions: input.permissions,
      status: 'ativo',
    });
  }

  return mapTeamInvite(row);
}

export async function updateTeamInvite(
  actorProfile: UserProfile,
  inviteId: string,
  updates: Partial<Omit<TeamInvite, 'id' | 'created_at'>>
): Promise<TeamInvite> {
  if (actorProfile.role !== 'proprietario' && actorProfile.role !== 'administrador') {
    throw new Error('Apenas proprietário ou administrador pode atualizar convites de colaboradores.');
  }
  await verifyBackendAccess({ allowedRoles: ['proprietario', 'administrador'] });

  const row = await adaptiveUpdate('team_invites', inviteId, {
    ...updates,
    updated_at: new Date().toISOString(),
  } as Record<string, unknown>);
  return mapTeamInvite(row);
}

// ============================================================================
// PROSPECTS, ACTIVITIES, PROPOSALS & ASSIGNMENTS
// ============================================================================

export async function fetchProspects(): Promise<{ items: Prospect[]; tableMissing: boolean }> {
  const sb = getSupabaseClient();
  const { data, error } = await sb
    .from('prospects')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    if (isMissingTableError(error)) {
      return { items: [], tableMissing: true };
    }
    throw new Error(error.message);
  }
  return { items: (data || []).map((r) => mapProspect(r as AnyRow)), tableMissing: false };
}

export async function createProspect(
  input: Omit<Prospect, 'id' | 'created_at' | 'updated_at'>
): Promise<Prospect> {
  const authUserId = await getAuthenticatedUserId();
  // Preserve explicit unassigned choice only if caller passed responsible_id === null explicitly AND DB allows;
  // note: member_id ALWAYS tracks authUserId to satisfy NOT NULL constraint safely.
  const effectiveResponsibleId =
    input.responsible_id === undefined
      ? authUserId
      : input.responsible_id && input.responsible_id.trim()
        ? input.responsible_id.trim()
        : null;

  const payload: Record<string, unknown> = {
    company_name: input.company_name.trim(),
    contact_name: input.contact_name.trim(),
    phone: input.phone.trim(),
    whatsapp: input.whatsapp.trim(),
    email: input.email?.trim() || null,
    city: input.city.trim(),
    segment: input.segment.trim(),
    instagram: input.instagram.trim(),
    website: input.website.trim(),
    origin: input.origin.trim(),
    source: input.origin.trim(),
    member_id: authUserId,
    created_by: authUserId,
    responsible_id: effectiveResponsibleId,
    responsible_name: input.responsible_name.trim(),
    notes: input.notes.trim(),
    first_contact_date: input.first_contact_date || null,
    contact_date: input.first_contact_date || null,
    next_contact_date: input.next_contact_date || null,
    status: input.status,
  };

  if (input.place_id) payload.place_id = input.place_id.trim();
  if (input.state) payload.state = input.state.trim();
  if (input.address) payload.address = input.address.trim();
  if (input.website_status) payload.website_status = input.website_status;
  if (typeof input.geo_confirmed === 'boolean') payload.geo_confirmed = input.geo_confirmed;
  if (typeof input.lead_score === 'number') payload.lead_score = input.lead_score;
  if (input.lead_classification) payload.lead_classification = input.lead_classification;
  if (input.score_justification) payload.score_justification = input.score_justification;
  if (input.commercial_opportunities) {
    payload.commercial_opportunities = Array.isArray(input.commercial_opportunities)
      ? input.commercial_opportunities.join('\n')
      : input.commercial_opportunities;
  }
  if (typeof input.google_rating === 'number') payload.google_rating = input.google_rating;
  if (typeof input.google_reviews_count === 'number') payload.google_reviews_count = input.google_reviews_count;
  if (input.search_date) payload.search_date = input.search_date;
  if (typeof input.estimated_value === 'number') payload.estimated_value = input.estimated_value;
  if (input.next_activity_title) payload.next_activity_title = input.next_activity_title.trim();
  if (input.next_activity_time) payload.next_activity_time = input.next_activity_time.trim();
  if (effectiveResponsibleId) {
    payload.assigned_at = new Date().toISOString();
    payload.assigned_by = authUserId;
  }

  const row = await adaptiveInsert('prospects', payload);
  return mapProspect(row);
}

export async function updateProspect(
  id: string,
  updates: Partial<Omit<Prospect, 'id' | 'created_at'>>
): Promise<Prospect> {
  const payload: Record<string, unknown> = {
    ...updates,
    updated_at: new Date().toISOString(),
  };

  if (updates.origin !== undefined) {
    payload.source = updates.origin;
  }
  if (updates.first_contact_date !== undefined) {
    payload.first_contact_date = updates.first_contact_date || null;
    payload.contact_date = updates.first_contact_date || null;
  }
  if (updates.next_contact_date !== undefined) {
    payload.next_contact_date = updates.next_contact_date || null;
  }
  if (updates.closed_at !== undefined) {
    payload.closed_at = updates.closed_at || null;
  }
  if (updates.converted_company_id !== undefined) {
    payload.company_id = updates.converted_company_id;
  }

  const row = await adaptiveUpdate('prospects', id, payload);
  return mapProspect(row);
}

export async function deleteProspect(id: string): Promise<void> {
  const sb = getSupabaseClient();
  const { error } = await sb.from('prospects').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

export async function assignOrTransferProspect(params: {
  prospect: Prospect;
  newResponsibleId: string | null;
  newResponsibleName: string;
  actor: UserProfile;
  notes?: string;
  participatingCollaborators?: ParticipatingCollaborator[];
}): Promise<Prospect> {
  const isTransfer =
    Boolean(params.prospect.responsible_id) &&
    params.prospect.responsible_id !== params.newResponsibleId;

  const canDistribute =
    params.actor.role === 'proprietario' ||
    params.actor.role === 'administrador' ||
    params.actor.role === 'gerente' ||
    Boolean(params.actor.permissions?.distribuir_leads);

  if (!canDistribute && params.newResponsibleId !== params.actor.id) {
    throw new Error('Você não possui permissão para distribuir ou transferir leads para outro colaborador.');
  }

  const nowIso = new Date().toISOString();
  const updated = await updateProspect(params.prospect.id, {
    responsible_id: params.newResponsibleId,
    responsible_name: params.newResponsibleName,
    assigned_at: nowIso,
    assigned_by: params.actor.id,
    assigned_by_name: params.actor.full_name,
    assignment_notes: params.notes?.trim() || '',
    participating_collaborators:
      params.participatingCollaborators ?? params.prospect.participating_collaborators ?? [],
  });

  // Record assignment audit entry cleanly (ignore gracefully if migration 004 missing)
  try {
    await adaptiveInsert('lead_assignments_history', {
      prospect_id: params.prospect.id,
      previous_responsible_id: params.prospect.responsible_id || null,
      previous_responsible_name: params.prospect.responsible_name || 'Sem responsável',
      new_responsible_id: params.newResponsibleId || null,
      new_responsible_name: params.newResponsibleName || 'Sem responsável',
      assigned_by: params.actor.id,
      assigned_by_name: params.actor.full_name,
      notes: params.notes?.trim() || '',
    });
  } catch {
    // Non-blocking if migration 004 hasn't been applied yet
  }

  // Also log to interaction timeline so history preserves responsibility shifts
  try {
    await createProspectInteraction({
      prospect_id: params.prospect.id,
      company_id: params.prospect.converted_company_id || null,
      contact_at: nowIso,
      contact_type: 'observacao_interna',
      summary: isTransfer
        ? `Lead transferido de "${params.prospect.responsible_name || 'Sem responsável'}" para "${params.newResponsibleName || 'Sem responsável'}".${params.notes ? ` Obs: ${params.notes}` : ''}`
        : `Lead atribuído para "${params.newResponsibleName || 'Sem responsável'}".${params.notes ? ` Obs: ${params.notes}` : ''}`,
      responsible_id: params.actor.id,
      responsible_name: params.actor.full_name,
      outcome: 'Alteração de responsabilidade',
      next_action: '',
    });
  } catch {
    // Non-blocking
  }

  return updated;
}

export async function fetchLeadAssignmentsHistory(prospectId?: string): Promise<LeadAssignmentHistory[]> {
  const sb = getSupabaseClient();
  let query = sb
    .from('lead_assignments_history')
    .select('*')
    .order('created_at', { ascending: false });
  if (prospectId) query = query.eq('prospect_id', prospectId);
  const { data, error } = await query;
  if (error) return [];
  return (data || []).map((r) => mapAssignmentHistory(r as AnyRow));
}

export async function fetchProspectInteractions(prospectId?: string): Promise<{
  items: ProspectInteraction[];
  source: 'prospect_interactions' | 'prospecting_logs' | 'missing';
}> {
  const sb = getSupabaseClient();
  let query = sb.from('prospect_interactions').select('*').order('contact_at', { ascending: false });
  if (prospectId) query = query.eq('prospect_id', prospectId);

  const { data, error } = await query;
  if (!error) {
    return {
      items: (data || []).map((r) => mapInteraction(r as AnyRow)),
      source: 'prospect_interactions',
    };
  }

  if (isMissingTableError(error)) {
    let logQuery = sb.from('prospecting_logs').select('*').order('created_at', { ascending: false });
    if (prospectId) logQuery = logQuery.eq('prospect_id', prospectId);
    const { data: logs, error: logError } = await logQuery;
    if (!logError) {
      return {
        items: (logs || []).map((r) => mapInteraction(r as AnyRow)),
        source: 'prospecting_logs',
      };
    }
    return { items: [], source: 'missing' };
  }

  throw new Error(error.message);
}

export async function createProspectInteraction(
  input: Omit<ProspectInteraction, 'id' | 'created_at'>
): Promise<ProspectInteraction> {
  const authUserId = await getAuthenticatedUserId();
  const contactAt = input.contact_at || new Date().toISOString();
  const payload: Record<string, unknown> = {
    prospect_id: input.prospect_id,
    company_id: input.company_id || null,
    contact_at: contactAt,
    contact_type: input.contact_type,
    channel: input.contact_type,
    summary: input.summary.trim(),
    member_id: authUserId,
    responsible_id: input.responsible_id || authUserId,
    responsible_name: input.responsible_name.trim(),
    outcome: input.outcome.trim(),
    next_action: input.next_action.trim(),
  };

  let created: ProspectInteraction;
  try {
    const row = await adaptiveInsert('prospect_interactions', payload);
    created = mapInteraction(row);
  } catch (err) {
    if (isMissingTableError(err)) {
      const logRow = await adaptiveInsert('prospecting_logs', payload);
      created = mapInteraction(logRow);
    } else {
      throw err;
    }
  }

  // Update last_interaction_at on parent prospect (non-blocking if column missing)
  try {
    await adaptiveUpdate('prospects', input.prospect_id, {
      last_interaction_at: contactAt,
      updated_at: new Date().toISOString(),
    });
  } catch {
    // Ignore
  }

  return created;
}

// ============================================================================
// PROSPECT COMMERCIAL ACTIVITIES (TASKS & REMINDERS)
// ============================================================================

export async function fetchProspectActivities(prospectId?: string): Promise<{
  items: ProspectActivity[];
  tableMissing: boolean;
}> {
  const sb = getSupabaseClient();
  let query = sb
    .from('prospect_activities')
    .select('*')
    .order('due_date', { ascending: true });
  if (prospectId) query = query.eq('prospect_id', prospectId);

  const { data, error } = await query;
  if (error) {
    if (isMissingTableError(error)) {
      return { items: [], tableMissing: true };
    }
    return { items: [], tableMissing: false };
  }
  return { items: (data || []).map((r) => mapActivity(r as AnyRow)), tableMissing: false };
}

export async function createProspectActivity(
  input: Omit<ProspectActivity, 'id' | 'created_at' | 'completed_at'>
): Promise<ProspectActivity> {
  const authUserId = await getAuthenticatedUserId();
  const row = await adaptiveInsert('prospect_activities', {
    prospect_id: input.prospect_id,
    title: input.title.trim(),
    description: input.description.trim(),
    due_date: input.due_date,
    due_time: input.due_time?.trim() || '',
    responsible_id: input.responsible_id || authUserId,
    responsible_name: input.responsible_name.trim(),
    priority: input.priority,
    status: input.status || 'pendente',
    created_by: authUserId,
  });

  // Sync next_activity / next_contact_date on parent prospect cleanly
  try {
    await adaptiveUpdate('prospects', input.prospect_id, {
      next_contact_date: input.due_date,
      next_activity_title: input.title.trim(),
      next_activity_time: input.due_time?.trim() || '',
      updated_at: new Date().toISOString(),
    });
  } catch {
    // Non-blocking
  }

  return mapActivity(row);
}

export async function completeProspectActivity(
  activity: ProspectActivity,
  outcome: string
): Promise<ProspectActivity> {
  const nowIso = new Date().toISOString();
  const row = await adaptiveUpdate('prospect_activities', activity.id, {
    status: 'concluida',
    completion_outcome: outcome.trim(),
    completed_at: nowIso,
  });

  // Log completion as real interaction on the lead timeline
  try {
    await createProspectInteraction({
      prospect_id: activity.prospect_id,
      company_id: null,
      contact_at: nowIso,
      contact_type: 'observacao_interna',
      summary: `Atividade concluída: "${activity.title}"`,
      responsible_id: activity.responsible_id,
      responsible_name: activity.responsible_name || 'Equipe',
      outcome: outcome.trim() || 'Concluída',
      next_action: '',
    });
  } catch {
    // Non-blocking
  }

  return mapActivity(row);
}

export async function deleteProspectActivity(id: string): Promise<void> {
  const sb = getSupabaseClient();
  const { error } = await sb.from('prospect_activities').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

// ============================================================================
// COMMERCIAL PROPOSALS
// ============================================================================

export async function fetchCommercialProposals(prospectId?: string): Promise<{
  items: CommercialProposal[];
  tableMissing: boolean;
}> {
  const sb = getSupabaseClient();
  let query = sb
    .from('commercial_proposals')
    .select('*')
    .order('created_at', { ascending: false });
  if (prospectId) query = query.eq('prospect_id', prospectId);

  const { data, error } = await query;
  if (error) {
    if (isMissingTableError(error)) {
      return { items: [], tableMissing: true };
    }
    return { items: [], tableMissing: false };
  }
  return { items: (data || []).map((r) => mapProposal(r as AnyRow)), tableMissing: false };
}

export async function createCommercialProposal(
  input: Omit<CommercialProposal, 'id' | 'created_at' | 'updated_at'>
): Promise<CommercialProposal> {
  const authUserId = await getAuthenticatedUserId();
  const row = await adaptiveInsert('commercial_proposals', {
    prospect_id: input.prospect_id,
    company_id: input.company_id || null,
    title: input.title.trim(),
    service_type: input.service_type,
    value: Number(input.value) || 0,
    sent_date: input.sent_date,
    valid_until: input.valid_until || null,
    responsible_id: input.responsible_id || authUserId,
    responsible_name: input.responsible_name.trim(),
    status: input.status,
    viewed_confirmed_at: input.status === 'visualizada' ? input.viewed_confirmed_at || new Date().toISOString() : null,
    notes: input.notes?.trim() || '',
  });

  // Update estimated_value on prospect if not set yet and log proposal in history
  try {
    await adaptiveUpdate('prospects', input.prospect_id, {
      estimated_value: Number(input.value) || 0,
      updated_at: new Date().toISOString(),
    });
    if (input.status === 'enviada') {
      await createProspectInteraction({
        prospect_id: input.prospect_id,
        company_id: input.company_id || null,
        contact_at: new Date().toISOString(),
        contact_type: 'proposta_enviada',
        summary: `Proposta comercial "${input.title.trim()}" enviada (${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(input.value) || 0)}).`,
        responsible_id: input.responsible_id || authUserId,
        responsible_name: input.responsible_name.trim(),
        outcome: 'Proposta enviada',
        next_action: '',
      });
    }
  } catch {
    // Non-blocking
  }

  return mapProposal(row);
}

export async function updateCommercialProposal(
  id: string,
  updates: Partial<Omit<CommercialProposal, 'id' | 'created_at'>>
): Promise<CommercialProposal> {
  const payload: Record<string, unknown> = {
    ...updates,
    updated_at: new Date().toISOString(),
  };
  if (updates.status === 'visualizada' && !updates.viewed_confirmed_at) {
    payload.viewed_confirmed_at = new Date().toISOString();
  }
  const row = await adaptiveUpdate('commercial_proposals', id, payload);
  return mapProposal(row);
}

export async function deleteCommercialProposal(id: string): Promise<void> {
  const sb = getSupabaseClient();
  const { error } = await sb.from('commercial_proposals').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

// ============================================================================
// SALE COLLABORATORS & CONTROLLED DEAL CLOSING / CONVERSION
// ============================================================================

export async function fetchSaleCollaborators(): Promise<SaleCollaborator[]> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('sale_collaborators').select('*').order('created_at', { ascending: false });
  if (error) return [];
  return (data || []).map((r) => mapSaleCollaborator(r as AnyRow));
}

export async function convertProspectToCompany(
  prospect: Prospect,
  companyInput: {
    name: string;
    contact_name: string;
    phone: string;
    whatsapp: string;
    email: string;
    cnpj: string;
    city: string;
    segment: string;
    entry_date: string;
    contracted_service: ServiceType;
    contract_value: number;
    responsible_id: string | null;
    responsible_name: string;
    status: CompanyStatus;
    notes: string;
    participating_collaborators?: ParticipatingCollaborator[];
    commission_entries?: Array<{
      collaborator_id: string;
      collaborator_name: string;
      participation_role: SaleParticipationRole;
      commission_percentage: number;
      status: 'prevista' | 'pendente' | 'aprovada';
    }>;
  }
): Promise<{ company: Company; prospect: Prospect }> {
  const sb = getSupabaseClient();

  if (prospect.status === 'convertido' && prospect.converted_company_id) {
    throw new Error('Este prospect já foi convertido anteriormente em empresa.');
  }

  const normalizedName = companyInput.name.trim().toLowerCase();
  const { data: allCompanies } = await sb.from('companies').select('*');
  const duplicate = (allCompanies || []).find((c: AnyRow) => {
    const existingProspectId = str(c.prospect_id);
    if (existingProspectId && existingProspectId === prospect.id) return true;
    const existingName = str(c.name || c.company_name).trim().toLowerCase();
    const existingCnpj = str(c.cnpj).replace(/\D/g, '');
    const newCnpj = companyInput.cnpj.replace(/\D/g, '');
    if (existingName && existingName === normalizedName) return true;
    if (newCnpj && existingCnpj && existingCnpj === newCnpj) return true;
    return false;
  });

  if (duplicate) {
    throw new Error(
      `Já existe uma empresa cadastrada com o mesmo nome, CNPJ ou vínculo (${str((duplicate as AnyRow).name)}). Evite duplicações.`
    );
  }

  const saleValue = Number(companyInput.contract_value) || 0;

  const createdCompanyRow = await adaptiveInsert('companies', {
    name: companyInput.name.trim(),
    contact_name: companyInput.contact_name.trim(),
    phone: companyInput.phone.trim(),
    whatsapp: companyInput.whatsapp.trim(),
    email: companyInput.email.trim(),
    cnpj: companyInput.cnpj.trim(),
    city: companyInput.city.trim(),
    segment: companyInput.segment.trim(),
    entry_date: companyInput.entry_date,
    contracted_service: companyInput.contracted_service,
    contract_value: saleValue,
    responsible_id: companyInput.responsible_id || null,
    responsible_name: companyInput.responsible_name.trim(),
    status: companyInput.status,
    origin: prospect.origin || 'Prospecção',
    prospect_id: prospect.id,
    notes: companyInput.notes.trim(),
  });
  const company = mapCompany(createdCompanyRow);

  await sb
    .from('prospect_interactions')
    .update({ company_id: company.id })
    .eq('prospect_id', prospect.id);

  // Create commissions cleanly without duplicating existing prospect commissions or marking paid_at
  const createdCommissionsMap = new Map<string, string>();
  if (Array.isArray(companyInput.commission_entries) && companyInput.commission_entries.length > 0 && saleValue > 0) {
    const { data: existingComms } = await sb
      .from('commissions')
      .select('id,collaborator_id,participation_role,prospect_id,company_id')
      .eq('prospect_id', prospect.id);

    for (const entry of companyInput.commission_entries) {
      if (!entry.collaborator_id || entry.commission_percentage <= 0) continue;
      const alreadyExists = (existingComms || []).some(
        (ec: AnyRow) =>
          str(ec.collaborator_id) === entry.collaborator_id &&
          str(ec.participation_role) === entry.participation_role
      );
      if (alreadyExists) continue;

      const comm = await createCommission({
        collaborator_id: entry.collaborator_id,
        collaborator_name: entry.collaborator_name,
        company_id: company.id,
        company_name: company.name,
        prospect_id: prospect.id,
        participation_role: entry.participation_role,
        description: `Fechamento ${company.name} (${entry.participation_role})`,
        sale_value: saleValue,
        commission_percentage: entry.commission_percentage,
        status: entry.status,
        paid_at: null,
      });
      createdCommissionsMap.set(`${entry.collaborator_id}:${entry.participation_role}`, comm.id);
    }
  }

  // Persist sale_collaborators cleanly (non-blocking if migration 004 missing)
  if (Array.isArray(companyInput.participating_collaborators)) {
    for (const part of companyInput.participating_collaborators) {
      if (!part.id) continue;
      try {
        await adaptiveInsert('sale_collaborators', {
          prospect_id: prospect.id,
          company_id: company.id,
          collaborator_id: part.id,
          collaborator_name: part.name,
          participation_role: part.participation_role,
          commission_id: createdCommissionsMap.get(`${part.id}:${part.participation_role}`) || null,
        });
      } catch {
        // Non-blocking before migration 004
      }
    }
  }

  const updatedProspectRow = await adaptiveUpdate('prospects', prospect.id, {
    status: 'convertido',
    sale_status: 'ganha',
    deal_value: saleValue,
    estimated_value: saleValue,
    contracted_service: companyInput.contracted_service,
    closed_at: companyInput.entry_date,
    converted_company_id: company.id,
    company_id: company.id,
    converted_at: new Date().toISOString(),
    participating_collaborators: companyInput.participating_collaborators || [],
    updated_at: new Date().toISOString(),
  });

  return { company, prospect: mapProspect(updatedProspectRow) };
}

// ============================================================================
// COMPANIES
// ============================================================================

export async function fetchCompanies(): Promise<Company[]> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('companies').select('*').order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data || []).map((r) => mapCompany(r as AnyRow));
}

export async function createCompany(input: Omit<Company, 'id' | 'created_at'>): Promise<Company> {
  const sb = getSupabaseClient();

  const { data: existing } = await sb.from('companies').select('*');
  const dup = (existing || []).find((c: AnyRow) => {
    const n1 = str(c.name || c.company_name).trim().toLowerCase();
    const n2 = input.name.trim().toLowerCase();
    const cnpj1 = str(c.cnpj).replace(/\D/g, '');
    const cnpj2 = input.cnpj.replace(/\D/g, '');
    return n1 === n2 || (cnpj2.length >= 14 && cnpj1 === cnpj2);
  });
  if (dup) {
    throw new Error(`Empresa "${str((dup as AnyRow).name)}" já está cadastrada.`);
  }

  const row = await adaptiveInsert('companies', {
    name: input.name.trim(),
    contact_name: input.contact_name.trim(),
    phone: input.phone.trim(),
    whatsapp: input.whatsapp.trim(),
    email: input.email.trim(),
    cnpj: input.cnpj.trim(),
    city: input.city.trim(),
    segment: input.segment.trim(),
    entry_date: input.entry_date,
    contracted_service: input.contracted_service,
    contract_value: Number(input.contract_value) || 0,
    responsible_id: input.responsible_id || null,
    responsible_name: input.responsible_name.trim(),
    status: input.status,
    origin: input.origin || 'Cadastro direto',
    prospect_id: input.prospect_id || null,
    notes: input.notes.trim(),
  });
  return mapCompany(row);
}

export async function updateCompany(id: string, updates: Partial<Omit<Company, 'id' | 'created_at'>>): Promise<Company> {
  const row = await adaptiveUpdate('companies', id, updates as Record<string, unknown>);
  return mapCompany(row);
}

export async function deleteCompany(id: string): Promise<void> {
  const sb = getSupabaseClient();
  const { error } = await sb.from('companies').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

// ============================================================================
// COMMISSIONS
// ============================================================================

export async function fetchCommissions(): Promise<Commission[]> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('commissions').select('*').order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data || []).map((r) => mapCommission(r as AnyRow));
}

export async function createCommission(
  input: Omit<Commission, 'id' | 'created_at' | 'commission_value'>
): Promise<Commission> {
  const saleValue = Number(input.sale_value) || 0;
  const pct = Number(input.commission_percentage) || 0;
  const calculatedValue = Number(((saleValue * pct) / 100).toFixed(2));

  const effectivePaidAt = input.status === 'paga' ? (input.paid_at || null) : null;
  if (input.status === 'paga' && !effectivePaidAt) {
    throw new Error('Informe a data efetiva do pagamento para comissões com status Paga.');
  }

  const row = await adaptiveInsert('commissions', {
    collaborator_id: input.collaborator_id || null,
    collaborator_name: input.collaborator_name.trim(),
    company_id: input.company_id || null,
    company_name: input.company_name.trim(),
    prospect_id: input.prospect_id || null,
    participation_role: input.participation_role || null,
    description: input.description.trim(),
    sale_value: saleValue,
    commission_percentage: pct,
    commission_value: calculatedValue,
    amount: calculatedValue,
    status: input.status,
    notes: input.notes?.trim() || '',
    paid_at: effectivePaidAt,
  });
  return mapCommission(row);
}

export async function updateCommission(
  id: string,
  updates: Partial<Omit<Commission, 'id' | 'created_at'>>
): Promise<Commission> {
  const payload: Record<string, unknown> = { ...updates };

  if (updates.sale_value !== undefined && updates.commission_percentage !== undefined) {
    const calculated = Number(
      ((Number(updates.sale_value) * Number(updates.commission_percentage)) / 100).toFixed(2)
    );
    payload.commission_value = calculated;
    payload.amount = calculated;
  }

  if (updates.status === 'paga' && !updates.paid_at) {
    throw new Error('Informe a data efetiva do pagamento para marcar a comissão como paga.');
  }
  if (updates.status && updates.status !== 'paga') {
    payload.paid_at = null;
  }

  const row = await adaptiveUpdate('commissions', id, payload);
  return mapCommission(row);
}

export async function deleteCommission(id: string): Promise<void> {
  const sb = getSupabaseClient();
  const { error } = await sb.from('commissions').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

// ============================================================================
// PAYMENTS (RECEITAS) & EXPENSES (DESPESAS)
// ============================================================================

export async function fetchPayments(): Promise<Payment[]> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('payments').select('*').order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data || []).map((r) => mapPayment(r as AnyRow));
}

export async function createPayment(input: Omit<Payment, 'id' | 'created_at'>): Promise<Payment> {
  const row = await adaptiveInsert('payments', {
    description: input.description.trim(),
    company_id: input.company_id || null,
    company_name: input.company_name.trim(),
    amount: Number(input.amount) || 0,
    payment_date: input.payment_date,
    paid_at: input.status === 'recebido' ? input.payment_date : null,
    category: input.category.trim(),
    status: input.status,
    notes: input.notes?.trim() || input.description.trim(),
  });
  return mapPayment(row);
}

export async function updatePayment(id: string, updates: Partial<Omit<Payment, 'id' | 'created_at'>>): Promise<Payment> {
  const payload: Record<string, unknown> = { ...updates };
  if (updates.payment_date !== undefined) {
    payload.paid_at = updates.payment_date;
  }
  const row = await adaptiveUpdate('payments', id, payload);
  return mapPayment(row);
}

export async function deletePayment(id: string): Promise<void> {
  const sb = getSupabaseClient();
  const { error } = await sb.from('payments').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

export async function fetchExpenses(): Promise<Expense[]> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('expenses').select('*').order('expense_date', { ascending: false });
  if (error) {
    const retry = await sb.from('expenses').select('*').order('created_at', { ascending: false });
    if (retry.error) throw new Error(retry.error.message);
    return (retry.data || []).map((r) => mapExpense(r as AnyRow));
  }
  return (data || []).map((r) => mapExpense(r as AnyRow));
}

export async function createExpense(input: Omit<Expense, 'id' | 'created_at'>): Promise<Expense> {
  const row = await adaptiveInsert('expenses', {
    description: input.description.trim(),
    category: input.category.trim(),
    amount: Number(input.amount) || 0,
    expense_date: input.expense_date,
    responsible_id: input.responsible_id || null,
    responsible_name: input.responsible_name.trim(),
    notes: input.notes.trim(),
  });
  return mapExpense(row);
}

export async function updateExpense(id: string, updates: Partial<Omit<Expense, 'id' | 'created_at'>>): Promise<Expense> {
  const row = await adaptiveUpdate('expenses', id, updates as Record<string, unknown>);
  return mapExpense(row);
}

export async function deleteExpense(id: string): Promise<void> {
  const sb = getSupabaseClient();
  const { error } = await sb.from('expenses').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

// ============================================================================
// MARKETING & TASKS
// ============================================================================

export async function fetchMarketingTasks(): Promise<MarketingTask[]> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('marketing_tasks').select('*').order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data || []).map((r) => mapTask(r as AnyRow));
}

export async function createMarketingTask(
  input: Omit<MarketingTask, 'id' | 'created_at' | 'completed_at'>
): Promise<MarketingTask> {
  const row = await adaptiveInsert('marketing_tasks', {
    title: input.title.trim(),
    description: input.description.trim(),
    category: input.category,
    responsible_id: input.responsible_id || null,
    assigned_to: input.responsible_id || null,
    responsible_name: input.responsible_name.trim(),
    due_date: input.due_date || null,
    priority: input.priority,
    status: input.status,
    completed_at: input.status === 'concluida' ? new Date().toISOString() : null,
  });
  return mapTask(row);
}

export async function updateMarketingTask(
  id: string,
  updates: Partial<Omit<MarketingTask, 'id' | 'created_at'>>
): Promise<MarketingTask> {
  const payload: Record<string, unknown> = { ...updates };
  if (updates.responsible_id !== undefined) {
    payload.assigned_to = updates.responsible_id || null;
  }
  if (updates.status === 'concluida') {
    payload.completed_at = new Date().toISOString();
  } else if (updates.status) {
    payload.completed_at = null;
  }
  const row = await adaptiveUpdate('marketing_tasks', id, payload);
  return mapTask(row);
}

export async function deleteMarketingTask(id: string): Promise<void> {
  const sb = getSupabaseClient();
  const { error } = await sb.from('marketing_tasks').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

// ============================================================================
// SYSTEM SETTINGS
// ============================================================================

const DEFAULT_SETTINGS: SystemSettings = {
  id: 'default',
  organization_name: 'VORTEX SYSTEM',
  organization_cnpj: '',
  organization_email: '',
  organization_phone: '',
  organization_city: '',
  default_commission_pct: 10,
  currency: 'BRL',
  preferences: {
    compactTables: false,
    defaultPeriodDays: 30,
    customJobRoles: [],
    customDepartments: [],
  },
};

export async function fetchSystemSettings(): Promise<{ settings: SystemSettings; tableMissing: boolean }> {
  const sb = getSupabaseClient();
  const { data, error } = await sb.from('system_settings').select('*').eq('id', 'default').maybeSingle();
  if (error) {
    if (isMissingTableError(error)) {
      return { settings: DEFAULT_SETTINGS, tableMissing: true };
    }
    return { settings: DEFAULT_SETTINGS, tableMissing: false };
  }
  if (!data) return { settings: DEFAULT_SETTINGS, tableMissing: false };
  const row = data as AnyRow;
  const prefs = (row.preferences as AnyRow) || {};
  return {
    settings: {
      id: str(row.id, 'default'),
      organization_name: str(row.organization_name, 'VORTEX SYSTEM'),
      organization_cnpj: str(row.organization_cnpj),
      organization_email: str(row.organization_email),
      organization_phone: str(row.organization_phone),
      organization_city: str(row.organization_city),
      default_commission_pct: num(row.default_commission_pct, 10),
      currency: str(row.currency, 'BRL'),
      preferences: {
        compactTables: Boolean(prefs.compactTables),
        defaultPeriodDays: num(prefs.defaultPeriodDays, 30),
        customJobRoles: Array.isArray(prefs.customJobRoles) ? (prefs.customJobRoles as string[]) : [],
        customDepartments: Array.isArray(prefs.customDepartments) ? (prefs.customDepartments as string[]) : [],
      },
    },
    tableMissing: false,
  };
}

export async function saveSystemSettings(settings: SystemSettings): Promise<SystemSettings> {
  const sb = getSupabaseClient();
  const { data, error } = await sb
    .from('system_settings')
    .upsert({
      id: 'default',
      organization_name: settings.organization_name.trim(),
      organization_cnpj: settings.organization_cnpj.trim(),
      organization_email: settings.organization_email.trim(),
      organization_phone: settings.organization_phone.trim(),
      organization_city: settings.organization_city.trim(),
      default_commission_pct: Number(settings.default_commission_pct) || 10,
      currency: settings.currency || 'BRL',
      preferences: settings.preferences,
      updated_at: new Date().toISOString(),
    })
    .select('*')
    .single();
  if (error) throw new Error(error.message);
  return data as unknown as SystemSettings;
}
