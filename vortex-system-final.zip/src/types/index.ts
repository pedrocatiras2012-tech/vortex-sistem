export type UserRole = 'proprietario' | 'administrador' | 'gerente' | 'colaborador';

export interface ModulePermissions {
  dashboard: boolean;
  prospeccao: boolean;
  empresas: boolean;
  comissoes: boolean;
  financeiro: boolean;
  marketing: boolean;
  relatorios: boolean;
  equipe: boolean;
  configuracoes: boolean;
  ver_todos_leads?: boolean;
  distribuir_leads?: boolean;
  visualizar_comissoes_equipe?: boolean;
}

export interface UserProfile {
  id: string;
  full_name: string;
  email: string;
  phone?: string;
  role: UserRole;
  job_title: string;
  department?: string;
  responsibilities?: string;
  entry_date?: string;
  custom_role_label?: string;
  linked_auth_email?: string;
  permissions: ModulePermissions;
  status: 'ativo' | 'inativo';
  avatar_url?: string | null;
  created_at: string;
  updated_at?: string;
}

export interface TeamInvite {
  id: string;
  full_name: string;
  email: string;
  phone?: string;
  role: UserRole;
  job_title: string;
  department?: string;
  responsibilities?: string;
  entry_date?: string;
  avatar_url?: string | null;
  permissions: ModulePermissions;
  status: 'pendente' | 'vinculado' | 'inativo';
  linked_profile_id?: string | null;
  created_by?: string | null;
  created_at: string;
}

export type ProspectStatus =
  | 'novo'
  | 'contato_pendente'
  | 'primeiro_contato'
  | 'aguardando_resposta'
  | 'interessado'
  | 'reuniao_agendada'
  | 'proposta_enviada'
  | 'em_negociacao'
  | 'convertido'
  | 'perdido'
  | 'sem_interesse';

export type SaleStatus = 'aberta' | 'ganha' | 'perdida' | 'cancelada';

export type SaleParticipationRole = 'prospeccao' | 'atendimento' | 'negociacao' | 'fechamento';

export interface ParticipatingCollaborator {
  id: string;
  name: string;
  participation_role: SaleParticipationRole;
}

export interface Prospect {
  id: string;
  company_name: string;
  contact_name: string;
  phone: string;
  whatsapp: string;
  email?: string;
  city: string;
  segment: string;
  instagram: string;
  website: string;
  origin: string;
  member_id?: string | null;
  responsible_id: string | null;
  responsible_name: string;
  notes: string;
  first_contact_date: string;
  next_contact_date: string;
  status: ProspectStatus;
  converted_company_id?: string | null;
  converted_at?: string | null;
  place_id?: string | null;
  state?: string;
  address?: string;
  website_status?: string;
  geo_confirmed?: boolean | null;
  lead_score?: number | null;
  lead_classification?: string;
  score_justification?: string;
  commercial_opportunities?: string | string[];
  google_rating?: number | null;
  google_reviews_count?: number | null;
  search_date?: string | null;
  estimated_value?: number | null;
  deal_value?: number | null;
  contracted_service?: ServiceType | '';
  closed_at?: string | null;
  sale_status?: SaleStatus;
  loss_reason?: string;
  next_activity_title?: string;
  next_activity_time?: string;
  assigned_at?: string | null;
  assigned_by?: string | null;
  assigned_by_name?: string;
  assignment_notes?: string;
  participating_collaborators?: ParticipatingCollaborator[];
  last_interaction_at?: string | null;
  created_at: string;
  updated_at?: string;
}

export type ContactType =
  | 'primeiro_contato'
  | 'mensagem_enviada'
  | 'whatsapp'
  | 'ligacao'
  | 'resposta_recebida'
  | 'reuniao'
  | 'apresentacao_enviada'
  | 'proposta_enviada'
  | 'negociacao'
  | 'observacao_interna'
  | 'email'
  | 'outro';

export interface ProspectInteraction {
  id: string;
  prospect_id: string;
  company_id?: string | null;
  contact_at: string;
  contact_type: ContactType;
  summary: string;
  responsible_id: string | null;
  responsible_name: string;
  outcome: string;
  next_action: string;
  created_at: string;
}

export type ActivityPriority = 'baixa' | 'media' | 'alta' | 'urgente';
export type ActivityStatus = 'pendente' | 'concluida' | 'cancelada';

export interface ProspectActivity {
  id: string;
  prospect_id: string;
  title: string;
  description: string;
  due_date: string;
  due_time?: string;
  responsible_id: string | null;
  responsible_name: string;
  priority: ActivityPriority;
  status: ActivityStatus;
  completion_outcome?: string;
  completed_at?: string | null;
  created_by?: string | null;
  created_at: string;
}

export type ProposalStatus =
  | 'em_preparacao'
  | 'enviada'
  | 'visualizada'
  | 'em_negociacao'
  | 'aceita'
  | 'recusada'
  | 'expirada';

export interface CommercialProposal {
  id: string;
  prospect_id: string;
  company_id?: string | null;
  title: string;
  service_type: ServiceType;
  value: number;
  sent_date: string;
  valid_until?: string | null;
  responsible_id: string | null;
  responsible_name: string;
  status: ProposalStatus;
  viewed_confirmed_at?: string | null;
  notes?: string;
  created_at: string;
  updated_at?: string;
}

export interface LeadAssignmentHistory {
  id: string;
  prospect_id: string;
  previous_responsible_id: string | null;
  previous_responsible_name: string;
  new_responsible_id: string | null;
  new_responsible_name: string;
  assigned_by: string | null;
  assigned_by_name: string;
  notes?: string;
  created_at: string;
}

export interface SaleCollaborator {
  id: string;
  prospect_id?: string | null;
  company_id?: string | null;
  collaborator_id: string | null;
  collaborator_name: string;
  participation_role: SaleParticipationRole;
  commission_id?: string | null;
  created_at: string;
}

export type ServiceType =
  | 'criacao_sites'
  | 'gestao_redes'
  | 'presenca_digital'
  | 'automacao'
  | 'outros';

export type CompanyStatus = 'ativo' | 'onboarding' | 'pausado' | 'cancelado';

export interface Company {
  id: string;
  name: string;
  contact_name: string;
  phone: string;
  whatsapp: string;
  email: string;
  cnpj: string;
  city: string;
  segment: string;
  entry_date: string;
  contracted_service: ServiceType;
  contract_value: number;
  responsible_id: string | null;
  responsible_name: string;
  status: CompanyStatus;
  origin?: string;
  prospect_id?: string | null;
  notes: string;
  created_at: string;
}

export type CommissionStatus = 'prevista' | 'pendente' | 'aprovada' | 'paga' | 'cancelada';

export interface Commission {
  id: string;
  collaborator_id: string | null;
  collaborator_name: string;
  company_id: string | null;
  company_name: string;
  prospect_id?: string | null;
  participation_role?: SaleParticipationRole | '';
  description: string;
  sale_value: number;
  commission_percentage: number;
  commission_value: number;
  status: CommissionStatus;
  notes?: string;
  created_at: string;
  paid_at: string | null;
}

export interface Payment {
  id: string;
  description: string;
  company_id: string | null;
  company_name: string;
  amount: number;
  payment_date: string;
  category: string;
  status: 'recebido' | 'pendente' | 'cancelado';
  notes?: string;
  created_at: string;
}

export interface Expense {
  id: string;
  description: string;
  category: string;
  amount: number;
  expense_date: string;
  responsible_id: string | null;
  responsible_name: string;
  notes: string;
  created_at: string;
}

export type TaskCategory = 'marketing' | 'producao_conteudo' | 'atendimento' | 'comercial';
export type TaskPriority = 'baixa' | 'media' | 'alta' | 'urgente';
export type TaskStatus = 'pendente' | 'em_andamento' | 'concluida' | 'cancelada';

export interface MarketingTask {
  id: string;
  title: string;
  description: string;
  category: TaskCategory;
  responsible_id: string | null;
  responsible_name: string;
  due_date: string;
  priority: TaskPriority;
  status: TaskStatus;
  completed_at?: string | null;
  created_at: string;
}

export interface SystemSettings {
  id: string;
  organization_name: string;
  organization_cnpj: string;
  organization_email: string;
  organization_phone: string;
  organization_city: string;
  default_commission_pct: number;
  currency: string;
  preferences: {
    compactTables: boolean;
    defaultPeriodDays: number;
    customJobRoles?: string[];
    customDepartments?: string[];
  };
}

export interface SchemaTableStatus {
  table: string;
  exists: boolean;
  accessible: boolean;
  rowCount: number | null;
  error?: string;
}

export type AppPage =
  | 'dashboard'
  | 'prospeccao'
  | 'empresas'
  | 'equipe'
  | 'comissoes'
  | 'financeiro'
  | 'marketing'
  | 'relatorios'
  | 'configuracoes';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  description?: string;
}
